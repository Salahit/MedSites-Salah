<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
use MedSites\Presenters\UserPresenter;
use MedSites\Support\Enum\UserStatus;
use Laracasts\Presenter\PresentableTrait;

class Download extends Model
{

    use PresentableTrait;

    protected $presenter = UserPresenter::class;

    protected $table = 'download';

    protected $fillable = [

            'user_id',
        'id',
         'id_p',
            'status',


    ];


//    public function users()
//    {
//        return $this->hasMany(User::class, 'id');
//    }



        public function users_id()
    {
        return $this->hasMany('MedSites\User', 'id', 'user_id' );

    }

    public function products_id()
    {
        return $this->hasMany('MedSites\Product', 'id', 'id_p' );

    }



}

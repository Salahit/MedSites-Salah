<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
use MedSites\Presenters\UserPresenter;
use MedSites\Support\Enum\UserStatus;
use Laracasts\Presenter\PresentableTrait;

class EmployeesCashMoney extends Model
{

    use PresentableTrait;

    protected $presenter = UserPresenter::class;

    protected $table = 'employees_cash_money';

    protected $fillable = [

            'name',
            'user_id',
            'employee_id',
            'reason',
            'cash_money',
            'from_id',
            'to_id',
            'status',


    ];
    public function users_id()
    {
        return $this->hasMany('MedSites\User', 'id', 'user_id' );
    }
    public function byFromId()
    {
        return $this->hasMany('MedSites\User', 'id', 'from_id' );
    }
    public function byToId()
    {
        return $this->hasMany('MedSites\User', 'id', 'to_id' );
    }

}

<?php

namespace MedSites\Events\Price;

class Created extends PriceEvent {}
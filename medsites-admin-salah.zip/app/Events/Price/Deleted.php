<?php

namespace MedSites\Events\Price;

class Deleted extends PriceEvent {}
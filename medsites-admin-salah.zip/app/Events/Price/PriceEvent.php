<?php

namespace MedSites\Events\Price;

use MedSites\Price;

abstract class PriceEvent
{
    /**
     * @var Permission
     */
    protected $Price;

    public function __construct(Price $Price)
    {
        $this->Price = $Price;
    }

    /**
     * @return Permission
     */
    public function getPrice()
    {
        return $this->Price;
    }
}
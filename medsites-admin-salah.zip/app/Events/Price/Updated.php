<?php

namespace MedSites\Events\Price;

class Updated extends PriceEvent {}
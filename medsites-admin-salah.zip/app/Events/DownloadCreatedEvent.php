<?php


namespace MedSites\Events;




class DownloadCreatedEvent
{
    /**
     * @var User
     */
    protected $createdDownload;

    public function __construct($createdDownload)
    {
        $this->createdDownload = $createdDownload;
    }

    /**
     * @return User
     */
    public function getCreatedDownload()
    {
        return $this->createdDownload;


    }
}

<?php

namespace MedSites\Events\Page;

class Updated extends PageEvent {}
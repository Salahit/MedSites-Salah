<?php

namespace MedSites\Events\Page;

class Created extends PageEvent {}
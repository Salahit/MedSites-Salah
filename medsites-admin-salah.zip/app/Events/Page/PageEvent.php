<?php

namespace MedSites\Events\Page;

use MedSites\Pages;

abstract class PageEvent
{
    /**
     * @var Permission
     */
    protected $page;

    public function __construct(Pages $page)
    {
        $this->page = $page;
    }

    /**
     * @return Permission
     */
    public function getPage()
    {
        return $this->page;
    }
}
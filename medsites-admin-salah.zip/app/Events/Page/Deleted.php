<?php

namespace MedSites\Events\Page;

class Deleted extends PageEvent {}
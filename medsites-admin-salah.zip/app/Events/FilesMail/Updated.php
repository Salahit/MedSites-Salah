<?php

namespace MedSites\Events\FilesMail;

class Updated extends FilesMailEvent {}
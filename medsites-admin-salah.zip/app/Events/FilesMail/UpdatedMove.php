<?php

namespace MedSites\Events\FilesMail;

class UpdatedMove extends FilesMailEventMove {}
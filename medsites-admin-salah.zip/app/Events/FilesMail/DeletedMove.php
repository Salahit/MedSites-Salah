<?php

namespace MedSites\Events\FilesMail;

class DeletedMove extends FilesMailMoveEvent {}
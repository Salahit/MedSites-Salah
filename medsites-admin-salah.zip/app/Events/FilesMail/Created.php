<?php

namespace MedSites\Events\FilesMail;

class Created extends FilesMailEvent {}
<?php

namespace MedSites\Events\FilesMail;

class Deleted extends FilesMailEvent {}
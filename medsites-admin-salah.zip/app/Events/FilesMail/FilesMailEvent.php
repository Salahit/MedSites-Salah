<?php

namespace MedSites\Events\FilesMail;

use MedSites\FilesMail;

abstract class FilesMailEvent
{
    /**
     * @var Role
     */
    protected $FilesMail;

    public function __construct(FilesMail $FilesMail)
    {
        $this->FilesMail = $FilesMail;
    }

    /**
     * @return Role
     */
    public function getFilesMail()
    {
        return $this->FilesMail;
    }
}
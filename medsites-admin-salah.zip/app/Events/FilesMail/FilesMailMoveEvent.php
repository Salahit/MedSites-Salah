<?php

namespace MedSites\Events\FilesMail;

use MedSites\FilesMail;

abstract class FilesMailMoveEvent
{
    /**
     * @var Role
     */
    protected $FilesMail;

    public function __construct( $FilesMail)
    {
        $this->FilesMail = $FilesMail;
    }

    /**
     * @return Role
     */
    public function getFilesMail()
    {
        return $this->FilesMail;
    }
}
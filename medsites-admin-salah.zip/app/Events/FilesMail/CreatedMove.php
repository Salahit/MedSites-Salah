<?php

namespace MedSites\Events\FilesMail;

class CreatedMove extends FilesMailMoveEvent {}
<?php

namespace MedSites\Events\FilesMail;

use MedSites\User;

class SendFilesMove
{
    /**
     * @var User
     */
    private $areaEmail1;

    /**
     * Registered constructor.
     * @param User $registeredUser
     */
    public function __construct($areaEmail1)
    {
       $this->areaEmail1 = $areaEmail1;
    }

    /**
     * @return User
     */
    public function getRegisteredUser()
    {
        return $this->areaEmail1;
    }
}

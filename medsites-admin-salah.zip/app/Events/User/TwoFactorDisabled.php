<?php

namespace MedSites\Events\User;

class TwoFactorDisabled {}
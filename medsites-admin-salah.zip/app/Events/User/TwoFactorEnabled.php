<?php

namespace MedSites\Events\User;

class TwoFactorEnabled {}
<?php

namespace MedSites\Events\User;

class UpdatedProfileDetails {}

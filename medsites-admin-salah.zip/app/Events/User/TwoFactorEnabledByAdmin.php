<?php

namespace MedSites\Events\User;

use MedSites\User;

class TwoFactorEnabledByAdmin
{
    /**
     * @var User
     */
    protected $user;

    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * @return User
     */
    public function getUser()
    {
        return $this->user;
    }
}

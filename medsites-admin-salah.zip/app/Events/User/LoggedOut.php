<?php

namespace MedSites\Events\User;

class LoggedOut {}

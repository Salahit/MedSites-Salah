<?php

namespace MedSites\Events\User;

class ChangedAvatar {}

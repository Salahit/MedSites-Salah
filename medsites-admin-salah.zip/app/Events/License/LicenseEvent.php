<?php

namespace MedSites\Events\License;

use MedSites\License;

abstract class LicenseEvent
{
    /**
     * @var Permission
     */
    protected $license;

    public function __construct(License $license)
    {
        $this->license = $license;
    }

    /**
     * @return Permission
     */
    public function getLicense()
    {
        return $this->license;
    }
}
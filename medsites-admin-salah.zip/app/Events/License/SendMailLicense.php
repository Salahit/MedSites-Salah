<?php

namespace MedSites\Events\License;


use MedSites\License;
class SendMailLicense
{
    /**
     * @var User
     */
    private $licenseUser;

    /**
     * Registered constructor.
     * @param User $registeredUser
     */
    public function __construct($licenseUser)
    {
        $this->licenseUser = $licenseUser;
    }

    /**
     * @return User
     */
    public function getLicenseUser()
    {

        return $this->licenseUser;
    }
}

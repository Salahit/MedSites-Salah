<?php

namespace MedSites\Events\License;

class Created extends LicenseEvent {}
<?php

namespace MedSites\Events\License;

class Deleted extends LicenseEvent {}
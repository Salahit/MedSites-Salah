<?php

namespace MedSites\Events\License;

class Updated extends LicenseEvent {}
<?php

namespace MedSites\Events\Message;

use MedSites\Message;

abstract class MessageEvent
{
    /**
     * @var massage
     */
    protected $message;

    public function __construct(Message $message)
    {
        $this->message = $message;
    }

    /**
     * @return Permission
     */
    public function getMessage()
    {
        return $this->message;
    }
}
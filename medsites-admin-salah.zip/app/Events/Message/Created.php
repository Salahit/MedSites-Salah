<?php

namespace MedSites\Events\Message;

class Created extends MessageEvent {}
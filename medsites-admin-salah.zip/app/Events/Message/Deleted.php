<?php

namespace MedSites\Events\Message;

class Deleted extends MessageEvent {}
<?php

namespace MedSites\Events\Message;

class Updated extends MessageEvent {}
<?php

namespace MedSites\Events\Expense;

class Updated extends ExpenseEvent {}
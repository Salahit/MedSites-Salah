<?php

namespace MedSites\Events\Expense;

class Created extends ExpenseEvent {}
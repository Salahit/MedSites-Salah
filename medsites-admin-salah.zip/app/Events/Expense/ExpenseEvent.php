<?php

namespace MedSites\Events\Expense;

use MedSites\ZModelsExpense\Expense;
abstract class ExpenseEvent
{
    /**
     * @var Expense
     */
    protected $expense;

    public function __construct(Expense $expense)
    {
        $this->expense = $expense;
    }

    /**
     * @return Role
     */
    public function getExpense()
    {
        return $this->expense;
    }
}
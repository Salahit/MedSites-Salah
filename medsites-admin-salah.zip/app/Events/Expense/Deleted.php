<?php

namespace MedSites\Events\Expense;

class Deleted extends ExpenseEvent {}
<?php

namespace MedSites\Events\Order;

use MedSites\OrderInvoice;

abstract class OrderInvoiceEvent
{
    /**
     * @var Role
     */
    protected $order;

    public function __construct(OrderInvoice $order)
    {
        $this->order = $order;
    }

    /**
     * @return Role
     */
    public function getOrder()
    {
        return $this->order;
    }
}
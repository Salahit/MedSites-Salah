<?php

namespace MedSites\Events\Order;

class Deleted extends OrderEvent {}
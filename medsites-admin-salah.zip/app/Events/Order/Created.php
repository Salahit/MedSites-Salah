<?php

namespace MedSites\Events\Order;

class Created extends OrderEvent {}
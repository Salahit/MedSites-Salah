<?php

namespace MedSites\Events\Order;

class DeletedInvoice extends OrderInvoiceEvent {}
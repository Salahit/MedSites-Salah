<?php

namespace MedSites\Events\Order;

use MedSites\Order;

abstract class OrderEvent
{
    /**
     * @var Role
     */
    protected $order;

    public function __construct(Order $order)
    {
        $this->order = $order;
    }

    /**
     * @return Role
     */
    public function getOrder()
    {
        return $this->order;
    }
}
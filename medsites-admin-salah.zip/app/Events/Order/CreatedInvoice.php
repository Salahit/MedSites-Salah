<?php

namespace MedSites\Events\Order;

class CreatedInvoice extends OrderInvoiceEvent {}
<?php

namespace MedSites\Events\Order;

class Updated extends OrderEvent {}
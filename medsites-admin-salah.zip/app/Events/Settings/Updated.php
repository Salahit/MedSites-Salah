<?php

namespace MedSites\Events\Settings;

class Updated {}
<?php

namespace MedSites\Events\Product;

class Created extends ProductEvent {}
<?php

namespace MedSites\Events\Product;

use MedSites\Product;

abstract class ProductEvent
{
    /**
     * @var Permission
     */
    protected $product;

    public function __construct(Product $product)
    {
        $this->product = $product;
    }

    /**
     * @return Permission
     */
    public function getProduct()
    {
        return $this->product;
    }
}
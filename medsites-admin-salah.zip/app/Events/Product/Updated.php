<?php

namespace MedSites\Events\Product;

class Updated extends ProductEvent {}
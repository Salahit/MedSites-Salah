<?php

namespace MedSites\Events\Product;

class Deleted extends ProductEvent {}
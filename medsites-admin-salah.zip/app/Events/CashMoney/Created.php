<?php

namespace MedSites\Events\CashMoney;

class Created extends CashMoneyEvent {}
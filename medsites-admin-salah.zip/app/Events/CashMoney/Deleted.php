<?php

namespace MedSites\Events\CashMoney;

class Deleted extends CashMoneyEvent {}
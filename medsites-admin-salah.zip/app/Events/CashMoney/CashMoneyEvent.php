<?php

namespace MedSites\Events\CashMoney;

use MedSites\EmployeesCashMoney;

abstract class CashMoneyEvent
{
    /**
     * @var Role
     */
    protected $CashMoney;

    public function __construct(EmployeesCashMoney $cashMoney)
    {
        $this->CashMoney = $cashMoney;
    }

    /**
     * @return Role
     */
    public function getCashMoney()
    {
        return $this->CashMoney;
    }
}
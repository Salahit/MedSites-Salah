<?php

namespace MedSites\Events\CashMoney;

class Updated extends CashMoneyEvent {}
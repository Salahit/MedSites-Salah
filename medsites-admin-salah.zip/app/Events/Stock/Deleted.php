<?php

namespace MedSites\Events\Stock;

class Deleted extends StockEvent {}
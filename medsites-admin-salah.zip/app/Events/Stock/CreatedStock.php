<?php

namespace MedSites\Events\Stock;

use MedSites\StockItem;

class CreatedStock
{
    /**
     * @var User
     */
    protected $CreatedStock;

    public function __construct(StockItem $CreatedStock)
    {
        $this->CreatedStock = $CreatedStock;
    }

    /**
     * @return User
     */
    public function getCreatedStock()
    {
        return $this->CreatedStock;
    }
}

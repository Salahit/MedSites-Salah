<?php

namespace MedSites\Events\Stock;

use MedSites\Stock;
use MedSites\StockItem;

abstract class StockEvent
{
    /**
     * @var Stock
     */
    protected $stock;

    public function __construct(Stock $stock)
    {
        $this->stock = $stock;
    }

    /**
     * @return Role
     */
    public function getStock()
    {
        return $this->stock;
    }
}
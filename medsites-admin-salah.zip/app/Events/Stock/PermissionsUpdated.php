<?php

namespace MedSites\Events\Stock;

class StockUpdated {}
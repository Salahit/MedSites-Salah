<?php

namespace MedSites\Events\Stock;

class Updated extends StockEvent {}
<?php

namespace MedSites\Events\Stock;

use MedSites\User;

class SendStock
{
    /**
     * @var User
     */
    private $areaEmail1;

    /**
     * Registered constructor.
     * @param User $registeredUser
     */
    public function __construct($areaEmail1)
    {
       $this->areaEmail1 = $areaEmail1;
    }

    /**
     * @return User
     */
    public function getRegisteredUser()
    {
        return $this->areaEmail1;
    }
}

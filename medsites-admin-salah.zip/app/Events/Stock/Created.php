<?php

namespace MedSites\Events\Stock;

class Created extends StockEvent {}
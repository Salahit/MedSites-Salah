<?php

namespace MedSites\Events;

abstract class Event
{
    //
}

<?php

namespace MedSites\Events\Importer;

class Updated extends ImporterEvent {}
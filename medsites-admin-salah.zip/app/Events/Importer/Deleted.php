<?php

namespace MedSites\Events\Importer;

class Deleted extends ImporterEvent {}
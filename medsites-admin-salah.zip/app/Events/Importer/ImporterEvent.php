<?php

namespace MedSites\Events\Importer;

use MedSites\StockImportersItems;

abstract class ImporterEvent
{
    /**
     * @var Role
     */
    protected $importer;

    public function __construct(StockImportersItems $importers)
    {
        $this->importer = $importers;
    }

    /**
     * @return Role
     */
    public function getImporter()
    {
        return $this->importer;
    }
}
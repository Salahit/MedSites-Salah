<?php

namespace MedSites\Events\Importer;

class Created extends ImporterEvent {}
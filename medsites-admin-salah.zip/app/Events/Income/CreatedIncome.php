<?php

namespace MedSites\Events\Income;

class CreatedIncome extends IncomeEvent {}
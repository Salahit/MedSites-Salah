<?php

namespace MedSites\Events\Income;

class UpdatedIncome extends IncomeEvent {}
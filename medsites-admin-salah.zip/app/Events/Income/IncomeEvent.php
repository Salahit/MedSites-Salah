<?php

namespace MedSites\Events\Income;

use MedSites\ZModelsExpense\IncomeInvoice;
abstract class IncomeEvent
{
    /**
     * @var Expense
     */
    protected $expense;

    public function __construct(IncomeInvoice $expense)
    {
        $this->expense = $expense;
    }

    /**
     * @return Role
     */
    public function getExpense()
    {
        return $this->expense;
    }
}
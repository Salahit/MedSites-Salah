<?php

namespace MedSites\Events\Income;

class DeletedIncome extends IncomeEvent {}
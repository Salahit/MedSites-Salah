<?php

namespace MedSites\Events\Permission;

class Created extends PermissionEvent {}
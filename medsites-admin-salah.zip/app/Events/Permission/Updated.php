<?php

namespace MedSites\Events\Permission;

class Updated extends PermissionEvent {}
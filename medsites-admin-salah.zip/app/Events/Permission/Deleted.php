<?php

namespace MedSites\Events\Permission;

class Deleted extends PermissionEvent {}
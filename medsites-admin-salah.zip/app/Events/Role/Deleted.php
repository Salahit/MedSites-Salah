<?php

namespace MedSites\Events\Role;

class Deleted extends RoleEvent {}
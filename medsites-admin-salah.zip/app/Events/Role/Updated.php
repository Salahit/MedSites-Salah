<?php

namespace MedSites\Events\Role;

class Updated extends RoleEvent {}
<?php

namespace MedSites\Events\Role;

class PermissionsUpdated {}
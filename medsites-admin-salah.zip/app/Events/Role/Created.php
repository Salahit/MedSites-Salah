<?php

namespace MedSites\Events\Role;

class Created extends RoleEvent {}
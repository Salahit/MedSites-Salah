<?php

namespace MedSites\Events\Registration;

use MedSites\RegistrationEvents;

abstract class RegistrationEvent
{
    /**
     * @var Role
     */
    protected $Registration;

    public function __construct(RegistrationEvents $registration)
    {
        $this->Registration = $registration;
    }

    /**
     * @return Role
     */
    public function getRegistration()
    {
        return $this->Registration;
    }
}
<?php

namespace MedSites\Events\Registration;

class Deleted extends RegistrationEvent {}
<?php

namespace MedSites\Events\Registration;

class Created extends RegistrationEvent {}
<?php

namespace MedSites\Events\Registration;

class Updated extends RegistrationEvent {}
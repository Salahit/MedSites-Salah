<?php

namespace MedSites\Events\Registration;

use MedSites\RegistrationMessage;

class CommentEvent
{
    /**
     * @var Role
     */
    protected $Comment;

    public function __construct(RegistrationMessage $Comment)
    {
        $this->Comment = $Comment;
    }

    /**
     * @return Role
     */
    public function getComment()
    {
        return $this->Comment;
    }
}
<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
use MedSites\Presenters\UserPresenter;
use MedSites\Support\Enum\UserStatus;
use Laracasts\Presenter\PresentableTrait;

class Files extends Model
{

    use PresentableTrait;

    protected $presenter = UserPresenter::class;

    protected $table = 'files';

    protected $fillable = [

            'name',
            'user_id',
            'filetype',
            'size_file',
            'status',


    ];

}

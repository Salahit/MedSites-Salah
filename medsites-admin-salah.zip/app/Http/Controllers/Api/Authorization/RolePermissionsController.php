<?php

namespace MedSites\Http\Controllers\Api\Authorization;

use Cache;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use MedSites\Events\Role\PermissionsUpdated;
use MedSites\Http\Controllers\Api\ApiController;
use MedSites\Http\Requests\Role\CreateRoleRequest;
use MedSites\Http\Requests\Role\RemoveRoleRequest;
use MedSites\Http\Requests\Role\UpdateRolePermissionsRequest;
use MedSites\Http\Requests\Role\UpdateRoleRequest;
use MedSites\Repositories\Role\RoleRepository;
use MedSites\Repositories\User\UserRepository;
use MedSites\Role;
use MedSites\Transformers\PermissionTransformer;
use MedSites\Transformers\RoleTransformer;

/**
 * Class RolePermissionsController
 * @package MedSites\Http\Controllers\Api
 */
class RolePermissionsController extends ApiController
{
    /**
     * @var RoleRepository
     */
    private $roles;

    public function __construct(RoleRepository $roles)
    {
        $this->roles = $roles;
        $this->middleware('auth');
        $this->middleware('permission:permissions.manage');
    }

    public function show(Role $role)
    {
        return $this->respondWithCollection(
            $role->cachedPermissions(),
            new PermissionTransformer
        );
    }

    /**
     * Update specified role.
     * @param Role $role
     * @param UpdateRolePermissionsRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Role $role, UpdateRolePermissionsRequest $request)
    {
        $this->roles->updatePermissions(
            $role->id,
            $request->permissions
        );

        event(new PermissionsUpdated);

        return $this->respondWithCollection(
            $role->cachedPermissions(),
            new PermissionTransformer
        );
    }
}

<?php

namespace MedSites\Http\Controllers\Api;

use MedSites\Repositories\Country\CountryRepository;
use MedSites\Transformers\CountryTransformer;

/**
 * Class CountriesController
 * @package MedSites\Http\Controllers\Api
 */
class CountriesController extends ApiController
{
    /**
     * @var CountryRepository
     */
    private $countries;

    public function __construct(CountryRepository $countries)
    {
        $this->middleware('auth');
        $this->countries = $countries;
    }

    /**
     * Get list of all available countries.
     * @return \Illuminate\Http\JsonResponse
     */
    public function index()
    {
        return $this->respondWithCollection(
            $this->countries->all(),
            new CountryTransformer
        );
    }
}

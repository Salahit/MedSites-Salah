<?php

namespace MedSites\Http\Controllers\Api\Profile;

use MedSites\Events\User\UpdatedProfileDetails;
use MedSites\Http\Controllers\Api\ApiController;
use MedSites\Http\Requests\User\UpdateProfileDetailsRequest;
use MedSites\Http\Requests\User\UpdateProfileLoginDetailsRequest;
use MedSites\Repositories\User\UserRepository;
use MedSites\Transformers\UserTransformer;

/**
 * Class DetailsController
 * @package MedSites\Http\Controllers\Api\Profile
 */
class AuthDetailsController extends ApiController
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Updates user profile details.
     * @param UpdateProfileLoginDetailsRequest $request
     * @param UserRepository $users
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UpdateProfileLoginDetailsRequest $request, UserRepository $users)
    {
        $user = $request->user();

        $data = $request->only(['email', 'username', 'password']);

        $user = $users->update($user->id, $data);

        return $this->respondWithItem($user, new UserTransformer);
    }
}

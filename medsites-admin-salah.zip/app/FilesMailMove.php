<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
//use MedSites\Support\Enum\UserStatus;
use MedSites\Presenters\UserPresenter;
use Laracasts\Presenter\PresentableTrait;
class FilesMailMove extends Model
{
  use PresentableTrait;

    protected $presenter = UserPresenter::class;
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'files_mail_move';



    protected $fillable = [
        'file_id',
        'by_company_id',
        'by_to_hand',
        'company_id',
        'company_to_id',
        'reason',
        'note',
        'user_id',
        'in_or_out',
        'date_at',
        'status'
    ];

    public function byCompanyId()
    {
        return $this->hasMany('MedSites\ZModels\PostalCompany', 'id', 'by_company_id' );
    }
    public function byHandsId()
    {
        return $this->hasMany('MedSites\ZModels\PostalCompany', 'id', 'by_to_hand' );
    }

    public function CompanyId()
    {
        return $this->hasMany('MedSites\ZModels\Company', 'id', 'company_id' );
    }
    public function CompanyIdOut()
    {
        return $this->hasMany('MedSites\ZModels\Company', 'id', 'company_to_id' );
    }

    public function ItemId()
    {
        return $this->hasMany('MedSites\ZModels\Item', 'id', 'item_id' );
    }

}

<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
use MedSites\Presenters\UserPresenter;
use MedSites\Support\Enum\UserStatus;
use Laracasts\Presenter\PresentableTrait;

class Employees extends Model
{

    use PresentableTrait;

    protected $presenter = UserPresenter::class;

    protected $table = 'employees';

    protected $fillable = [

            'name',
            'user_id',
            'employee_id',
            'salary',
            'cash_money',
            'total_cash_money',
            'status',


    ];
    public function users_id()
    {
        return $this->hasMany('MedSites\User', 'id', 'employee_id' );
    }
}

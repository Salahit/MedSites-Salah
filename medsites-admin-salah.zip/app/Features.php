<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
use MedSites\Presenters\UserPresenter;
use MedSites\Support\Enum\UserStatus;
use Laracasts\Presenter\PresentableTrait;
class Features extends Model
{

    use PresentableTrait;

    protected $presenter = UserPresenter::class;

    protected $table = 'features';



}

<?php

namespace MedSites;

use Illuminate\Database\Eloquent\Model;
//use MedSites\Support\Enum\UserStatus;
use MedSites\Presenters\UserPresenter;
use Laracasts\Presenter\PresentableTrait;
class FilesMail extends Model
{
  use PresentableTrait;

    protected $presenter = UserPresenter::class;
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'files_mail';



    protected $fillable = [
        'by_company_id',
        'company_id',
        'reason',
        'user_id',
        'item_id',
        'file_name',
        'note',
        'picture',
        'created_arrive',
        'status_out_in',
        'status'
    ];

    public function byCompanyId()
    {
        return $this->hasMany('MedSites\ZModels\PostalCompany', 'id', 'by_company_id' );
    }

    public function CompanyId()
    {
        return $this->hasMany('MedSites\ZModels\Company', 'id', 'company_id' );
    }

    public function ItemId()
    {
        return $this->hasMany('MedSites\ZModels\Item', 'id', 'item_id' );
    }

    public function moves()
    {
        //  return $this->hasMany('MedSites\OrderInvoice', 'order_id' , 'id');
        return $this->hasMany(FilesMailMove::class, 'file_id' , 'id');
    }
}

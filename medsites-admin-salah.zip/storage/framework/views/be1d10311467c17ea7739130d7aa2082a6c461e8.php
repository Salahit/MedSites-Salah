<?php $__env->startSection('page-title', 'Income'); ?>
<?php $__env->startSection('page-heading',  'Income'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('expenses.index')); ?>"> Income </a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('expense.accounting.income.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th> ID</th>
                        <th> Amount</th>
                        <th>	Price Dollar </th>

                        <th>Income Type</th>
                        <th>Name </th>
                        <th>Add By </th>

                        <th> Arrival Date</th>
                        <th>Create Date</th>
                        <th><?php echo app('translator')->getFromJson('app.action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(count($incomes)): ?>
                            <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('expense.accounting.income.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>

                    <th>  </th>
                    <th><h4><?php echo e(number_format($paginateIncomeSum)); ?> </h4></th>

                    <th> </th>
                    <th>  </th>
                    <th>   </th>
                    <th>  </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                <?php echo $incomes->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $("#month").change(function () {
            $("#users-form").submit();
        });

        $("#company").change(function () {
            $("#users-form").submit();
        });

        $("#type").change(function () {
            $("#users-form").submit();
        });

        $("#name").change(function () {
            $("#users-form").submit();
        });


    </script>


<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2.css'); ?>">
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2-bootstrap4.css'); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>


        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4 ',

                });
            });
        });

    </script>

    <script src="<?php echo url('assets/plugins/select2/select2.full.js'); ?>"></script>

    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/expense/accounting/income/index.blade.php ENDPATH**/ ?>
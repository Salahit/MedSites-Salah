<?php $__env->startSection('page-title', $filesMail->file_name); ?>
<?php $__env->startSection('page-heading', $filesMail->file_name); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('filesMail.index')); ?>"><?php echo app('translator')->getFromJson('app.filesMail'); ?></a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($filesMail->file_name); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-4 col-xl-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    <?php echo app('translator')->getFromJson('app.details'); ?>

                    <small class="float-right">


                        <a href="<?php echo e(route('filesMail.edit', $filesMail->id)); ?>" class="edit"
                           data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('app.edit'); ?>">
                            <?php echo app('translator')->getFromJson('app.edit'); ?>
                        </a>
                    </small>
                </h5>


                <ul class="list-group list-group-flush mt-3">
                    <div class="d-flex align-items-center flex-column pt-3">
                        <div>
                          <?php echo $filesMail->present()->picture; ?>

                        </div>
                    </div>


                    <li class="list-group-item">

                        <?php echo e($filesMail->file_name); ?>

                    </li>
                    <li class="list-group-item"><strong> Out or In :</strong>
                        <?php if($filesMail->status_out_in === 'In'): ?>

<span class="badge badge-lg badge-success">
 <?php echo e($filesMail->status_out_in); ?>

 <?php else: ?>
 <span class="badge badge-lg badge-secondary">
 <?php echo e($filesMail->status_out_in); ?> <?php endif; ?>

 </span>






                    </li>

                    <li class="list-group-item">
                        Date Create<br>
                        <strong><?php echo e(\Carbon\Carbon::parse($filesMail->created_at)->format('Y F  d D')); ?><br>
                       <?php echo e($filesMail->created_at->diffForHumans()); ?>

                        </strong>
                    </li>

                </ul>
            </div>
        </div>
    </div>

    <div class="col-lg-8 col-xl-9">
        <div class="card">
            <div class="card-body">

                <?php echo $__env->make('filesMail.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <?php if(count($fileMoves)): ?>
                    <table class="table table-borderless table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>By</th>
                            <th>To hand</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>

                            <th><-></th>

                            <th class="text-center min-width-150"><?php echo app('translator')->getFromJson('app.action'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $fileMoves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('filesMail.partials.rowMoves', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="text-muted font-weight-light"><em>No moves  from this files  yet.</em></p>
                <?php endif; ?>
                <?php echo $fileMoves->render(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/filesMail/view.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, Without shrink-to-fit specified">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title'); ?> - <?php echo e(settings('app_name')); ?></title>

    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(url('assets/img/icons/apple-touch-icon-144x144.png')); ?>" />
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo e(url('assets/img/icons/apple-touch-icon-152x152.png')); ?>" />
    <link rel="icon" type="image/png" href="<?php echo e(url('assets/img/icons/favicon-32x32.png')); ?>" sizes="32x32" />
    <link rel="icon" type="image/png" href="<?php echo e(url('assets/img/icons/favicon-16x16.png')); ?>" sizes="16x16" />
    <meta name="application-name" content="<?php echo e(settings('app_name')); ?>"/>
    <meta name="msapplication-TileColor" content="#FFFFFF" />
    <meta name="msapplication-TileImage" content="<?php echo e(url('assets/img/icons/mstile-144x144.png')); ?>" />

    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(url(mix('assets/css/vendor.css'))); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(url(mix('assets/css/app.css'))); ?>">
    <link media="all" type="text/css" rel="stylesheet" href="<?php echo e(url('assets/plugins/pnotify/pnotify.custom.min.css')); ?>">

    <?php echo $__env->yieldContent('after_styles'); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body >
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="content-page" >
                <main role="main" class="px-2">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
        </div>
    </div>

    <script src="<?php echo e(url(mix('assets/js/vendor.js'))); ?>"></script>
    <script src="<?php echo e(url('assets/js/as/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('after_scripts'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="<?php echo e(url('assets/plugins/pnotify/pnotify.custom.min.js')); ?>"></script>


    
    <script type="text/javascript">
        jQuery(document).ready(function ($) {

            PNotify.prototype.options.styling = "bootstrap3";
            PNotify.prototype.options.styling = "fontawesome";

            <?php $__currentLoopData = Alert::getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            $(function () {
                <?php if($message == 'demo_mode_message'): ?>
                new PNotify({
                    title: 'Information',
                    text: "<?php echo e($message); ?>",
                    type: "<?php echo e($type); ?>"
                });
                <?php else: ?>
                new PNotify({
                    text: "<?php echo e($message); ?>",
                    type: "<?php echo e($type); ?>",
                    icon: false
                });
                <?php endif; ?>
            });

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/layouts/app.blade.php ENDPATH**/ ?>
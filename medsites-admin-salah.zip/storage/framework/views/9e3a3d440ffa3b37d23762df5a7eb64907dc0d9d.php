<?php $__env->startSection('page-title', 'Comments '); ?>
<?php $__env->startSection('page-heading', $event->title); ?>
ؤ
<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('registration.index')); ?>">   Registration </a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($event->title); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row" >
        <div class="col-lg-4 col-xl-5">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">
                        <?php echo app('translator')->getFromJson('app.details'); ?> Ticket

                        <small class="float-right">


                        </small>
                    </h5>



                    <ul class="list-group list-group-flush mt-3">


                        <li class="list-group-item">

                            <?php echo e($event->start); ?> <br><strong><?php echo e($event->created_at->diffForHumans()); ?> </strong>
                        </li>
                        <li class="list-group-item">
                            <strong>Add by:</strong>
                            <a href="<?php echo e(route('user.show', $event->user_id)); ?>">  <?php echo e($event->usersid->first()
                            ->present()->nameOrEmail); ?></a>
                        </li>
                        <li class="list-group-item">
                            <strong>Title:</strong>
                      <?php echo e($event->title); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Description :</strong>
                            <?php echo $event->description; ?>

                        </li>

                    </ul>

                    <?php echo Form::open(['route' => 'registration.storeMessage', 'id' => 'message-form']); ?>


                        <input type="hidden" value="<?php echo e($event->user_id); ?>" name="user_id" >
                        <input type="hidden" value="<?php echo e($event->id); ?>" name="registration_id" >
                        <div class="row" id="container">
                        <div class="col-md-12" >
                            <div class="form-group">
                                <label for="message">Comment  <a href="#" id="toggle_fullscreen">Toggle
                                        Fullscreen</a></label>
                                <textarea name="message" id="description" rows="5" class="form-control"><?php echo e(old('message')); ?></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary">
                                 Send Comment
                                </button>
                            </div>
                        </div>
                            <?php echo Form::close(); ?>

                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-8 col-xl-7 " >
            <div class="scroll-1  square scrollbar-cyan bordered-cyan">
                <div class="card">
                    <div class="card-body mt-md-0 mt-0">


                        <?php if(count($message2)): ?>
                            <?php $__currentLoopData = $message2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licenseActivity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($licenseActivity->user_id != auth()->user()->id): ?>
                                    <div class="card text-primary bg-white mt-md-0 mt-0">
                                        <?php else: ?>
                                            <div class="card bg-primary text-light mt-md-0 mt-0"  >
                                                <?php endif; ?>
                                                <span class="badge badge position-absolute mt-md-0 mt-0"> <?php echo e($licenseActivity->created_at->diffForHumans()); ?>

                                                    <?php if($licenseActivity->user_id == auth()->user()->id): ?>
                                                          <?php endif; ?> - <?php echo e($licenseActivity->usersid->first()->present()
                       ->nameOrEmail); ?>



                       </span>




                                                    <div class="dropdown show d-inline-block float-right mt-md-0 mt-0">

                                                           <a class="btn btn-icon float-right"
                                                       href="#" role="button" id="dropdownMenuLink"
                                                       data-toggle="dropdown"
                                                       data-html="true"
                                                       aria-haspopup="true" aria-expanded="true">
                                                               <?php if($licenseActivity->user_id == auth()->user()->id): ?>    <i class="fas fa-edit"></i>
                                                               <?php endif; ?>  </a>
                                                        <?php if($licenseActivity->user_id == auth()->user()->id): ?>
                                                        <div class="col-md-12 dropdown-menu dropdown-menu-right"
                                                         aria-labelledby="dropdownMenuLink">
                                                        <div class="col-md-12 mt-md-0 mt-0">

                                                            <?php echo Form::open(['route' => ['registration.updateText', $licenseActivity->id],
                                                             'method' => 'PUT', 'id' =>
                                                            'stockEdit-form']); ?>


                                                            <div class="form-group my-0">
  <textarea name="message"  rows="5" class="form-control"><?php echo e(html_entity_decode($licenseActivity->message)); ?>

  </textarea>


                                                            </div>
                                                        </div>

                                                        <div class="form-group my-3   ml-5">
                                                            <button type="submit" class="btn btn-primary">
                                                                Save
                                                            </button>
                                                        </div>
                                                        <?php echo Form::close(); ?>

                                                    </div>
                                                        <?php endif; ?>


                                                </div>

                                                <div class="mt-md-0 mt-0 ml-1">

                                                    <?php echo $licenseActivity->message; ?>



                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            <?php else: ?>
                                                <p class="text-muted font-weight-light"><em>no message from this user yet</em></p>
                                            <?php endif; ?>
                                    </div>
                    </div>
                </div>
            </div>


            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('after_styles'); ?>
                <link rel="stylesheet" type="text/css" href="<?php echo e(url('design')); ?>/assets/plugins/simditor/styles/simditor.css" />



                <?php echo $__env->yieldPushContent('dashboard_styles'); ?>

                <style>




                    .scrollbar-cyan::-webkit-scrollbar-track {
                        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
                        background-color: #F5F5F5;
                        border-radius: 10px; }

                    .scrollbar-cyan::-webkit-scrollbar {
                        width: 12px;
                        background-color: #F5F5F5; }

                    .scrollbar-cyan::-webkit-scrollbar-thumb {
                        border-radius: 10px;
                        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
                        background-color: #00bcd4; }

                    .scrollbar-dusty-grass::-webkit-scrollbar-track {
                        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
                        background-color: #F5F5F5;
                        border-radius: 10px; }



                    .bordered-deep-purple::-webkit-scrollbar-track {
                        -webkit-box-shadow: none;
                        border: 1px solid #512da8; }

                    .bordered-deep-purple::-webkit-scrollbar-thumb {
                        -webkit-box-shadow: none; }

                    .bordered-cyan::-webkit-scrollbar-track {
                        -webkit-box-shadow: none;
                        border: 1px solid #00bcd4; }

                    .bordered-cyan::-webkit-scrollbar-thumb {
                        -webkit-box-shadow: none; }

                    .square::-webkit-scrollbar-track {
                        border-radius: 0 !important; }

                    .square::-webkit-scrollbar-thumb {
                        border-radius: 0 !important; }

                    .thin::-webkit-scrollbar {
                        width: 6px; }

                    .scroll-1 {
                        position: relative;
                        overflow-y: scroll;

                        height: 600px;
                    }


                </style>

            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('after_scripts'); ?>



                <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/mobilecheck.js"></script>

                <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/module.js"></script>
                <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/hotkeys.js"></script>
                <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/uploader.js"></script>
                <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/simditor.js"></script>
                <script type="text/javascript">
                    Simditor.i18n = {
                        'en': {
                            'blockquote': 'Block Quote',
                            'bold': 'Bold',
                            'code': 'Code',
                            'color': 'Text Color',
                            'coloredText': 'Colored Text',
                            'hr': 'Horizontal Line',
                            'image': 'Insert Image',
                            'externalImage': 'External Image',
                            'uploadImage': 'Upload Image',
                            'uploadFailed': 'Upload failed',
                            'uploadError': 'Error occurs during upload',
                            'imageUrl': 'Url',
                            'imageSize': 'Size',
                            'imageAlt': 'Alt',
                            'restoreImageSize': 'Restore Origin Size',
                            'uploading': 'Uploading',
                            'indent': 'Indent',
                            'outdent': 'Outdent',
                            'italic': 'Italic',
                            'link': 'Insert Link',
                            'linkText': 'Text',
                            'linkUrl': 'Url',
                            'linkTarget': 'Target',
                            'openLinkInCurrentWindow': 'Open link in current window',
                            'openLinkInNewWindow': 'Open link in new window',
                            'removeLink': 'Remove Link',
                            'ol': 'Ordered List',
                            'ul': 'Unordered List',
                            'strikethrough': 'Strikethrough',
                            'table': 'Table',
                            'deleteRow': 'Delete Row',
                            'insertRowAbove': 'Insert Row Above',
                            'insertRowBelow': 'Insert Row Below',
                            'deleteColumn': 'Delete Column',
                            'insertColumnLeft': 'Insert Column Left',
                            'insertColumnRight': 'Insert Column Right',
                            'deleteTable': 'Delete Table',
                            'title': 'Title',
                            'normalText': 'Text',
                            'underline': 'Underline',
                            'alignment': 'Alignment',
                            'alignCenter': 'Align Center',
                            'alignLeft': 'Align Left',
                            'alignRight': 'Align Right',
                            'selectLanguage': 'Select Language',
                            'fontScale': 'Font Size',
                            'fontScaleXLarge': 'X Large Size',
                            'fontScaleLarge': 'Large Size',
                            'fontScaleNormal': 'Normal Size',
                            'fontScaleSmall': 'Small Size',
                            'fontScaleXSmall': 'X Small Size'
                        }
                    };

                    (function() {
                        $(function() {
                            var $preview, editor, mobileToolbar, toolbar, allowedTags;
                            Simditor.locale = 'en';
                            toolbar = ['bold','italic','underline','fontScale','color','|','ol','ul','blockquote','table','link'];
                            mobileToolbar = ["bold", "italic", "underline", "ul", "ol"];
                            if (mobilecheck()) {
                                toolbar = mobileToolbar;
                            }


                            allowedTags = ['br','span','a','img','b','strong','i','strike','u','font','p','ul','ol','li','blockquote','pre','h1','h2','h3','h4','hr','table'];
                            editor = new Simditor({
                                textarea: $('#description'),
                                placeholder: 'Message',
                                toolbar: toolbar,
                                pasteImage: false,
                                defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                                upload: false,
                                allowedTags: allowedTags
                            });
                            editor = new Simditor({
                                textarea: $('#descriptionar'),
                                placeholder: 'صف ما الذي يجعل الممتج فريدا من نوعه...',
                                toolbar: toolbar,
                                pasteImage: false,
                                defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                                upload: false,
                                allowedTags: allowedTags
                            });
                            $preview = $('#preview');
                            if ($preview.length > 0) {
                                return editor.on('valuechanged', function(e) {
                                    return $preview.html(editor.getValue());
                                });
                            }
                        });
                    }).call(this);

                    $('#toggle_fullscreen').on('click', function(){
                        // if already full screen; exit
                        // else go fullscreen
                        if (
                            document.fullscreenElement ||
                            document.webkitFullscreenElement ||
                            document.mozFullScreenElement ||
                            document.msFullscreenElement
                        ) {
                            if (document.exitFullscreen) {
                                document.exitFullscreen();
                            } else if (document.mozCancelFullScreen) {
                                document.mozCancelFullScreen();
                            } else if (document.webkitExitFullscreen) {
                                document.webkitExitFullscreen();
                            } else if (document.msExitFullscreen) {
                                document.msExitFullscreen();
                            }
                        } else {
                            element = $('#container').get(0);
                            if (element.requestFullscreen) {
                                element.requestFullscreen();
                            } else if (element.mozRequestFullScreen) {
                                element.mozRequestFullScreen();
                            } else if (element.webkitRequestFullscreen) {
                                element.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                            } else if (element.msRequestFullscreen) {
                                element.msRequestFullscreen();
                            }
                        }
                    });

                </script>
                <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->

    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Registration\CreateMessageRequest', '#message-form'); ?>

        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Registration\UpdateMessageRequest', '#stockEdit-form'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/registration/view.blade.php ENDPATH**/ ?>
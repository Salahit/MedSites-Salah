<?php $__env->startSection('page-title', 'Expenses'); ?>
<?php $__env->startSection('page-heading', 'Expenses '); ?>

<?php $__env->startSection('breadcrumbs'); ?>


    <li class="breadcrumb-item active">
        <a href="<?php echo e(route('expenses.index')); ?>"> Expenses </a>
    </li>   <li class="breadcrumb-item text-muted">
        Print
    </li>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>


    <section class="content" id="invoice-stmt">
        <div class="row">
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header bg-success text-white">
                        <span><i data-name="tablet" data-size="30" data-loop="true" data-c="#fff"
                                 data-hc="#fff"></i> Print  At <bold><?php echo e(\Carbon\Carbon::now()->format(config('app.date_time_format'))); ?></bold></span>


                    </div>
                    <div class="card-body"  >
                        <div class="row my-0 flex-md-row flex-column-reverse" >
                            <div class=" col-md-12 mt-md-0 mt-0">
           <img src="<?php echo e(url('assets/img/medsites-logo.png')); ?>" alt="logo" class="img-fluid">
                                <h5 class="mt-md-0 my-10 float-right">
                                    <?php if(Input::get('user') != ''): ?>


                                Print By    <?php echo e(auth()->user()->present()->nameOrEmail); ?>

                                        -   <b> <?php echo e($listsEmployeesme->users_id()->first()->present()->nameOrEmail); ?></b>
                                        <?php else: ?>

                                        All -



                                    <?php endif; ?>
                                        <?php if(Input::get('user') == ''): ?>  <?php echo e($listsEmployeesme->users_id()->first()->present()->nameOrEmail); ?>  <?php endif; ?> - Cash Money <?php echo e(number_format
                                        ($listsEmployeesme->cash_money)); ?>


                                        <br>
                                        <?php if(Input::get('from') != ''): ?>

                                            <?php echo e(Input::get('from')); ?> To  <?php echo e(Input::get('to')); ?>

                                        <?php endif; ?>

                                </h5>

                            </div>


                        </div>

                        </div>
                        <div class="row" style="padding:15px;">
                            <div class="col-md-12 col-12 col-lg-12">
                                <div class="table-responsive-lg table-responsive-md table-responsive-sm">


                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th> ID</th>

                                            <th>نوع الشركه</th>
                                            <th> القيمة</th>
                                            <th>نوع </th>
                                            <th> أسم المصروف </th>
                                            <th> السبب</th>
                                            <th> بتاريخ</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($expenses)): ?>
                                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>





                                                    <td class="align-middle"><?php echo e($expense->id); ?>  </td>

                                                    <td class="align-middle"><?php echo $expense->companyId()->first()->name; ?>  </td>
                                                    <td class="align-middle"><?php echo e(number_format($expense->amount)); ?>  </td>
                                                    <td class="align-middle"><?php echo $expense->typeId()->first()->name; ?>  </td>
                                                    <td class="align-middle"><?php echo $expense->expenseId()->first()->name; ?>  </td>
                                                    <td class="align-middle"><?php echo $expense->present()->reason; ?>  </td>


                                                    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($expense->created_at)->format('D d F Y ')); ?></td>


                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="8"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                        <tfoot>

                                        <th>  </th>

                                        <th> </th>
                                        <th><?php echo e(number_format($paginateSum)); ?><h2> </h2></th>
                                        <th>  </th>
                                        <th>   </th>
                                        <th>  </th>
                                        <th> </th>


                                        </tfoot>
                                    </table>





                                </div>
                            </div>
                        </div>
                        <div style="background-color: #eee;padding:15px;" id="footer-bg">

                                 <div style="margin:10px 20px;text-align:center;" class="btn-section">
                                <button type="button" class="btn btn-responsive btn_marTop button-alignment btn-info"
                                        data-toggle="button">
                                    <a style="color:#fff;" onclick="javascript:window.print();">
                                        <i class="livicon" data-name="printer" data-size="16" data-loop="true"
                                           data-c="#fff" data-hc="white" style="position:relative;top:3px;"></i>
                                        Print
                                    </a>
                                </button>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets')); ?>/css/invoice.css" />



    <?php echo $__env->yieldPushContent('dashboard_styles'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>



    <script src="<?php echo e(url('assets')); ?>/js/invoice.js"></script>



    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/expense/partials/invoice.blade.php ENDPATH**/ ?>
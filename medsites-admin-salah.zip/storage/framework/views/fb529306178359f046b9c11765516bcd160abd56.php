

<div class="box box-primary">
	<h5 class="card-title">Download all </h5>

	<div class="box-body chart-responsive">

			<canvas id="pieChartUsers"></canvas>

	</div>
</div>


<?php $__env->startPush('dashboard_styles'); ?>
	<style>
		canvas {
			-moz-user-select: none;
			-webkit-user-select: none;
			-ms-user-select: none;
		}
	</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('dashboard_scripts'); ?>

    <script>


			
			var config = {
				type: 'pie', /* pie, doughnut */
				data: <?php echo $usersPerCountry; ?>,
				options: {
					responsive: true,
					legend: {
						display: true,
						position: 'right'
					},
					title: {
						display: false
					},
					animation: {
						animateScale: true,
						animateRotate: true
					}
				}
			};
			
			$(function () {
				var ctx = document.getElementById('pieChartUsers').getContext('2d');
				window.myUsersDoughnut = new Chart(ctx, config);
			});

    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\xampp\htdocs\medsites\resources\views/dashboard/ini/download-per-users.blade.php ENDPATH**/ ?>
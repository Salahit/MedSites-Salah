<tr>




    <td class="align-middle"><?php echo e($importer->users_id()->first()->present()->nameOrEmail); ?>  </td>


    <td class="align-middle"><?php echo $importer->name; ?>  </td>

    <td class="align-middle"><?php echo $importer->order_count; ?>  </td>
    <td class="align-middle"><?php echo $importer->items_count; ?>  </td>


    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($importer->start_at)->format('F Y')); ?></td>


    <td class="text-center align-middle">
        <a href="<?php echo e(route('importer.listImporter') . '?importer=' .$importer->id); ?>"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>




    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/importer/partials/row.blade.php ENDPATH**/ ?>
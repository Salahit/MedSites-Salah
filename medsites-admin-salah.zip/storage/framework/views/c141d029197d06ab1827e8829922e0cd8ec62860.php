<?php $__env->startSection('page-title', 'Add Page'); ?>
<?php $__env->startSection('page-heading', $edit ? $page->name : 'Edit Page'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('pages.index')); ?>">Pages</a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($edit ? trans('app.edit') : trans('app.create')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php if($edit): ?>
    <?php echo Form::open(['route' => ['pages.update', $page->id], 'method' => 'PUT', 'id' => 'pages-form']); ?>

<?php else: ?>
    <?php echo Form::open(['route' => 'pages.store', 'id' => 'pages-form']); ?>

<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <h5 class="card-title">
                    Page  Details
                </h5>
            </div>


            <div class="col-md-4">
                <div class="form-group">
                    <label for="name"> Name </label>
                    <input type="text" class="form-control" id="name"
                           name="name" placeholder="Name" value="<?php echo e($edit ? $page->name : old('name')); ?>">
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="name"> Name Ar </label>
                    <input type="text" class="form-control" id="name_ar"
                           name="name_ar" placeholder="Name Ar" value="<?php echo e($edit ? $page->name_ar : old('name_ar')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="name"> Slug </label>
                    <input type="text" class="form-control" id="slug"
                           name="slug" placeholder="Slug" value="<?php echo e($edit ? $page->slug : old
                           ('slug')); ?>">
                </div>
            </div>


            <div class="col-md-6">
                <div class="form-group"><i class="fas fa-arrow-alt-circle-right"></i>
                    <label for="menu_sort">Menu Sort</label>
                    <?php echo Form::select('menu_sort',['Company' => 'Company' ,'Services' => 'Services','Clients' =>
                    'Clients','Other' => 'Other'  ] , $edit ? $page->menu_sort : '',

                ['class' => 'form-control', 'id' => 'menu_sort']); ?>

                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group"><i class="fas fa-arrow-alt-circle-right"></i>
                    <label for="status"><?php echo app('translator')->getFromJson('app.status'); ?></label>
                    <?php echo Form::select('status', $statuses, $edit ? $page->status : '',
                ['class' => 'form-control', 'id' => 'status']); ?>

                </div>
            </div>



            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_title">Title</label>
                    <textarea name="title"  placeholder="Title"  id="Title" class="form-control"><?php echo e($edit ?
                    $page->title : old
                    ('p_title')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_title">Title Arabic</label>
                    <textarea name="title_ar" placeholder="Title Arabic" id="Title" class="form-control"><?php echo e($edit ?
                    $page->title_ar : old
                    ('title_ar')); ?></textarea>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group">
                    <label for="content">Content </label>
                    <textarea name="content" id="description" rows="5" class="form-control"><?php echo e($edit ?
                    $page->content : old('content')); ?></textarea>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group">
                    <label for="editor">Content Arabic</label>
                    <textarea name="content_ar" id="descriptionar" rows="5" class="form-control"><?php echo e($edit ?
                    $page->content_ar : old('content_ar')); ?></textarea>
                </div>
            </div>



            </div>
        </div>
    </div>


<div class="row">
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">
            <?php echo e($edit ? trans('app.update') : trans('app.create')); ?>

        </button>
    </div>
</div>

</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('design')); ?>/assets/plugins/simditor/styles/simditor.css" />



    <?php echo $__env->yieldPushContent('dashboard_styles'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>



    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/mobilecheck.js"></script>

    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/module.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/hotkeys.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/uploader.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/simditor.js"></script>
    <script type="text/javascript">
        Simditor.i18n = {
            'en': {
                'blockquote': 'Block Quote',
                'bold': 'Bold',
                'code': 'Code',
                'color': 'Text Color',
                'coloredText': 'Colored Text',
                'hr': 'Horizontal Line',
                'image': 'Insert Image',
                'externalImage': 'External Image',
                'uploadImage': 'Upload Image',
                'uploadFailed': 'Upload failed',
                'uploadError': 'Error occurs during upload',
                'imageUrl': 'Url',
                'imageSize': 'Size',
                'imageAlt': 'Alt',
                'restoreImageSize': 'Restore Origin Size',
                'uploading': 'Uploading',
                'indent': 'Indent',
                'outdent': 'Outdent',
                'italic': 'Italic',
                'link': 'Insert Link',
                'linkText': 'Text',
                'linkUrl': 'Url',
                'linkTarget': 'Target',
                'openLinkInCurrentWindow': 'Open link in current window',
                'openLinkInNewWindow': 'Open link in new window',
                'removeLink': 'Remove Link',
                'ol': 'Ordered List',
                'ul': 'Unordered List',
                'strikethrough': 'Strikethrough',
                'table': 'Table',
                'deleteRow': 'Delete Row',
                'insertRowAbove': 'Insert Row Above',
                'insertRowBelow': 'Insert Row Below',
                'deleteColumn': 'Delete Column',
                'insertColumnLeft': 'Insert Column Left',
                'insertColumnRight': 'Insert Column Right',
                'deleteTable': 'Delete Table',
                'title': 'Title',
                'normalText': 'Text',
                'underline': 'Underline',
                'alignment': 'Alignment',
                'alignCenter': 'Align Center',
                'alignLeft': 'Align Left',
                'alignRight': 'Align Right',
                'selectLanguage': 'Select Language',
                'fontScale': 'Font Size',
                'fontScaleXLarge': 'X Large Size',
                'fontScaleLarge': 'Large Size',
                'fontScaleNormal': 'Normal Size',
                'fontScaleSmall': 'Small Size',
                'fontScaleXSmall': 'X Small Size'
            }
        };

        (function() {
            $(function() {
                var $preview, editor, mobileToolbar, toolbar, allowedTags;
                Simditor.locale = 'en';
                toolbar = ['bold','italic','underline','fontScale','color','|','ol','ul','blockquote','table','link'];
                mobileToolbar = ["bold", "italic", "underline", "ul", "ol"];
                if (mobilecheck()) {
                    toolbar = mobileToolbar;
                }


                allowedTags = ['br','span','a','img','b','strong','i','strike','u','font','p','ul','ol','li','blockquote','pre','h1','h2','h3','h4','hr','table'];
                editor = new Simditor({
                    textarea: $('#description'),
                    placeholder: 'Describe what makes the product unique ...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    allowedTags: allowedTags
                });
                editor = new Simditor({
                    textarea: $('#descriptionar'),
                    placeholder: 'صف ما الذي يجعل الممتج فريدا من نوعه...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    allowedTags: allowedTags
                });
                $preview = $('#preview');
                if ($preview.length > 0) {
                    return editor.on('valuechanged', function(e) {
                        return $preview.html(editor.getValue());
                    });
                }
            });
        }).call(this);
    </script>
    <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


    <?php if($edit): ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Page\UpdatePageRequest', '#pages-form'); ?>

    <?php else: ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Page\CreatePageRequest', '#pages-form'); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/pages/add-edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title', 'Add Item'); ?>
<?php $__env->startSection('page-heading', $edit ? $stock->name : 'Edit Item'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('stock.index')); ?>">Item </a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($edit ? trans('app.edit') : trans('app.create')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php if($edit): ?>
    <?php echo Form::open(['route' => ['stock.update', $stock->id], 'method' => 'PUT', 'id' => 'stock-form']); ?>

<?php else: ?>
    <?php echo Form::open(['route' => 'stock.store', 'id' => 'stock-form']); ?>

<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <h5 class="card-title">
                    Item    Details
                </h5>
            </div>
        </div>
        <div class="row">

            <div class="col-md-4">
                <div class="form-group">
                    <label for="name"> Name</label>
                    <input type="text" class="form-control" id="name"
                           name="name" placeholder="name"
                           value="<?php echo e($edit ? $stock->name : old('name')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="importer"> Rate MedSites %</label>
                    <input type="text" class="form-control" id="rate_company"
                           name="rate_company" placeholder="Rate MedSites %"
                           value="<?php echo e($edit ? $stock->rate_company : old('rate_company')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="rate_importer"> Rate Importer %</label>
                    <input type="text" class="form-control" id="rate_importer"
                           name="rate_importer" placeholder="Rate Importer %"
                           value="<?php echo e($edit ? $stock->rate_importer : old('rate_importer')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="company"> Company</label>
                    <input type="text" class="form-control" id="company"
                           name="company" placeholder="Company"
                           value="<?php echo e($edit ? $stock->company : old('company')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="importer"> Importer</label>
                    <input type="text" class="form-control" id="importer"
                           name="importer" placeholder="importer"
                           value="<?php echo e($edit ? $stock->importer : old('importer')); ?>">
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="company"> Price LE</label>
                    <input type="text" class="form-control" id="price"
                           name="price" placeholder="Price LE"
                           value="<?php echo e($edit ? $stock->price : old('price')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="_dollar"> Price Dollar $</label>
                    <input type="text" class="form-control" id="price"
                           name="price_dollar" placeholder="Price Dollar $ "
                           value="<?php echo e($edit ? $stock->price_dollar : old('price_dollar')); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <label for="pay_day_after">Pay Day After</label>
                <input type="text" class="form-control" id="pay_day_after"
                       name="pay_day_after" placeholder="Pay Day after Like 150 Day" value="<?php echo e($edit ?
                           $stock->pay_day_after : old
                           ('pay_day_after')); ?>">
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="status"><?php echo app('translator')->getFromJson('app.status'); ?></label>
                    <?php echo Form::select('status', $statuses, $edit ? $stock->status : '',
                ['class' => 'form-control', 'id' => 'status']); ?>

                </div>
            </div>
        </div>




<div class="row">
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">
            <?php echo e($edit ? 'Update Item' : 'Save Item'); ?>

        </button>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_styles'); ?>

    <?php echo $__env->yieldPushContent('dashboard_styles'); ?>

<style>.pand{padding-top: 35px;} </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>


    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <?php if($edit): ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Stock\UpdateStockRequest', '#stock-form'); ?>

    <?php else: ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Stock\CreateStockRequest', '#stock-form'); ?>

    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/stock/add-edit.blade.php ENDPATH**/ ?>
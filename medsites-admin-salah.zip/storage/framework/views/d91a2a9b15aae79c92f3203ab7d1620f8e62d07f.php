<tr>

    <td class="align-middle">
        <a href="<?php echo e(route('user.show', $filesMail->id)); ?>">
            <?php echo e($filesMail->id ?: trans('app.n_a')); ?>

        </a>
    </td>


    <td class="align-middle"><?php echo $filesMail->byCompanyId()->first()->name; ?>  </td>
    <td class="align-middle"><?php echo e($filesMail->file_name); ?></td>
    <td class="align-middle"><?php echo $filesMail->ItemId()->first()->name; ?>  </td>

    <td class="align-middle"><?php echo $filesMail->CompanyId()->first()->name; ?>  </td>
    <td class="align-middle"><?php echo e($filesMail->moves_count); ?></td>


    <td class="align-middle">
        <?php if($filesMail->status_out_in === 'In'): ?>

            <span class="badge badge-lg badge-success">
 <?php echo e($filesMail->status_out_in); ?>

                <?php else: ?>
                    <span class="badge badge-lg badge-secondary">
 <?php echo e($filesMail->status_out_in); ?> <?php endif; ?>

 </span>

    </td>

    <td class="text-center align-middle">
        <a href="<?php echo e(route('filesMail.show', $filesMail->id) .'?year='.\Carbon\Carbon::now()->format('Y')); ?>"

           class="btn btn-icon eye"
           title="View File"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

        <a href="<?php echo e(route('filesMail.edit', $filesMail->id)); ?>"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('filesMail.delete', $filesMail->id)); ?>"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/filesMail/partials/row.blade.php ENDPATH**/ ?>
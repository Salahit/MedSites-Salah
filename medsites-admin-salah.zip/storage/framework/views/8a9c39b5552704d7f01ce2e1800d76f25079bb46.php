<?php $__env->startSection('page-title', 'License'); ?>
<?php $__env->startSection('page-heading', 'License'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active">
        <a href="<?php echo e(route('license.index')); ?>">Licenses</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card">
    <div class="card-body">

            <form action="" method="GET" id="users-form" class="pb-2 mb-3 border-bottom-light">
            <div class="row my-3 flex-md-row flex-column-reverse">
                <div class="col-md-4 mt-md-0 mt-2">
                    <div class="input-group custom-search-form">
                        <input type="text"
                               class="form-control input-solid"
                               name="search"
                               value="<?php echo e(Input::get('search')); ?>"
                               placeholder="<?php echo app('translator')->getFromJson('app.search_for_licenses'); ?>">

                        <span class="input-group-append">
                                <?php if(Input::has('search') && Input::get('search') != ''): ?>
                                <a href="<?php echo e(route('license.index')); ?>"
                                   class="btn btn-light d-flex align-items-center text-muted"
                                   role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                            <?php endif; ?>
                            <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-search text-muted"></i>
                                </button>
                            </span>
                    </div>
                </div>

                <div class="col-md-2 mt-2 mt-md-0">
                    <?php echo Form::select('status', $statuses, Input::get('status'), ['id' => 'status', 'class' => 'form-control input-solid']); ?>

                </div>
                <div class="col-md-2 mt-2 mt-md-0">
                <button type="button"  class="btn btn-primary btn-rounded  float-right " data-toggle="collapse"
                        data-target="#add_wrapper">
                    <i class="fas fa-plus mr-2"></i>    Add
                </button>
                </div>
            </div>
        </form>

        <?php echo Form::open(['route' => 'license.store', 'id' => 'License-form' , 'class' =>'pb-2 mb-3
                border-bottom-light']); ?>

        <div id="add_wrapper"  class="row my-3 flex-md-row flex-column-reverse collapse" >



            <div class="col-sm-3">
                <div class="form-group">
                    <label for="Email">Email</label>
                    <input type="text" name="user_email" id="email" class="form-control input-solid">
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label for="Product">Product</label>
                    <select name="product_id" class="form-control input-solid" >
                        <option  value="">-- Select --</option>
                        <option  value=30102 >HospitalGate</option>
                        <option  value=10001 >ClinicGate</option><option  value=50014 >VeterinaryGate</option><option  value=90000 >BodycareGate</option><option  value=70006 >CompanyGate</option><option  value=20001 >RestaurantGate</option><option  value=9856 >LiverCancerME</option><option  value=7854 >Hemophilia</option><option  value=3256 >PAP0</option><option  value=9652 >PAP</option><option  value=7733 >PAP_Arabic</option><option  value=2486 >PAP_French</option><option  value=2211 >PSORSA</option><option  value=2212 >PSO</option><option  value=9632 >PSO_Arabic</option><option  value=9512 >PSO_French</option><option  value=7524 >MDbay</option><option  value=5610 >HCCScreening</option><option  value=8888 >SubmitterGate</option><option  value=2525 >PageRankGate</option><option  value=2501 >TubeGate</option><option  value=1199 >LikesBay</option><option  value=2213 >CRF_RA</option></select>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label for="Version">Version</label>
                    <select name="version_id" class="form-control input-solid" >
                        <option  value="">-- Select --</option>
                        <option  value=JBNA08 >Basic</option><option  value=PSTAM08 >Standard</option><option  value=KASD08 >Advanced</option></select>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label for="License No">License No</label>
                    <input type="number" name="no_lisens" id="replyNumber" data-bind="value:replyNumber"
                           class="form-control
                    input-solid"/>
                </div>
            </div>


            <div class="col-sm-3">
                <div class="form-group">
                    <input type="submit" name="send" id="send" value="Creat License" class="btn
                    btn-primary">
                </div>
            </div>

        </div>
        <?php echo e(Form::close()); ?>

        <div class="table-responsive" id="users-table-wrapper">
            <table class="table table-borderless table-striped">
                <thead>
                <tr>

                    <th class="text-center min-width-150"><?php echo app('translator')->getFromJson('app.action'); ?></th>
                    <th >User</th>
                    <th class="text-center min-width-30"><i class="fas fa-check-circle"></i></th>
                    <th >Computer ID</th>
                    <th>Version</th>
                    <th>Date Created</th>
                    <th class="min-width-80"><?php echo app('translator')->getFromJson('app.status'); ?></th>

                </tr>
                </thead>
                <tbody>
                    <?php if(count($licenses)): ?>
                        <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('license.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php echo $licenses->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo JsValidator::formRequest('MedSites\Http\Requests\License\CreateLicenseRequest', '#License-form'); ?>


    <script>
        $("#status").change(function () {
            $("#users-form").submit();
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/license/list.blade.php ENDPATH**/ ?>
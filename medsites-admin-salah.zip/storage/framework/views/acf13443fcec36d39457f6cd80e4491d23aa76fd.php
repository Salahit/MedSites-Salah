<tr>

    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($stockRow->start_at)->format('m')); ?>





    </td>
    <td class="align-middle"><?php echo e(number_format($stockRow->total_month)); ?></td>
    <td class="align-middle"><?php echo e(number_format($stockRow->stock)); ?></td>

    <?php




 if($yearAverage){
     $avg = $yearAverage->average  / 12 ;
  $percent_members = round(( $stockRow->total_month / $avg) * 100);
 }else {
     $percent_members = 0 ;
 }

    ?>
    <td class="align-middle"><?php echo e($percent_members); ?>  % </td>



    <td class="align-middle"><?php echo e($stockRow->importer()->first()->name); ?>   </td>



    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($stockRow->start_at)->format('F Y')); ?></td>
    <td class="align-middle"><?php echo e($stockRow->users_id()->first()->present()->nameOrEmail); ?>  </td>


    <td class="text-center align-middle" >
        <div class="dropdown show d-inline-block">
            <a class="btn btn-icon"
               href="#" role="button" id="dropdownMenuLink"
               data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-edit"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-left  " aria-labelledby="dropdownMenuLink" style="width:
            500px" >


                <?php echo Form::open(['route' => ['stock.editStock', $stockRow->id], 'method' => 'PUT', 'id' =>
                   'stockEdit-form']); ?>

                <input type="hidden" value="<?php echo e($stock->id); ?>" name="item_id" >
                <input type="hidden" value="<?php echo e($stockRow->importer_id); ?>" name="importer_id" >
                <div class="col-md-12 mt-md-0 mt-1">
                    <div class="row my-1 flex-md-row flex-column-reverse">
                        <div class="col-md-6 mt-md-0 mt-1">


                                Sales <input type="text" class="form-control input-solid" id="total_month"
                                             name="total_month" placeholder="Total month "
                                             value="<?php echo e($stockRow->total_month); ?>">

                        </div>




                        <div class="col-md-6 mt-3 mt-md-1">
                            Stock <input type="text" class="form-control input-solid"  id="total_month"
                                         name="stock" placeholder="Total Stock "
                                         value="<?php echo e($stockRow->stock); ?>">

                        </div>
                        <div class="col-md-6 mt-3 mt-md-1">
                            <input type="date" name="start_at"  id="start_at" class="form-control input-solid"  value="<?php echo e($stockRow->start_at); ?>">


                        </div>

                        <div class="col-md-6 mt-3 mt-md-1">
                            <button type="submit" class="btn btn-primary">
                                Save
                            </button>
                        </div>
                    </div>





                <?php echo Form::close(); ?>

                </div>
            </div>
        </div>




    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/stock/partials/rowStock.blade.php ENDPATH**/ ?>
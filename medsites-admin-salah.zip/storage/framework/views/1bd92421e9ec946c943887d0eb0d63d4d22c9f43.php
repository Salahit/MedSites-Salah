<tr>

    <td class="align-middle">
        <a href="<?php echo e(route('importer.show', $importer->id)); ?>">
            <?php echo e($importer->id ?: trans('app.n_a')); ?>

        </a>
    </td>


    <td class="align-middle"><?php echo e($importer->users_id()->first()->present()->nameOrEmail); ?>  </td>
    <td class="align-middle"><?php echo e($importer->importer()->first()->name); ?>  </td>
    <td class="align-middle"><?php echo e($importer->items_id()->first()->name); ?>  </td>
    <td class="align-middle"><?php echo e(number_format($importer->total_stock)); ?>  </td>







    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($importer->start_at)->format('F Y')); ?></td>


    <td class="text-center align-middle">
        <div class="dropdown show d-inline-block">
            <a class="btn btn-icon"
               href="#" role="button" id="dropdownMenuLink"
               data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-edit"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                <div class="col-md-12 mt-md-0 mt-1">

                    <?php echo Form::open(['route' => ['importer.editImporter', $importer->id], 'method' => 'PUT', 'id' =>
                    'importerEdit-form']); ?>


                    <input type="hidden" value="<?php echo e($importer->importer_id); ?>" name="importer_id" >
                    <div class="form-group my-3">
                        <input type="text" class="form-control" id="total_stock"
                               name="total_stock"
                               value="<?php echo e($importer->total_stock); ?>">
                    </div>
                    <div class="form-group my-3">
                        <?php echo Form::select('status', [ 'Active'=>'Active','Banned'=>'Banned']     ,$importer->status,
                   ['id' => 'status', 'class' => 'form-control input-solid']); ?>      </div>


                    <div class="form-group my-3">
                        <button type="submit" class="btn btn-primary">
                            Save
                        </button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>




    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/importer/partials/row-importer.blade.php ENDPATH**/ ?>
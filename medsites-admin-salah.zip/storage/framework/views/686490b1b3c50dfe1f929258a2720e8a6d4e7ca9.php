<?php echo Form::open(['route' => 'stock.sendEmailStock', 'id' => 'Average-form']); ?>

<input type="hidden" value="<?php echo e($stock->id); ?>" name="item_id" >
<?php if($getLastMonthValue): ?>
<input type="hidden" value="<?php echo e(number_format($getLastMonthValue->total_month)); ?> " name="monthVal" >
<input type="hidden" value="<?php echo e(\Carbon\Carbon::parse($getLastMonthValue->start_at)->format('F Y')); ?> "
       name="month_date" >
<?php endif; ?>
<?php if(count($lastMonth)): ?>



<textarea name="sales" id="note" class="form-control" style="display: none;" >

     <h1> <?php echo e($stock->name); ?> </h1>

    <strong>Sales Month :  </strong> <br>
  <?php $__currentLoopData = $lastMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e(\Carbon\Carbon::parse
($Month->start_at)->format('Y F')); ?>

<?php echo e($Month->Importer()->first()->name); ?> :<strong> <?php echo e(number_format($Month->total_month)); ?></strong><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(count($stockImporter)): ?>
  <strong>Stock  </strong> <br>
 <?php $__currentLoopData = $stockImporter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Importer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($Importer->status == 'Active'): ?>
  <?php echo e($Importer->Importer()->first()->name); ?> : <strong> <?php echo e(number_format($Importer->total_stock)); ?></strong><br>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



 <strong>Sales </strong> <br>
 <?php $__currentLoopData = $stockImporter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Importer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($Importer->status == 'Active'): ?>
<?php echo e($Importer->Importer()->first()->name); ?> : <strong> <?php echo e(number_format($Importer->balance)); ?></strong><br>
            <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
<br>
  Total Year :     <strong> <?php echo e(number_format($sumByYear)); ?></strong> <br>
  Total Sales : <strong> <?php echo e(number_format($countOfStockAllYear)); ?></strong><br>


    <?php if($yearAverage): ?>
        <br>
      Average of <?php echo e($yearAverage->years); ?> <strong><?php echo e(number_format($yearAverage->average)); ?></strong>
        <br>
   Average of Month <strong> <?php echo e(number_format($yearAverage->average / 12 )); ?></strong>
   <?php else: ?>
        No Average
    <?php endif; ?>


</textarea>



<input type="hidden" value="<?php echo e($stock->name); ?>" name="name" >
<button type="submit" class="btn btn-icon "><i class="fas fa-envelope fa-lg"></i></button>





<?php endif; ?>

<?php echo Form::close(); ?>

<?php /**PATH C:\xampp\htdocs\medsites\resources\views/stock/partials/fromSendEmailStock.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title', 'Orders Invoice' ); ?>
<?php $__env->startSection('page-heading',  'Orders Invoice '    ); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('order.indexInvoiceOrders' )); ?>"> Orders   </a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('order.partials.search-invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th>Invoice ID </th>
                        <th>Amount </th>
                        <th> </th>

                        <th>Price Dollar</th>
                        <th> </th>
                        <th>Order ID</th>
                        <th>Arrival At</th>


                    </tr>
                    </thead>
                    <tbody>
                        <?php if(count($invoices)): ?>
                            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('order.partials.row-page-invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>

                    <th> </th>

                    <th><?php echo e(number_format($InvoiceOrdersSum)); ?> </th>


                    <th> </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                <?php echo $invoices->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
        $("#item").change(function () {
            $("#users-form").submit();
        });



    </script>


    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/invoice-orders.blade.php ENDPATH**/ ?>

    <h5 class="card-title">Sales  of all Years</h5>

		<div class="chart" id="barChartUsers" style="height: 300px;width:100% ;"></div>





<?php $__env->startPush('dashboard_styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('dashboard_scripts'); ?>
    <script>
        $(function () {
            "use strict";
        
            // USERS STATS
            var area = new Morris.Bar({
                element: 'barChartUsers',
                resize: true,
                data: <?php echo $stockPerMonth; ?>,
                xkey: 'y',
                ykeys: ['activated'],
                labels: ['Total'],
                lineColors: ['#88c16d','#88c16d'],
                hideHover: 'auto',
                parseTime: true
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/stock/ini/latest-users.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title', trans('app.registration_calendar') ); ?>
<?php $__env->startSection('page-heading',  'Calendar'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('registration.index')); ?>"><?php echo app('translator')->getFromJson('app.registration_calendar'); ?></a>
    </li>
    <li class="breadcrumb-item active">
        Calendar
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('registration.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id='calendar'></div>


            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-borderless table-striped">

                    <tbody>
                    <?php if(count($registrationEventsList)): ?>
                        <?php $__currentLoopData = $registrationEventsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $EventsLis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('registration.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php echo $registrationEventsList->render(); ?>

    </div>
    </div>

    <form method="GET" id="get_edit_form" class="form-horizontal">
        <input type="hidden" class="form-control" id="get_id_edit_id"  name="id"  >

    </form>

    <!-- Modal -->
    <div class="modal fade" id="formModalAddType"  role="dialog" >
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Type</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="AddType_form" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <span id="form_result_add_type"></span>
                        <div class="form-group">
                            <label for="AddType">New Type Name</label>
                            <input type="text" class="form-control" id="name"
                                   name="name" placeholder="Type Name" value="<?php echo e(old ('name')); ?>">

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="hidden" name="actionAddType" id="actionAddType" />
                        <input type="hidden" name="hidden_id" id="hidden_id" />
                        <input type="submit" name="action_button" id="AddType_form" class="btn btn-warning" value="Add" />

                    </div>
                </form>
            </div>
        </div>
    </div>






    <div class="modal fade" id="formModal"  role="dialog" >
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Record</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>


                    <?php echo Form::open(['route' => 'registration.store', 'files' => true, 'id' => 'user-form']); ?>

                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <span id="form_result"></span>
                        <div class="form-group">
                            <div class="row my-0 flex-md-row flex-column-reverse">
                                <div class="col-md-3 mt-md-0 mt-0">
                                    <label for="by_company">Item</label>
                                </div>

                            </div>

                            <?php echo Form::select('item_id', [''=>'Select'] +  $listsAddItem   ,Input::get('item_id'),
                                               ['id' => 'add_item_id', 'class' => 'form-control input-solid']); ?>




                        </div>
                        <div class="form-group">
                            <label for="colorss"> Type Event</label>




                            <?php echo Form::select('type_id', [''=>'Type'] +  $listsType   ,Input::get('type'),
                            ['id' => 'by_type', 'class' => 'form-control input-solid']); ?>

                        </div>
                        <div class="form-group">
                            <label for="from_company">Title</label>
                            <input type="text" class="form-control" id="title"
                                   name="title" placeholder="Title" value="<?php echo e(old ('title')); ?>">

                        </div>
                        <div class="form-group">
                            <label for="Color">Color </label>
                            <input type="text" class="form-control" id="color"
                                   name="colorss"   value="<?php echo e(old ('title')); ?>">

                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" class="form-control"><?php echo e(old('description')); ?></textarea>
                        </div>


                        <input type="text" class="form-control" id="start_id"  name="start"  >


                        </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="hidden" name="action" id="action" />
                        <input type="hidden" name="hidden_id" id="hidden_id" />
                        <input type="submit" name="action_button" id="action_button" class="btn btn-warning" value="Add" />

                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="formModalAddItem"  role="dialog" >
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Record</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="AddItem_form" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <span id="form_result_add_item"></span>
                        <div class="form-group">
                            <label for="from_company">New Item</label>
                            <input type="text" class="form-control" id="name"
                                   name="name" placeholder="New Item" value="<?php echo e(old
                           ('name')); ?>">
                        </div>
                        </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="hidden" name="actionAddCompany" id="action" />
                        <input type="hidden" name="hidden_id" id="hidden_id" />
                        <input type="submit" name="action_button" id="action_buttonAddItem" class="btn btn-warning" value="Add" />

                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php if(Input::has('id') && Input::get('id') != ''): ?>
       <?php
                               $envet  = \DB::table('registration_events')->where('id', Input::get('id'))->first() ;




                                       ?>

       <div class="modal fade" id="editModal"  role="dialog" >
           <div class="modal-dialog modal-dialog-centered" role="document">
               <div class="modal-content">
                   <div class="modal-header">
                       <h5 class="modal-title">Edit Record</h5>
                       <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                       </button>
                   </div>
                   <form method="post" id="edit_form" class="form-horizontal" enctype="multipart/form-data">

                       <?php echo csrf_field(); ?>
                       <div class="modal-body">
                           <span id="form_edit_result"></span>
                           <div class="form-group">
                               <div class="row my-0 flex-md-row flex-column-reverse">
                                   <div class="col-md-3 mt-md-0 mt-0">
                                       <label for="by_company">Item</label>
                                   </div>
                                   <div class="col-md-2 mt-md-0 mt-0">
    <span class="input-group-append">
               <button class="btn btn-light" type="button" id="AddItem_record">

                                    <i class="fas fa-plus-circle text-muted"></i>

                                   </button>
                               </span>
                                   </div>
                               </div>

                               <?php echo Form::select('item_id', [''=>'Select'] +  $listsAddItem   ,$envet->item_id ,
                                                  ['id' => 'add_item_id', 'class' => 'form-control input-solid']); ?>




                           </div>
                           <div class="form-group">
                               <label >Type Event</label>


                               <?php echo Form::select('type_id', [''=>'Type'] +  $listsType   , $envet->type_id,
  ['id' => 'by_type', 'class' => 'form-control input-solid']); ?>



                           </div>
                           <div class="form-group">
                               <label for="from_company">Title</label>
                               <input type="text" class="form-control"
                                      name="title" placeholder="Title" value="<?php echo e($envet->title); ?>" >

                           </div>
                           <div class="form-group">
                               <label for="Color">Color </label>
                               <input type="text" class="form-control" id="color2"
                                      name="colorss"  value="<?php echo e($envet->colorss); ?>" >

                           </div>
                           <div class="form-group">
                               <label for="description">Description</label>
   <textarea name="description"  class="form-control"><?php echo e($envet->description); ?></textarea>


                           </div>
                           <div class="form-group">
                               <label for="start">Start</label>


                               <input name="start" class="form-control" type="text"
                                      value="<?php echo e(\Carbon\Carbon::parse($envet->start)->format('Y-m-d')); ?>">


                           </div>


                           <input type="hidden" class="form-control" value="<?php echo e($envet->id); ?>"  name="id"  >


                       </div>
                       <div class="modal-footer">
                           <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                           <input type="hidden" name="action" id="action" />
                           <input type="hidden" name="hidden_id" id="hidden_id" />
                           <input type="submit" name="edit_edit" id="action_edit" class="btn btn-warning" value="Add" />

                       </div>
                   </form>
               </div>
           </div>
       </div>
    <?php endif; ?>
   <?php $__env->stopSection(); ?>
   <?php $__env->startSection('scripts'); ?>


       <?php echo JsValidator::formRequest('MedSites\Http\Requests\Registration\CreateRegistrationRequest', '#user-form'); ?>

       <script>

           <?php if(Input::has('id') && Input::get('id') != ''): ?>
           $('.modal-title').text("Edit Record");
           $('#action_edit').val("Add");
           $('#action').val("Add");

           $('#editModal').modal('show');

           <?php endif; ?>

           $('#action_edit').click(function(){
               $("#edit_form").submit();
           });
           $('#create_record').click(function(){
               $('.modal-title').text("Add New Record");
               $('#action_button').val("Add");
               $('#action').val("Add");
               $('#formModal').modal('show');
           });
           $('#sample_form').on('submit', function(event){

               event.preventDefault();
               if($('#action').val() == 'Add')
               {
                   $.ajax({
                       url:"<?php echo e(route('registration.createQuickEvent')); ?>",
                       method:"POST",
                       data: new FormData(this),
                       contentType: false,
                       cache:false,
                       processData: false,
                       dataType:"json",
                       success:function(data)
                       {
                           var html = '';
                           if(data.errors)
                           {
                               html = '<div class="alert alert-danger">';
                               for(var count = 0; count < data.errors.length; count++)
                               {
                                   html += '<p>' + data.errors[count] + '</p>';
                               }
                               html += '</div>';
                           }
                           if(data.success)
                           {
                               html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                               $('#sample_form')[0].reset();
                              //  $("#calendar").load("#calendar");

                               location.reload('#calendar');

                           }
                           $('#form_result').html(html);

                       }
                   })
               }




           });
           $('#AddItem_record').click(function(){
               $('.modal-title').text("Add New Record");
               $('#action_buttonAddItem').val("Add");
               $('#action').val("Add");
               $('#formModalAddItem').modal('show');
           });
           $('#AddItem_form').on('submit', function(event){

               event.preventDefault();
               if($('#action').val() == 'Add')
               {
                   $.ajax({
                       url:"<?php echo e(route('filesMail.storeAddItem')); ?>",
                       method:"POST",
                       data: new FormData(this),
                       contentType: false,
                       cache:false,
                       processData: false,
                       dataType:"json",
                       success:function(data)
                       {
                           var html = '';
                           if(data.errors)
                           {
                               html = '<div class="alert alert-danger">';
                               for(var count = 0; count < data.errors.length; count++)
                               {
                                   html += '<p>' + data.errors[count] + '</p>';
                               }
                               html += '</div>';
                           }
                           if(data.success)
                           {
                               html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                               $('#AddItem_form')[0].reset();
                               // $("#user_table").load(" #user_table");

                               $('#add_item_id').append('<option value = '+data.id+'>'+data.name+'</option>');


                           }
                           $('#form_result_add_item').html(html);
                           location.reload('#add_item_id');
                       }
                   })
               }




           });


           $('#create_record_type').click(function(){
               $('.modal-title').text("Add New Type");
               $('#action_buttonAddType').val("Add");
               $('#actionAddType').val("Add");
               $('#formModalAddType').modal('show');
           });
           $('#AddType_form').on('submit', function(event){

               event.preventDefault();
               if($('#actionAddType').val() == 'Add')
               {
                   $.ajax({
                       url:"<?php echo e(route('registration.storeType')); ?>",
                       method:"POST",
                       data: new FormData(this),
                       contentType: false,
                       cache:false,
                       processData: false,
                       dataType:"json",
                       success:function(data)
                       {
                           var html = '';
                           if(data.errors)
                           {
                               html = '<div class="alert alert-danger">';
                               for(var count = 0; count < data.errors.length; count++)
                               {
                                   html += '<p>' + data.errors[count] + '</p>';
                               }
                               html += '</div>';
                           }
                           if(data.success)
                           {
                               html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                               $('#AddItem_form')[0].reset();
                               // $("#user_table").load(" #user_table");

                               $('#by_type').append('<option value = '+data.id+'>'+data.name+'</option>');


                           }
                           $('#form_result_add_type').html(html);

                       }
                   })
               }




           });



           $('#edit_form').on('submit', function(event){

               event.preventDefault();
               if($('#action').val() == 'Add')
               {
                   $.ajax({
                       url:"<?php echo e(route('registration.editQuickEvent')); ?>",
                       method:"POST",
                       data: new FormData(this),
                       contentType: false,
                       cache:true,
                       processData: false,
                       dataType:"json",
                       success:function(data)
                       {
                           var html = '';
                           if(data.errors)
                           {
                               html = '<div class="alert alert-danger">';
                               for(var count = 0; count < data.errors.length; count++)
                               {
                                   html += '<p>' + data.errors[count] + '</p>';
                               }
                               html += '</div>';
                           }
                           if(data.success)
                           {
                               html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                               $('#edit_form')[0].reset();
                               //  $("#calendar").load("#calendar");

                               window.location = "<?php echo e(url('/admin/registration/calendar')); ?>";

                           }
                           $('#form_edit_result').html(html);

                       }
                   })
               }




           });
       </script>

           <script>

               document.addEventListener('DOMContentLoaded', function() {
                   var calendarEl = document.getElementById('calendar');

                   var calendar = new FullCalendar.Calendar(calendarEl, {
                       plugins: [ 'interaction', 'dayGrid', 'timeGrid', 'list' ],
                       header: {
                           left: 'prev,next today',
                           center: 'title',
                           right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
                       },



                       defaultDate: "<?php echo e($lastUpdateDate != '' ? \Carbon\Carbon::parse
                       ($lastUpdateDate->start)->format('Y-m-d') : date("Y-m-d")); ?>",

                       editable: false,

                       selectable: true,
                       selectHelper: true,
                       displayEventTime: false,
                       showNonCurrentDates: false,
                       eventRender: function(info) {
                           $(info.el).tooltip({
                               title: info.event.extendedProps.description,
                               placement: "top",
                               trigger: "hover",
                               container: "body"
                           });
                       },
                       dateClick: function(info) {

                           $('.modal-title').text("Add New Record");
                           $('#action_button').val("Add");
                           $('#action').val("Add");

                           $('#start_id').val(info.dateStr);


                           $('#formModal').modal('show');




                       },
                       navLinks: true, // can click day/week names to navigate views

                       events : [
                               <?php $__currentLoopData = $registrationEventsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           {
                               id: <?php echo e($appointment->id); ?>,
                               title : '<?php echo $appointment->ItemId()->first()->name; ?> <?php echo e($appointment->title); ?>',
                               start : '<?php echo e($appointment->start); ?>',
                               description : '<?php echo $appointment->UsersId()->first()->present()->nameOrEmail; ?> -  <?php echo e(str_replace(array("\n", "\r"), ' ', $appointment->description)); ?>',
                           //  url: '<?php echo e(url('/')); ?>',
                               backgroundColor: '<?php echo e($appointment->colorss); ?>',
                              borderColor: '#000000',
                               textColor: '#fff',
                               <?php if($appointment->end): ?>
                               end: '<?php echo e($appointment->end); ?>',
                               <?php endif; ?>
                           },
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       ],
                       eventLimit: true,
                       editable: false,
                       editable: true,
                       hiddenDays: [ 5, 6 ],
                       eventClick: function(info) {



                           $('#get_id_edit_id').val(info.event.id);



                           $("#get_edit_form").submit();

                       }

                   });

                   calendar.render();
               });

               $("#year").change(function () {
                   $("#users-form").submit();
               });

               $("#month").change(function () {
                   $("#users-form").submit();
               });
               $("#type").change(function () {
                   $("#users-form").submit();
               });
               $("#item").change(function () {
                   $("#users-form").submit();
               });
               $(function () {
                   $('select').each(function () {
                       $(this).select2({

                           theme: 'bootstrap4 ',

                       });
                   });
               });



               $('#color').colorpicker({});
               $('#color2').colorpicker({});
       </script>




   <?php $__env->startSection('after_styles'); ?>
       <link rel="stylesheet" href="<?php echo url('assets/plugins/fullcalendar/packages/core/main.css'); ?>">
       <link rel="stylesheet" href="<?php echo url('assets/plugins/fullcalendar/packages/timegrid/main.css'); ?>">
       <script src="<?php echo url('assets/js/popper.min.js'); ?>"></script>
       <link rel="stylesheet" href="<?php echo url('assets/plugins/fullcalendar/packages/list/main.css'); ?>">
       <link rel="stylesheet" href="<?php echo url('assets/plugins/fullcalendar/packages/core/main.css'); ?>">

       <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.3.3/css/bootstrap-colorpicker.min.css" rel="stylesheet">



       <style>

           /*
           i wish this required CSS was better documented :(
           https://github.com/FezVrasta/popper.js/issues/674
           derived from this CSS on this page: https://popper.js.org/tooltip-examples.html
           */
           #calendar {
               max-width: 100%;

           }

       </style>


   <?php $__env->stopSection(); ?>

   <?php $__env->startSection('after_scripts'); ?>


       <script src="<?php echo url('assets/plugins/fullcalendar/packages/moment/moment.js'); ?>"></script>
       <script src="<?php echo url('assets/plugins/fullcalendar/packages/core/main.js'); ?>"></script>
       <script src="<?php echo url('assets/plugins/fullcalendar/packages/interaction/main.js'); ?>"></script>
       <script src="<?php echo url('assets/plugins/fullcalendar/packages/daygrid/main.js'); ?>"></script>
       <script src="<?php echo url('assets/plugins/fullcalendar/packages/timegrid/main.js'); ?>"></script>
       <script src="<?php echo url('assets/plugins/fullcalendar/packages/list/main.js'); ?>"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.3.3/js/bootstrap-colorpicker.min.js"></script>

       <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
   <?php $__env->stopSection(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/registration/index.blade.php ENDPATH**/ ?>
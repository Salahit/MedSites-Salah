<tr>





    <td class="align-middle"><?php echo e($expense->id); ?>  </td>

    <td class="align-middle"><?php echo $expense->companyId()->first()->name; ?>  </td>
    <td class="align-middle"><?php echo e(number_format($expense->amount)); ?>  </td>
    <td class="align-middle"><?php echo $expense->typeId()->first()->name; ?>  </td>
    <td class="align-middle"><?php echo $expense->expenseId()->first()->name; ?>  </td>
    <td class="align-middle"><?php echo $expense->present()->reason; ?>  </td>
    <td class="align-middle"> <?php echo $expense->present()->pictureexpenses; ?></td>

    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($expense->created_at)->format('D d F Y ')); ?></td>




    <td class="text-center align-middle">


            <?php if(\Carbon\Carbon::parse($expense->created_at)->format('m') == \Carbon\Carbon::now()->format('m') and
\Carbon\Carbon::parse($expense->created_at)->format('Y') == \Carbon\Carbon::now()->format('Y') ): ?>

        <a href="<?php echo e(route('expenses.edit', $expense->id)); ?>"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('expenses.delete', $expense->id)); ?>"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    <?php endif; ?>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/expense/partials/row.blade.php ENDPATH**/ ?>
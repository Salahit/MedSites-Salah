<tr>

    <td><?php echo e(number_format($invoice->invoice_total)); ?> $ </td>

    <td>  <span class="badge badge-lg badge-info">
<?php echo e(number_format($invoice->rate_invoice)); ?> %

        </span>
    </td>


    <td><?php echo e(number_format($invoice->price_dollar)); ?> L.E </td>


    <td>
        <?php echo e(\Carbon\Carbon::parse($invoice->arrival_at)->format('Y F  d D')); ?>


    </td>

    <td class="text-center align-middle">

        <a href="<?php echo e(route('order.edit', $invoice->id)); ?>"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('order.deleteInvoice', $invoice->id)); ?>"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/partials/rowInvoice.blade.php ENDPATH**/ ?>
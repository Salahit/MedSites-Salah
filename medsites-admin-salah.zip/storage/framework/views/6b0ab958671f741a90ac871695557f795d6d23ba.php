<div class="col-lg-12 content-box layout-section">
    <div class="row row-featured">
        <div class="col-lg-12 box-title">
            <div class="inner">
                <h2>
                    <span class="title-3"><?php echo app('translator')->getFromJson('frontLog.Price_List'); ?>  <?php echo $product['p_name'.langIsAr()]; ?>  <span
                                style="font-weight: bold;">US$</span></span>
                    <br />
                        (<?php echo app('translator')->getFromJson('frontLog.License_price'); ?></h2>


            </div>
        </div>

        <table class="table table-hover table-bordered" style="text-align:center;padding-left:200px;
        padding-right:200px; padding-top: 0px;margin-top: 0px;">
            <thead>
            <tr class="active">
                <th><center><h3>#</h3><p class="text-muted text-sm">-</p></center></th>
           <?php if(settings('price_standard_on') == 'Active'): ?><th><center><h3>Standard</h3><p class="text-muted
           text-sm">Perfectfor larger operations.  </p></center></th>
                <?php endif; ?>


                <th><center><h3>Advanced</h3><p class="text-muted text-sm">Perfect for those who want software.</p></center></th>

            </tr>
            </thead>
            <tbody>

            <?php if(count($prices)): ?>
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h3>    <?php echo $price->name; ?></h3>

                    <?php if($price->status == "Active"): ?>
            <tr>
                <td><h3><?php echo $price->numbers; ?></h3>
                </td>

                <?php if(settings('price_standard_on') == 'Active'): ?>
                    <td>
                    <?php if($price->standard_status == "Active"): ?>
                    <h2 style="padding:0px;width:100%px"><?php echo e($price->price_standard); ?>$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="16" class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value="<?php echo e($price->product_id_standard); ?>" />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
                <td>

                    <h2 style="padding:0px;width:100%px"><?php echo e($price->price_advanced); ?>$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="16"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id'  value="<?php echo $price->product_id_advanced; ?>"  />
                        <input type='hidden' name='quantity' value='1' />
                    </form>

                </td>


            </tr>
                    <?php endif; ?>





                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>

                <em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em>

            <?php endif; ?>


            </tbody>
        </table>
        <?php if(settings('price_support_updates_on') == 'Active'): ?>

        <table class="table table-hover table-bordered" style="text-align:center;padding-left:200px;
        padding-right:200px; padding-top: 0px;margin-top: 0px;">
            <thead>
        <tr>
            <td colspan="5" align="left" style="padding-left:20px;" class="active"><b>Support & Updates</b></td>
        </tr>
        <tr>
            <td>Support & Updates</td>

            <td><?php echo e(settings('support_updates_standard_price')); ?>$</td>
            <td><?php echo e(settings('support_updates_advanced_price')); ?>$</td>

        </tr>

        <tr><td></td>

            <td>
                <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                    <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                    <input type='hidden' name='sid' value='146793' />
                    <input type='hidden' name='product_id' value=<?php echo e(settings('support_updates_standard_id')); ?> />
                    <input type='hidden' name='quantity' value='1' />
                </form>
            </td>
            <td> <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                    <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                    <input type='hidden' name='sid' value='146793' />
                    <input type='hidden' name='product_id' value='<?php echo e(settings('support_updates_advanced_id')); ?>' />
                    <input type='hidden' name='quantity' value='1' />
                </form></td>

        </tr>
            </thead></table>

            <?php endif; ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\medsites\resources\views/front/products/price/price.blade.php ENDPATH**/ ?>
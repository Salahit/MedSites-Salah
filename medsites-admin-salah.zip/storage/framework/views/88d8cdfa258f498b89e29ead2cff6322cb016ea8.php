<?php $fullUrl = rawurldecode(url(\Illuminate\Support\Facades\Request::getRequestUri())); ?>
<?php $__env->startSection('content'); ?>

<div class="main-container"  <?php if(direction()== 'rtl'): ?> style="direction:rtl;" <?php endif; ?> >
        <div class="container">
            <ol class="breadcrumb pull-left " >
                <li><a href="/"><i class="icon-home fa"></i></a></li>
                <li>
                    <a href="#">
                        <?php echo app('translator')->getFromJson('frontLog.Products'); ?>
                    </a>
                </li>

                <li class="active"><?php echo $product['p_name'.langIsAr()]; ?></li>
            </ol>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-9 page-content col-thin-right">

                    <div class="inner inner-box ads-details-wrapper">

                        <h2 class="enable-long-words">
                            <strong>
                                <a href="#" title="Medical Rep">
                                    <?php echo $product['p_name'.langIsAr()]; ?>                               </a>
                            </strong>
                            <small class="label label-default adlistingtype"><?php echo app('translator')->getFromJson('frontLog.since'); ?> <?php echo e($product->p_since); ?></small>
                        </h2>
                        <span class="info-row">
							<span class="date"> <i class=" icon-clock"> </i> <?php echo app('translator')->getFromJson('frontLog.since'); ?> <?php echo e($product->p_since); ?>

                            </span> -&nbsp;
							<span class="category"><a target="_blank" href="<?php echo e($product->p_manual_url); ?>"><i
                                            class="fa fa-question-circle"></i> <?php echo app('translator')->getFromJson('frontLog.Training_Help_Manual'); ?>
                                </a></span> -&nbsp;
							<span class="item-location"><a target="_blank" href="<?php echo e($product->p_pdf_url); ?> ">
                              <i class="fa fa-file"></i> <?php echo app('translator')->getFromJson('frontLog.Download_Brochure'); ?></a> </span>

							 <span class="category"> - -

    <a target="_blank" href="<?php echo e(url('download')); ?>/<?php echo e($product->p_name); ?>/<?php echo e($product->id); ?>"><i class="fa
    fa-download"></i> <?php echo app('translator')->getFromJson('frontLog.Download'); ?> </a></span>
						</span>

                        <h2 class="title-3">
                            <?php echo $product['p_nc_name'.langIsAr()]; ?>  </h2>
                        <h1 class="pricetag"><?php echo e($product->f_price); ?></h1>
                        <h3>
                            <?php echo $product['p_description'.langIsAr()]; ?>   </h3>

                        <center>
                            <div class="item">

     <span class="item-carousel-thumb center">
    <img src="<?php echo e(url('design')); ?>/images/products/<?php echo e($product->p_name); ?>.png" alt="<?php echo e($product->p_nc_name); ?>" width="300" height="400
    " class="img-responsive" style="border: 1px solid #e7e7e7; margin-top: 2px; background-position:center">
    </span>

                            </div>
                        </center>

                        <br />
                        <center>
                            <h4><p>
                                    CMS 1500 & ICD-9-CM International Diseases Classifications are included<br />

                                    Software for Microsoft Windows 98, ME, XP, NT, 2000, 2003, 2008, Vista, Windows
                                    7, 8,10 and comes with 1 Full Year FREE online support.
                                </p></h4>
                        </center>
                        <br />
                        <h4><p>
                                <?php echo $product['p_keyword_price'.langIsAr()]; ?>

                            </p></h4>



                        <?php echo $__env->make('front.products.price.price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




                        <div class="ads-details">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab-details" data-toggle="tab"><h4>Software Features </h4></a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab-details">
                                    <div class="row" style="padding: 10px;">
                                        <div class="ads-details-info col-md-12 col-sm-12 col-xs-12 enable-long-words from-wysiwyg">

                                            <!-- Location -->
                                            <div class="detail-line-lite col-md-6 col-sm-6 col-xs-6">
                                                <div>
                                                    <span><i class="fa fa-download"></i> Download: </span>
                                                    <span>
																												<a href="#">
 21 days FREE trial														</a>
													</span>
                                                </div>
                                            </div>
                                            <!-- Price / Salary -->
                                            <div class="detail-line-lite col-md-6 col-sm-6 col-xs-6">
                                                <div>

														<span>

																																														<small class="label label-success">User Friendly, Simple and Affordable</small>
																													</span>
                                                </div>
                                            </div>
                                            <div style="clear: both;"></div>
                                            <hr>

                                            <!-- Description -->
                                            <div class="detail-line-content"  >
                                                <center>
                                                    <div class="ads-image">



                                                        <ul class="bxslider"  >



                                                            <?php if(count($features)): ?>
                                                                <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><img src="<?php echo e(url('design')); ?>/images/medical/<?php echo $product->name_link; ?>/<?php echo e($feature->img_path); ?>"></li>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>

                                                                  <em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em>

                                                            <?php endif; ?>
                                                                                   </ul>
                                                    </div>
                                                </center>
                                                <hr>
                                            </div>
<?php if($product->features == ''): ?>

                                                <?php if(count($features)): ?>
                                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <h3>    <?php echo $feature->name; ?></h3>
                                                        <?php echo $feature->content; ?><br/>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>

                                                    <em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em>

                                                <?php endif; ?>

                                            <?php else: ?>

                                                <?php echo $product['features'.langIsAr()]; ?>


                                            <?php endif; ?>
                                        </div>

                                        <br />&nbsp;<br />
                                    </div>
                                </div>

                            </div>



                        </div>
                    </div>
                    <!--/.ads-details-wrapper-->
                </div>
                <!--/.page-content-->

                <?php echo $__env->make('front.layouts.product_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>

        </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_styles'); ?>
    <!-- bxSlider CSS file -->
        <?php if(direction()== 'rtl'): ?>
            <link href="<?php echo e(url('design/assets/plugins/bxslider/jquery.bxslider.rtl.css')); ?>" rel="stylesheet"/>
        <?php else: ?>

            <link href="<?php echo e(url('design/assets/plugins/bxslider/jquery.bxslider.css')); ?>" rel="stylesheet"/>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('after_scripts'); ?>



    <!-- bxSlider Javascript file -->
        <script src="<?php echo e(url('design/assets/plugins/bxslider/jquery.bxslider.min.js')); ?>"></script>

        <script>

            /* Favorites Translation */
            var lang = {
                labelSavePostSave: "Save ad",
                labelSavePostRemove: "Remove favorite",
                loginToSavePost: "Please log in to save the Ads.",
                loginToSaveSearch: "Please log in to save the search.",
                confirmationSavePost: "Post saved in favorites successfully !",
                confirmationRemoveSavePost: "Post deleted from favorites successfully !",
                confirmationSaveSearch: "Search saved successfully !",
                confirmationRemoveSaveSearch: "Search deleted successfully !"
            };

            $(document).ready(function () {
                /* bxSlider - Main Images */
                $('.bxslider').bxSlider({
                    speed: 1000,
                    pagerCustom: '#bx-pager',
                    adaptiveHeight: true,
                    onSlideAfter: function ($slideElement, oldIndex, newIndex) {
                        <?php if(!userBrowser('Chrome')): ?>
                        $('#bx-pager li:not(.bx-clone)').eq(newIndex).find('a.thumb-item-link').addClass('active');
                        <?php endif; ?>
                    }
                });

                /* bxSlider - Thumbnails */
                <?php if(userBrowser('Chrome')): ?>
                $('#bx-pager').addClass('m-3');
                $('#bx-pager .thumb-item-link').unwrap();
                        <?php else: ?>
                var thumbSlider = $('.product-view-thumb').bxSlider(bxSliderSettings());
                $(window).on('resize', function() {
                    thumbSlider.reloadSlider(bxSliderSettings());
                });
                <?php endif; ?>



                /* Keep the current tab active with Twitter Bootstrap after a page reload */
                /* For bootstrap 3 use 'shown.bs.tab', for bootstrap 2 use 'shown' in the next line */
                $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                    /* save the latest tab; use cookies if you like 'em better: */
                    localStorage.setItem('lastTab', $(this).attr('href'));
                });
                /* Go to the latest tab, if it exists: */
                var lastTab = localStorage.getItem('lastTab');
                if (lastTab) {
                    $('[href="' + lastTab + '"]').tab('show');
                }
            });

            /* bxSlider - Initiates Responsive Carousel */
            function bxSliderSettings()
            {
                var smSettings = {
                    slideWidth: 65,
                    minSlides: 1,
                    maxSlides: 4,
                    slideMargin: 5,
                    adaptiveHeight: true,
                    pager: false
                };
                var mdSettings = {
                    slideWidth: 100,
                    minSlides: 1,
                    maxSlides: 4,
                    slideMargin: 5,
                    adaptiveHeight: true,
                    pager: false
                };
                var lgSettings = {
                    slideWidth: 100,
                    minSlides: 3,
                    maxSlides: 6,
                    pager: false,
                    slideMargin: 10,
                    adaptiveHeight: true
                };

                if ($(window).width() <= 640) {
                    return smSettings;
                } else if ($(window).width() > 640 && $(window).width() < 768) {
                    return mdSettings;
                } else {
                    return lgSettings;
                }
            }
        </script>


        <script>
            $(document).ready(function () {
                
                $('.selecter').select2({
                    language: langLayout.select2,
                    dropdownAutoWidth: 'true',
                    minimumResultsForSearch: Infinity,
                    width: '100%'
                });

                
                $('.sselecter').select2({
                    language: langLayout.select2,
                    dropdownAutoWidth: 'true',
                    width: '100%'
                });

                
                $('.share').ShareLink({
                    title: '<?php echo e(addslashes($product['p_title'.langIsAr()])); ?>',
                    text: '<?php echo addslashes($product['p_title'.langIsAr()]); ?>',
                    url: '<?php echo $fullUrl; ?>',
                    width: 640,
                    height: 480
                });

                
                <?php if(isset($errors) and $errors->any()): ?>
                <?php if($errors->any() and old('quickLoginForm')=='1'): ?>
                $('#quickLogin').modal();
                <?php endif; ?>
                <?php endif; ?>
            });
        </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.app_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/front/products/products.blade.php ENDPATH**/ ?>
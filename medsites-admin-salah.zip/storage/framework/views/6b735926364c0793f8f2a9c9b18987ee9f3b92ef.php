<?php $__env->startSection('page-title', 'Expenses'); ?>
<?php $__env->startSection('page-heading',  'Expenses'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('expenses.index')); ?>"> Expenses </a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('expense.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section class="content" id="invoice-stmt">
            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th> ID</th>

                        <th>نوع الشركه</th>
                        <th> القيمة</th>
                        <th>نوع </th>
                        <th> أسم المصروف </th>
                        <th> السبب</th>
                        <th> ملف </th>
                        <th> بتاريخ</th>
                        <th><?php echo app('translator')->getFromJson('app.action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(count($expenses)): ?>
                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('expense.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>

                    <th>  </th>

                    <th> </th>
                    <th><?php echo e(number_format($paginateSum)); ?><h2> </h2></th>
                    <th>  </th>
                    <th>   </th>
                    <th>  </th>
                    <th> </th>
                    <th> <?php
                        $params = Input::get();

                        $params = http_build_query($params);
                        ?>

                        <button type="button" class="btn btn-responsive btn_marTop button-alignment btn-info" >

                            <a style="color:#fff;" href="<?php echo e(route('expenses.printExpense')); ?>?<?php echo e($params); ?>">

                                Print
                            </a>
                        </button> </th>

                    </tfoot>
                </table>


                <?php echo $expenses->render(); ?>

            </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $("#month").change(function () {
            $("#users-form").submit();
        });
        $("#user").change(function () {
            $("#users-form").submit();
        });



        $("#company").change(function () {
            $("#users-form").submit();
        });

        $("#type").change(function () {
            $("#users-form").submit();
        });

        $("#name").change(function () {
            $("#users-form").submit();
        });


    </script>


<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2.css'); ?>">
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2-bootstrap4.css'); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets')); ?>/css/invoice.css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>


        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4 ',

                });
            });
        });

    </script>

    <script src="<?php echo url('assets/plugins/select2/select2.full.js'); ?>"></script>
    <script src="<?php echo e(url('assets')); ?>/js/invoice.js"></script>
    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/expense/index.blade.php ENDPATH**/ ?>
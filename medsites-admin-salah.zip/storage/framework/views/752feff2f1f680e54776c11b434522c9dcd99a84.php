
    <h5 class="card-title">Sales  of Year <?php echo e(Input::get('search')); ?></h5>

		<div class="chart" id="ManthStockChart" style="height: 300px;width:100% ;"></div>





<?php $__env->startPush('dashboard_styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('dashboard_scripts'); ?>
    <script>
        $(function () {
            "use strict";

            var area = new Morris.Bar({
                element: 'ManthStockChart',
                resize: true,
                data: <?php echo $getManthStockChart; ?>,
                xkey: 'y',
                ykeys: ['item'],
                labels: ['Total'],
                lineColors: ['#a0d0e0'],
                hideHover: 'auto'

            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/stock/ini/latest-month.blade.php ENDPATH**/ ?>
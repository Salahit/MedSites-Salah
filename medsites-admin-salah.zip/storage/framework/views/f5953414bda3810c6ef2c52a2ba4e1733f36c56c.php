<?php $__env->startSection('page-title', trans('app.order') ); ?>
<?php $__env->startSection('page-heading', $edit ? $order->invoice_id : $ordersVal->name .' '.  trans('app.create_new_order')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('order.index',$ordersVal->id)); ?>"><?php echo app('translator')->getFromJson('app.order'); ?></a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($edit ? trans('app.edit') : trans('app.create')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($edit): ?>
    <?php echo Form::open(['route' => ['order.update', $order->id], 'method' => 'PUT', 'id' => 'order-form']); ?>

<?php else: ?>
    <?php echo Form::open(['route' => 'order.store', 'id' => 'order-form']); ?>

<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    Order Details                </h5>
                <p class="text-muted">
                    A general Order information.
               </p>


            </div>

            <?php if($edit == false): ?>
                <input type="hidden" name="item_id"   value="<?php echo e($id); ?>">

            <?php endif; ?>
            <input type="hidden" type="number" name="rate_company" value="<?php echo e($ordersVal->rate_company); ?>">
            <input type="hidden" type="number" name="rate_importer"  value="<?php echo e($ordersVal->rate_importer); ?>">
            <input type="hidden" type="number" name="price_dollar"   value="<?php echo e($ordersVal->price_dollar); ?>">
            <input type="hidden" type="number" name="pay_day_after"   value="<?php echo e($ordersVal->pay_day_after); ?>">
            <div class="col-md-9">

                <?php if($edit == false): ?>
                <div class="form-group">
                    <label for="invoice_id">Invoice Id</label>
                    <input type="text" class="form-control" id="invoice_id"
                           name="invoice_id" placeholder="Invoice Id" value="<?php echo e($edit ? $order->invoice_id : old
                           ('invoice_id')); ?>">
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label for="importer">Importer</label>
                    <?php echo Form::select('importer_id',[''=>'Select'] + $listsItemImporters, $edit ? $order->importer_id
                    : '',
                    ['id' =>
                    'importer_id', 'class' =>
                    'form-control input-solid']); ?>


                </div>

                <div class="form-group">
                    <label for="price">Quantity</label>
                    <input type="text" class="form-control" id="quantity"
                           name="quantity" placeholder="Quantity" value="<?php echo e($edit ? $order->quantity : old
                           ('quantity')); ?>">
                </div>


                <div class="form-group">
                    <label for="start_at">Date at </label>
                    <input type="date" class="form-control" id="start_at"
                           name="start_at"   value="<?php echo e($edit ? $order->start_at
                            : old('start_at')); ?>">
                </div>

                    <div class="form-group">
                        <label for="arrival_at">Arrival at </label>
                        <input type="date" class="form-control" id="start_at"
                               name="arrival_at"   value="<?php echo e($edit ? $order->arrival_at
                            : old('arrival_at')); ?>">
                    </div>
                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" id="note" class="form-control"><?php echo e($edit ? $order->note : old('note')); ?></textarea>
                </div>
            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    <?php echo e($edit ? trans('app.update_order') : trans('app.create_order')); ?>

</button>

</form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>



    <?php if($edit): ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Order\UpdateOrderRequest', '#order-form'); ?>

    <?php else: ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Order\CreateOrderRequest', '#order-form'); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/add-edit.blade.php ENDPATH**/ ?>
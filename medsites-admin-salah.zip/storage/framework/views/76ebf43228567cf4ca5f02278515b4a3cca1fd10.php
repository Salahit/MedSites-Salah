<tr>

    <td class="align-middle">
        <a href="<?php echo e(route('order.show', $order->id)); ?>">
            <?php echo e($order->invoice_id ?: trans('app.n_a')); ?>

        </a>
    </td>


    <td  ><?php echo e(number_format($order->quantity)); ?><?php if($order->convert_stock == 1): ?>
            <a href=""
               class="btn btn-icon float-left mt-md-0 mt-0"
               title="Done Conversion "
               data-toggle="tooltip">
                <i class="fas fa-check-circle"></i>
            </a>




        <?php endif; ?>
    </td>

    <td class="align-middle"><?php echo $order->importer()->first()->name; ?>  </td>

    <td class="align-middle"><?php echo number_format($order->total_mother_company); ?> $  </td>
    <td class="align-middle"><?php echo number_format($order->total_wanted); ?> $  </td>
    <td class="align-middle"><?php echo number_format($order->less_stamp_duties); ?> $  </td>
    <td class="align-middle"><?php echo number_format($order->rate_dollar); ?> L.E  </td>



    <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($order->arrival_at)->format('F Y')); ?></td>

    <td><?php echo e($order->invoice_count); ?> - <?php echo e(number_format($order->balance)); ?></td>
    <td class="align-middle">
        <span class="badge badge-lg badge-<?php echo e($order->present()->labelClassOrder); ?>">
            <?php echo e(trans("app.{$order->status_order}")); ?>

        </span>
    </td>

    <td class="text-center align-middle">
        <a href="<?php echo e(route('order.show', $order->id) .'?year='.\Carbon\Carbon::now()->format('Y')); ?>"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

        <a href="<?php echo e(route('order.edit', $order->id)); ?>"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('order.delete', $order->id)); ?>"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/partials/row.blade.php ENDPATH**/ ?>
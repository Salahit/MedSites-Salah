
    <nav class=" sidebar "  >




    <div class="user-box text-center mb-0 pt-0 pb-0">

        <ul class="list-inline mb-0">
            <li class="list-inline-item">
                <a href="<?php echo e(route('profile')); ?>" title="<?php echo app('translator')->getFromJson('app.my_profile'); ?>">
                    <i class="fas fa-cog"></i>
                </a>
            </li>

            <li class="list-inline-item">
                <a href="<?php echo e(route('auth.logout')); ?>" class="text-custom" title="<?php echo app('translator')->getFromJson('app.logout'); ?>">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </li>
        </ul>
    </div>


    <div class="sidebar-sticky mt-0">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                    <i class="fas fa-home"></i>
                    <span><?php echo app('translator')->getFromJson('app.dashboard'); ?></span>
                </a>
            </li>
            <?php if (\Auth::user()->hasPermission('accounting')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('accounting*') ? 'active' : ''); ?>" href="<?php echo e(route('accounting.accounting')); ?>">
                    <i class="far fa-money-bill-alt"></i>
                    <span> Accounting</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('expenses.list')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('expenses*') ? 'active' : ''); ?>" href="<?php echo e(route('expenses.index')); ?>">
                    <i class="fas fa-dollar-sign"></i>
                    <span>Expenses</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('cashMoney.list')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('cashMoney*') ? 'active' : ''); ?>" href="<?php echo e(route('cashMoney.index')); ?>">
                    <i class="far fa-money-bill-alt"></i>
                    <span> Cash Money</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('stock.list')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('stock*') ? 'active' : ''); ?>" href="<?php echo e(route('stock.index')); ?>">
                    <i class="fas fa-pills"></i>
                    <span>Pharmaceutical</span>
                </a>
            </li>
            <?php endif; ?>



            <?php if (\Auth::user()->hasPermission('importers')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('importer*') ? 'active' : ''); ?>" href="<?php echo e(route('importer.index')); ?>">
                    <i class="fas fa-capsules"></i>
                    <span>Importer</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('Registration.List')) : ?>
            <li class="nav-item">
  <a class="nav-link <?php echo e(Route::is('registration*') ? 'active' : ''); ?>" href="<?php echo e(route('registration.index')); ?>">

      <i class="fas fa-calendar-alt"></i>
                    <span> Registration</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (\Auth::user()->hasPermission('filesMail.list')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('filesMail*') ? 'active' : ''); ?>" href="<?php echo e(route('filesMail.index')); ?>">
                    <i class="fas fa-paste"></i>
                    <span>Files Mail List</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('license.list')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('license*') ? 'active' : ''); ?>" href="<?php echo e(route('license.index')); ?>">
                    <i class="fa fa-h-square"></i>
                    <span>License</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('message.list')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('message*') ? 'active' : ''); ?>" href="<?php echo e(route('message.index')); ?>">
                    <i class="fas fa-envelope-open"></i>

                    <span>Tickets</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (\Auth::user()->hasPermission('users.manage')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('user*') ? 'active' : ''); ?>" href="<?php echo e(route('user.list')); ?>">
                    <i class="fas fa-users"></i>
                    <span><?php echo app('translator')->getFromJson('app.users'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (\Auth::user()->hasPermission('users.activity')) : ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Route::is('activity*') ? 'active' : ''); ?>" href="<?php echo e(route('activity.index')); ?>">
                    <i class="fas fa-server"></i>
                    <span><?php echo app('translator')->getFromJson('app.activity_log'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (\Auth::user()->hasPermission(['product.list'], false)) : ?>
            <li class="nav-item">
                <a href="#site-dropdown"
                   class="nav-link"
                   data-toggle="collapse"
                   aria-expanded="<?php echo e(Route::is('products*') || Route::is('download*') || Route::is('pages*') ? 'true' : 'false'); ?>">
                    <i class="fas fa-cogs"></i>
                    <span>Site</span>
                </a>
                <ul class="<?php echo e(Route::is('products*') || Route::is('download*') || Route::is('pages*')  ? '' : 'collapse'); ?> list-unstyled sub-menu"
                    id="site-dropdown">
                    <?php if (\Auth::user()->hasPermission('product.list')) : ?>
                    <li class="nav-item nav-sub"  >
                        <a class="nav-link  <?php echo e(Route::is('products*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('products.index')); ?>">
                            <i class="fas fa-cubes"></i>
                            <span>Products List</span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (\Auth::user()->hasPermission('download.list')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('download*') ? 'active' : ''); ?>" href="<?php echo e(route('download.index')); ?>">
                            <i class="fas fa-download"></i>
                            <span>Download List</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (\Auth::user()->hasPermission('page.list')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('pages*') ? 'active' : ''); ?>" href="<?php echo e(route('pages.index')); ?>">
                            <i class="fas fa-basketball-ball"></i>
                            <span>Pages List</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>






            <?php if (\Auth::user()->hasPermission(['roles.manage', 'permissions.manage'])) : ?>
            <li class="nav-item">
                <a href="#roles-dropdown"
                   class="nav-link"
                   data-toggle="collapse"
                   aria-expanded="<?php echo e(Route::is('role*') || Route::is('permission*') ? 'true' : 'false'); ?>">
                    <i class="fas fa-users-cog"></i>
                    <span>Roles </span>
                </a>
                <ul class="<?php echo e(Route::is('role*') || Route::is('permission*') ? '' : 'collapse'); ?> list-unstyled
                sub-menu" id="roles-dropdown">
                    <?php if (\Auth::user()->hasPermission('roles.manage')) : ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('role*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('role.index')); ?>"><?php echo app('translator')->getFromJson('app.roles'); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if (\Auth::user()->hasPermission('permissions.manage')) : ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('permission*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('permission.index')); ?>"><?php echo app('translator')->getFromJson('app.permissions'); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if (\Auth::user()->hasPermission(['backup.page, settings.general', 'settings.auth', 'settings.price', 'settings
            .notifications'], false)) : ?>
            <li class="nav-item">
                <a href="#settings-dropdown"
                   class="nav-link"
                   data-toggle="collapse"
                   aria-expanded="<?php echo e(Route::is('settings*') || Route::is('backups*')  ? 'true' : 'false'); ?>">
                    <i class="fas fa-cogs"></i>
                    <span><?php echo app('translator')->getFromJson('app.settings'); ?></span>
                </a>
                <ul class="<?php echo e(Route::is('settings*') || Route::is('backups*') ? '' : 'collapse'); ?> list-unstyled
                sub-menu"
                    id="settings-dropdown">
                    <?php if (\Auth::user()->hasPermission('backup.page')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('backups*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('backups')); ?>">
                            Backups
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('clearCache*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('clearCache')); ?>">
                            Clear Cache
                        </a>
                    </li>

                    <?php if (\Auth::user()->hasPermission('settings.general')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('settings*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('settings.general')); ?>">
                            <?php echo app('translator')->getFromJson('app.general'); ?>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (\Auth::user()->hasPermission('settings.auth')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('settings/auth') ? 'active' : ''); ?>"
                           href="<?php echo e(route('settings.auth')); ?>"><?php echo app('translator')->getFromJson('app.auth_and_registration'); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if (\Auth::user()->hasPermission('settings.price')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('settings/price') ? 'active' : ''); ?>"
                           href="<?php echo e(route('settings.price')); ?>">Price</a>
                    </li>
                    <?php endif; ?>

                    <?php if (\Auth::user()->hasPermission('settings.notifications')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('settings/notifications') ? 'active' : ''); ?>"
                           href="<?php echo e(route('settings.notifications')); ?>"><?php echo app('translator')->getFromJson('app.notifications'); ?></a>
                    </li>
                    <?php endif; ?>

                    <?php if (\Auth::user()->hasPermission('settings.notifications')) : ?>
                    <li class="nav-item nav-sub">
                        <a class="nav-link <?php echo e(Route::is('settings/notifications') ? 'active' : ''); ?>"
                           href="<?php echo e(route('settings.notifications')); ?>"><?php echo app('translator')->getFromJson('app.notifications'); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
        </ul>




    </div>


</nav>

<?php /**PATH C:\xampp\htdocs\medsites\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>




    <div class="h-spacer"></div>
    <div class="main-container">
        <div class="container" <?php if(direction()== 'rtl'): ?> style="direction:rtl;" <?php endif; ?>>
            <div class="row">
            <?php echo $__env->make('front.tickets.partials.rowLeft', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!--/.page-sidebar-->
                <div class="col-md-9 page-content">
                <?php if($ticketFrontAll == ''): ?>
                        <?php echo $__env->make('front.tickets.partials.add-new-ticket', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>

                    <div class="inner-box">
                        <h2 class="title-2">
                            <i class="icon-mail"></i> Messages
                            <button class="btn btn-primary" type="button" data-toggle="collapse"
                          data-target="#contentUpload" aria-expanded="false"
                        aria-controls="contentId">
                                Show Upload Files
                            </button></h2>


                        <div style="clear:both"></div>


                        <div class="collapse" id="contentUpload">
                            <?php echo $__env->make('front.tickets.partials.upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>

                        <?php if($ticketFrontAll): ?>
                                    <?php if($ticketFrontAll !='null'): ?>
                                <div class="messageFromAdmin">
                                                    <?php echo nl2br($ticketFrontAll->message); ?>

                                </div>
                            <?php endif; ?>


                                    <?php
                                    $messagesFrontAll  = \DB::table('tickets_message')
                                        ->where('user_id',  auth()->user()->id)
                                        ->where('tickets_id',  $ticketFrontAll->id)
                                        ->orderBy('id', 'ASC')->get() ;

                                    if (isset($messagesFrontAll) && $messagesFrontAll->count() > 0):
                                    foreach($messagesFrontAll as $key => $messages):
                                    ?>



                                        <div class="col-md-12">

                                                <?php if($messages->admin_id ==''): ?>
                                                    <div class="messageFromAdmin">
                                                        <?php else: ?>
                                                            <div class="messageFromUser">
                                                                <?php endif; ?>

                                                <div class="text">
                                                    <?php echo nl2br($messages->message); ?>

                                                </div>
                                            </div>
                                        </div>



                                                <?php if(!empty($messages->filename) and \Storage::exists
                                                ($message->filename)): ?>
                                                    <br><br><a class="btn btn-info" href="<?php echo e(\Storage::url
                                                    ($messages->filename)); ?>"><?php echo e(t('Download')); ?></a>
                                                <?php endif; ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

              <?php if($ticketFrontAll->show_control_to_user == 1): ?>
                        <?php echo Form::open(['route' => 'ticket.close', 'id' => 'ticket-form']); ?>

<?php echo e($ticketFrontAll->show_control_to_user); ?>

                            <div class="form-group my-4">
                                <div class="d-flex align-items-center">
                                    <div class="switch">
                                        <input type="hidden" value="Close" name="close">

                                        <input type="checkbox"
                                               name="close"
                                               class="switch"

                                               value="Active"
                                               onChange="this.form.submit()"
                                               id="switch-signup-email"
                                                <?php echo e($ticketFrontAll->close == 'Active' ? 'checked' : ''); ?>>

                                        <label for="switch-signup-email"></label>



                                        <label class="mb-0"><?php echo app('translator')->getFromJson('app.sign_up_notification'); ?></label>

                                </div>
                            </div>


                            <?php echo Form::close(); ?>






                        <div class="collapse" id="contentId">

              <?php echo Form::open(['route' => 'ticket.save', 'id' => 'ticket-form']); ?>



                            <input type="hidden" value="<?php echo e($ticketFrontAll->id); ?>" name="tickets_id" >


                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="message">Message </label>
                                    <textarea name="message" id="description" rows="5" class="form-control"><?php echo e($edit ?
                    $page->content : old('message')); ?></textarea>
                                </div>
                            </div>






                            <div class="row">
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Send Message
                                    </button>
                                </div>
                            </div>

                        </div>






                        <div class="row">

                            <div class="card">
                                <div class="card-body">

                            <div class="col-md-12" >
                                <center>
<h3>       Is this useful? </h3>
                                    <button type="submit" class="btn btn-primary">
                                      Yes
                                    </button>

                                        <button class="btn btn-primary" type="button" data-toggle="collapse"
                                                data-target="#contentId" aria-expanded="false"
                                                aria-controls="contentId">
                                            No
                                        </button>

                                </center>

                            </div>
                                </div>
                            </div>
                        </div>



                    </div>

                <!--/.page-content-->
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
            </div>
            </div>
        </div>
            <div style="clear:both"><br></div>   <!--/.row-->
        </div>
        <!--/.container-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_styles'); ?>
            <link href="<?php echo e(url('assets')); ?>/plugins/fileinput/css/fileinput.css" media="all" rel="stylesheet" type="text/css"/>

            <link href="<?php echo e(url('assets')); ?>/plugins/fileinput/themes/explorer/theme.css" rel="stylesheet">



<style>
    .switch{font-size:.9rem;position:relative}.switch input{position:absolute;height:1px;width:1px;background:none;border:0;clip:rect(0 0 0 0);-webkit-clip-path:inset(50%);clip-path:inset(50%);overflow:hidden;padding:0}.switch input+label{position:relative;min-width:calc(((2.19rem + 2px) * .8) * 2);border-radius:calc((2.19rem + 2px) * .8);height:calc((2.19rem + 2px) * .8);line-height:calc((2.19rem + 2px) * .8);display:inline-block;cursor:pointer;outline:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;vertical-align:middle;text-indent:calc((((2.19rem + 2px) * .8) * 2) + .5rem);margin-bottom:0}.switch input+label:after,.switch input+label:before{content:"";position:absolute;top:0;left:0;width:calc(((2.19rem + 2px) * .8) * 2);bottom:0;display:block}.switch input+label:before{right:0;background-color:#dee2e6;border-radius:calc((2.19rem + 2px) * .8);-webkit-transition:all .2s;transition:all .2s}.switch input+label:after{top:2px;left:2px;width:calc(((2.19rem + 2px) * .8) - 4px);height:calc(((2.19rem + 2px) * .8) - 4px);border-radius:50%;background-color:#fff;-webkit-transition:all .2s;transition:all .2s}.switch input:checked+label:before{background-color:#245580}.switch input:checked+label:after{margin-left:calc((2.19rem + 2px) * .8)}.switch input:focus+label:before{outline:none;-webkit-box-shadow:0 0 0 .2rem rgba(23,153,112,.25);box-shadow:0 0 0 .2rem rgba(23,153,112,.25)}.switch input:disabled+label{color:#868e96;cursor:not-allowed}.switch input:disabled+label:before{background-color:#e9ecef}.switch.switch-sm{font-size:.7875rem}.switch.switch-sm input+label{min-width:calc(((1.68125rem + 2px) * .8) * 2);height:calc((1.68125rem + 2px) * .8);line-height:calc((1.68125rem + 2px) * .8);text-indent:calc((((1.68125rem + 2px) * .8) * 2) + .5rem)}.switch.switch-sm input+label:before{width:calc(((1.68125rem + 2px) * .8) * 2)}.switch.switch-sm input+label:after{width:calc(((1.68125rem + 2px) * .8) - 4px);height:calc(((1.68125rem + 2px) * .8) - 4px)}.switch.switch-sm input:checked+label:after{margin-left:calc((1.68125rem + 2px) * .8)}.switch.switch-lg{font-size:1.125rem}.switch.switch-lg input+label{min-width:calc(((2.6875rem + 2px) * .8) * 2);height:calc((2.6875rem + 2px) * .8);line-height:calc((2.6875rem + 2px) * .8);text-indent:calc((((2.6875rem + 2px) * .8) * 2) + .5rem)}.switch.switch-lg input+label:before{width:calc(((2.6875rem + 2px) * .8) * 2)}.switch.switch-lg input+label:after{width:calc(((2.6875rem + 2px) * .8) - 4px);height:calc(((2.6875rem + 2px) * .8) - 4px)}.switch.switch-lg input:checked+label:after{margin-left:calc((2.6875rem + 2px) * .8)}.switch+.switch{margin-left:1rem}.swal-button--confirm{background-color:#dc3545}.table thead th{color:#495057}.table-striped tr td:first-of-type{border-radius:5px 0 0 5px}.table-striped tr td:last-of-type{border-radius:0 5px 5px 0}.border-bottom-light{border-bottom:1px solid #f5f8fa}.no-decoration{text-decoration:none!important}.flex-1{-webkit-box-flex:1;-ms-flex:1;flex:1}.my-10p{margin-top:10%;margin-bottom:10%}.text-gray-500{color:#adb5bd}.badge-lg{padding:5px 8px}.min-width-200{min-width:200px}.min-width-150{min-width:150px}.min-width-100{min-width:100px}.min-width-80{min-width:80px}
.messageFromAdmin{
    color:#336699;
}

    .messageFromUser{
        color:#ffffff;

    }
    .messageFromUser a {
        color:#ffffff;
    }
</style>

    <?php echo $__env->yieldPushContent('dashboard_styles'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>





            <script src="<?php echo e(url('assets')); ?>/plugins/fileinput/js/fileinput.js" type="text/javascript"></script>
            <script src="<?php echo e(url('assets')); ?>/plugins/fileinput/js/locales/LANG.js" type="text/javascript"></script>

            <script src="<?php echo e(url('assets')); ?>/plugins/fileinput/themes/explorer/theme.js"></script>



            <script>

                $("#kv-explorer").fileinput({
                    'theme': 'explorer',
                    'uploadUrl': '/ticket/upload',
                    removeFromPreviewOnError: true,
                    overwriteInitial: false,
                    allowedFileExtensions: ['jpg', 'png', 'gif'],
                    initialPreview: [

                        <?php $__currentLoopData = $ticketFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                      <?php if($Files->filetype == 'image/jpeg'
                         and 'image/bmp'
                         and 'image/gif'
                         and 'image/tiff'
                         and 'image/x-cmu-raster'
                         and 'image/x-cmx'
                         and 'image/x-icon'
                         and 'image/x-portable-anymap'
                         and 'image/x-portable-bitmap'
                         and 'image/x-portable-graymap'
                         and 'image/x-portable-pixmap'
                         and 'image/x-rgb'
                         and 'image/x-xbitmap'
                         and 'image/x-xpixmap'
                         and 'image/x-xwindowdump'
                         and 'image/png'
                         and 'image/x-jps'
                         and 'image/x-freehand'): ?>

                            '<?php echo url('upload/FilesTicket/'.auth()->user()->id.'/'.$Files->name); ?>',

                        <?php else: ?>
                           '<?php echo e($Files->name); ?>',
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    ],
                    //elErrorContainer: "#errorBlock",
                    browseOnZoneClick: true,
                    initialPreviewAsData: true, // defaults markup
                    initialPreviewConfig: [
                        <?php $__currentLoopData = $ticketFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Files): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
{caption: "<?php echo e($Files->name); ?>", size: <?php echo e($Files->size_file); ?>,  filetype: "<?php echo e($Files->filetype); ?>" ,url:
                                "/ticket/<?php echo e($Files->id); ?>/filedelete",
                            key: <?php echo e($Files->id); ?>},
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          ],
                    preferIconicPreview: false,



                    previewFileExtSettings: { // configure the logic for determining icon file extensions
                        'doc': function(ext) {
                            return ext.match(/(doc|docx)$/i);
                        },
                        'xls': function(ext) {
                            return ext.match(/(xls|xlsx)$/i);
                        },
                        'ppt': function(ext) {
                            return ext.match(/(ppt|pptx)$/i);
                        },
                        'zip': function(ext) {
                            return ext.match(/(zip|rar|tar|gzip|gz|7z)$/i);
                        },
                        'htm': function(ext) {
                            return ext.match(/(htm|html)$/i);
                        },
                        'txt': function(ext) {
                            return ext.match(/(txt|ini|csv|java|php|js|css)$/i);
                        },
                        'mov': function(ext) {
                            return ext.match(/(avi|mpg|mkv|mov|mp4|3gp|webm|wmv)$/i);
                        },
                        'mp3': function(ext) {
                            return ext.match(/(mp3|wav)$/i);
                        }
                    }

                });



            </script>

<?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/front/tickets/ticket.blade.php ENDPATH**/ ?>
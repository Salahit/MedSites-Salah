<?php $__env->startSection('title', 'Forbidden!'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-5">Forbidden!</h1>
    <p class="lead">You don't have permission to access this page.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/errors/403.blade.php ENDPATH**/ ?>
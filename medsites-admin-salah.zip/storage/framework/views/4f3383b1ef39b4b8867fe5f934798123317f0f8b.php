
    <h5 class="card-title">Sales  in every month of all years </h5>

		<div class="chart" id="getAllManthStockChart" style="height: 300px;width:100% ;"></div>





<?php $__env->startPush('dashboard_styles'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('dashboard_scripts'); ?>
    <script>
        $(function () {
            "use strict";

            var area = new Morris.Bar({
                element: 'getAllManthStockChart',
                resize: true,
                data: <?php echo $getAllManthStockChart; ?>,
                xkey: 'y',
                ykeys: ['item'],
                labels: ['Total'],
                lineColors: ['#a0d0e0'],
                hideHover: 'auto'

            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/stock/ini/latest-all-month.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title', 'Importer List Items'); ?>
<?php $__env->startSection('page-heading',  'Importer  List Items'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('importer.index')); ?>">Importers</a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('importer.partials.search-importer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th> Id</th>
                        <th> Add By</th>

                        <th>importers</th>

                        <th>Item</th>
                        <th>Stock</th>
                        <th> Date</th>
                        <th><?php echo app('translator')->getFromJson('app.action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($importers)): ?>
                        <?php $__currentLoopData = $importers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $importer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('importer.partials.row-importer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                    <tfoot>

                    <th> </th>
                    <th> </th>

                    <th> </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                <?php echo $importers->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>
        $("#importer").change(function () {
            $("#users-form").submit();
        });
        $("#item").change(function () {
            $("#users-form").submit();
        });
    </script>


    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/importer/list-importer.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title', trans('app.cashMoney')); ?>
<?php $__env->startSection('page-heading', $edit ? $cashMoney->cash_money : trans('app.create_new_cashMoney')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('cashMoney.index')); ?>"><?php echo app('translator')->getFromJson('app.cashMoney'); ?></a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($edit ? trans('app.edit') : trans('app.create')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($edit): ?>
    <?php echo Form::open(['route' => ['cashMoney.update', $cashMoney->id], 'method' => 'PUT', 'id' => 'cashMoney-form']); ?>

<?php else: ?>
    <?php echo Form::open(['route' => 'cashMoney.store', 'id' => 'cashMoney-form']); ?>

<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    <?php echo app('translator')->getFromJson('app.cashMoney_details_big'); ?>
                </h5>
                <p class="text-muted">
                    A general Cash Money information.
               </p>
            </div>
            <div class="col-md-9">


                <div class="form-group">
                    <label for="from_id">Money From  </label>

                    <?php echo Form::select('from_id', [''=>'Select'] +  $listsEmployees   ,$edit ? $cashMoney->from_id : '',
                                       ['id' => 'from_id', 'class' => 'form-control input-solid']); ?>


                </div>
                <div class="form-group">
                    <label for="to_id">Money To </label>

                    <?php echo Form::select('to_id', [''=>'Select'] +  $listsEmployees   ,$edit ? $cashMoney->to_id : '',
                                       ['id' => 'to_id', 'class' => 'form-control input-solid']); ?>


                </div>

                <div class="form-group">
                    <label for="reason">Reason</label>
                    <input type="text" class="form-control" id="reason"
                           name="reason" placeholder="reason" value="<?php echo e($edit ? $cashMoney->reason : old
                           ('reason')); ?>">
                </div>

                <div class="form-group">
                    <label for="cash_money">Cash Money</label>
                    <input type="number" class="form-control" id="cash_money"
                           name="cash_money" placeholder="Cash Money" value="<?php echo e($edit ? $cashMoney->cash_money : old
                           ('cash_money')); ?>">
                </div>



            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    <?php echo e($edit ? trans('app.update_cashMoney') : trans('app.create_cashMoney')); ?>

</button>

</form>
<br>
<div class="card">
    <div class="card-body">
        <div class="  table-responsive" id="users-table-wrapper">
            <table class="table table-striped table-borderless">
                <thead>
                <tr>

                    <th>Name</th>
                    <th>Cash Money</th>
                    <th>Expenses</th>

                </tr>
                </thead>
                <tbody>
                <?php if(count($ListsEmployeesAll)): ?>
                    <?php $__currentLoopData = $ListsEmployeesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td class="align-middle"><?php echo e($row->users_id()->first()->present()->nameOrEmail); ?>  </td>
                            <td><?php echo e(number_format($row->cash_money )); ?></td>

                            <td>

                                <a href="<?php echo e(route('expenses.index') .'?user='.$row->employee_id); ?>" class="badge badge-lg badge-light">



                                    <h5>     <?php echo e(number_format($row->tobalance)); ?>  </h5>  </a>   </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2.css'); ?>">
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2-bootstrap4.css'); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4',
                    width: 'style',
                    placeholder: $(this).attr('placeholder'),
                    allowClear: Boolean($(this).data('allow-clear')),

                });
            });
        });

    </script>

    <script src="<?php echo url('assets/plugins/select2/select2.full.js'); ?>"></script>

    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>


<?php if($edit): ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\CashMoney\UpdateCashMoneyRequest', '#cashMoney-form'); ?>

    <?php else: ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\CashMoney\CreateCashMoneyRequest', '#cashMoney-form'); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/cashMoney/add-edit.blade.php ENDPATH**/ ?>
<tr>
    <td><?php echo e($invoice->invoice_id); ?> </td>
    <td><?php echo e(number_format($invoice->invoice_total)); ?> $ </td>

    <td>  <span class="badge badge-lg badge-info">
<?php echo e(number_format($invoice->rate_invoice)); ?> %

        </span>
    </td>


    <td><?php echo e(number_format($invoice->price_dollar)); ?> L.E </td>
    <td><?php echo e($invoice->ItemId()->first()->name); ?> </td>
    <td><?php echo e($invoice->OrderId()->first()->invoice_id); ?> </td>



    <td>
        <?php echo e(\Carbon\Carbon::parse($invoice->arrival_at)->format('Y F  d D')); ?>


    </td>

    <td class="text-center align-middle">

        <a href="<?php echo e(route('order.show', $invoice->order_id)); ?>"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/partials/row-page-invoice.blade.php ENDPATH**/ ?>
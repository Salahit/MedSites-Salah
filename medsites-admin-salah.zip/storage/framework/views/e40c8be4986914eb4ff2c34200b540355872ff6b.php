<?php $__env->startSection('page-title', $order->invoice_id .' '.$order->ItemId()->first()->name  ); ?>
<?php $__env->startSection('page-heading',  $order->invoice_id .' '.$order->ItemId()->first()->name   ); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('order.index',$order->item_id)  .'?year='.\Carbon\Carbon::parse($order->arrival_at)->format('Y')); ?>">Order</a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e(number_format($order->quantity)); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    <?php echo app('translator')->getFromJson('app.details'); ?>

                            <small class="float-right">
                                <a class="btn btn-icon float-right" href="<?php echo e(route('stock.addHistoryView',
                                $order->item_id)); ?>"
                                   title="Add history"
                                   data-toggle="tooltip">
                                    <i class="fa fa-plus fa-lg"></i>

                                </a>
                                <a class="btn btn-icon float-right"
                                   title="List History"
                                   data-toggle="tooltip"
                                   href="<?php echo e(route('stock.history').'?item='.$order->item_id); ?>" >
                                    <i class="fa fa-history fa-lg"></i>

                                </a>




                        <a href="<?php echo e(route('order.edit', $order->id)); ?>" class="edit float-left"
                           data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->getFromJson('app.edit_user'); ?>">
                            <?php echo app('translator')->getFromJson('app.edit'); ?>
                        </a>
                    </small>
                </h5>
                <ul class="list-group list-group-flush mt-1">
                <li class="list-group-item">
                    <span class="badge badge-lg badge-<?php echo e($order->present()->labelClassOrder); ?>">
            <?php echo e(trans("app.{$order->status_order}")); ?>

        </span>
                </li><li class="list-group-item">

                    <h3><strong> <?php echo e($order->ItemId()->first()->name); ?> </strong> </h3>
                    </li>
                    <li class="list-group-item">
                        Arrival At:
                        <strong> <?php echo e(\Carbon\Carbon::parse($order->arrival_at)->format('F Y')); ?> </strong>
                    </li>
                    <li class="list-group-item">
                        Add By :
                        <strong> <?php echo e($order->UsersId()->first()->present()->nameOrEmail); ?> </strong>
                    </li>
                    <li class="list-group-item">
                        Price :
                        <strong>  <?php echo e($order->price_dollar); ?>  $ </strong>
                    </li>


                    <li class="list-group-item">


                        Quantity :<strong>   <?php echo e(number_format($order->quantity)); ?>  </strong>
                        <?php if($order->convert_stock == 0): ?>
                            <a href="#"
                               class="btn btn-icon float-right"
                               title="Conversion"
                               data-toggle="modal"
                               data-target="#exampleModal"


                               data-placement="top"

                               data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
                               data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
                               data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">

                                <i class="fas fa-reply-all fa-2x"></i>
                            </a>

                        <?php else: ?>
                            <a tabindex="0" role="button" class="btn btn-icon"
                               data-trigger="focus"
                               data-placement="left"
                               data-html="true"
                               data-toggle="popover"
                               title="Done Conversion"
                               data-content="<?php echo \Carbon\Carbon::parse($order->convert_date_at)->format(config('app.date_time_format')); ?> ">


                                <i class="fas  fa-check-circle fa-2x"></i>
                            </a>

                        <?php endif; ?>

                        <br>
                        <strong>  <?php echo e($stockImporterFirst->importer()->first()->name); ?> -      Stock   : <strong>  <?php echo e(number_format($stockImporterFirst->total_stock )); ?>  </strong>
                        </strong>

                    </li>

                    <li class="list-group-item">
                        Total Price :
                        <strong>  <?php echo e(number_format($order->total_price)); ?>  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to <?php echo e($order->ItemId()->first()->company); ?>  :
                        <strong>  <?php echo e(number_format($order->total_mother_company)); ?>  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to MedSites  :
                        <strong>  <?php echo e(number_format($order->total_wanted)); ?>  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to  <?php echo e($stockImporterFirst->importer()->first()->name); ?>  :
                        <strong>  <?php echo e(number_format($order->less_stamp_duties)); ?>  $ </strong>
                    </li>
                    <li class="list-group-item">
                        <strong>  Rate MedSites : <?php echo e($order->rate_company); ?>

                         % </strong>
                    </li>

                    <li class="list-group-item">
                      Importer:
                        <strong>  <?php echo e($stockImporterFirst->importer()->first()->name); ?> -  <?php echo e($order->rate_importer); ?> %
                        </strong>
                        <br>
                    Stock   : <strong>  <?php echo e(number_format($stockImporterFirst->total_stock )); ?>  </strong>
                    </li>
                    <li class="list-group-item">
                        Pay Day After :</strong>
                        <strong> <?php echo e($order->pay_day_after); ?></strong>
                    </li>
                    <li class="list-group-item">
                        <strong>Order Time:</strong>
                        <?php echo e($order->present()->arrivalDateLogin); ?>

                    </li>
                    <li class="list-group-item">
                        <strong>Updated At:</strong>
                        <?php echo e($order->updated_at->format(config('app.date_time_format'))); ?>

                    </li>


                </ul>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">

                        Invoice to Medsites    <?php echo e($order->invoice_id); ?>


                        <span class="badge badge-lg badge-dark">
 <?php echo e(number_format($order->total_wanted)); ?>  $

        </span>

                            <small class="float-right">
   <a href="<?php echo e(route('order.createInvoice',$order->id)); ?>" class="btn btn-primary ms btn-rounded
            float-right">
                                    <i class="fas fa-plus mr-2"> </i>

                                      Invoice
                                </a>

                            </small>

                    </h5>

                <?php if(count($listOrderInvoice)): ?>
                <table class="table table-borderless table-striped">
                    <thead>
                    <tr>

                        <th>Amount </th>
                        <th></th>
                        <th>Price Dollar</th>
                        <th>Arrival At</th>

                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $listOrderInvoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('order.partials.rowInvoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <tr>
                    <th><?php echo e(number_format($sumOrderInvoice)); ?> $


                        <th><span class="badge badge-lg badge-info">
<?php echo e(number_format($sumRateOrderInvoice)); ?> %
        </span> </th>
                    <th>Price Dollar</th>

                    <th>Arrival At</th>

                        <th></th> </tr> </tfoot>
                </table>
            <?php else: ?>
                <p class="text-muted font-weight-light"><em> no invoice for this order</em></p>
            <?php endif; ?>
                </div>
                </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-0 mt-0">


                                <?php if(count($orderActivities)): ?>

                                    List  <span class="badge badge-dark">
   <?php echo e(number_format (count($orderActivities))); ?></span> of year  <span class="badge badge-light">
   <?php echo e(\Carbon\Carbon::parse($order->arrival_at)->format('Y')); ?></span> this order

                                <small class="float-right">
                                        <a href="<?php echo e(route('order.index', $order->item_id)); ?>" class="edit"
                                           data-toggle="tooltip" data-placement="top" title="Back">
                                            <?php echo app('translator')->getFromJson('app.view_all'); ?>
                                        </a>
                                    </small>
                                <?php endif; ?>
                            </h4>

                            <ul class="list-inline mb-0 mt-0">

                                <li class="list-inline-item"><h6 class="text-lg-center">Quantity<br>
                                        <span class="badge badge-primary">
  Total : <?php echo e(number_format ($sumquantity)); ?></span>
                                    </h6></li>


                                <li class="list-inline-item center">
     <h6 class="text-lg-center">MedSite<br>
  <span class="badge badge-primary">
  Total : <?php echo e(number_format ($sumOrdertotal_wanted)); ?></span>
                                    </h6>
                                     </li>

                                <li class="list-inline-item"><h6 class="text-lg-center">Mother Company<br>
                                        <span class="badge badge-primary">
  Total : <?php echo e(number_format ($sumtotal_mother_company)); ?></span>
                                    </h6></li>

                                <li class="list-inline-item"><h6 class="text-lg-center">Importer<br>
                                        <span class="badge badge-primary">
  Total : <?php echo e(number_format ($sumless_stamp_duties)); ?></span>
                                    </h6></li>

                            </ul>

                            <?php if(count($orderActivities)): ?>
                                <div class="table-responsive" id="users-table-wrapper">
                                    <table class="table table-borderless table-striped">
                                    <thead>
                                    <tr>
                                        <th class="width-80"> Invoice ID</th>
                                        <th class="width-80">To MedSites</th>
                                        <th class="width-80">Importer</th>
                                        <th class="width-80">Quantity</th>
                                        <th class="width-80">Invoice </th>

                                        <th class="width-80">Arrival At</th>

                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $orderActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('order.partials.rowOrder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </table>
                            <?php else: ?>
                                <p class="text-muted font-weight-light"><em><?php echo app('translator')->getFromJson('app.no_activity_from_this_user_yet'); ?></em></p>
                            <?php endif; ?>

                                </div>

        </div>
        </div>
    </div>


</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Would you like to convert <?php echo e(number_format
                ($order->quantity)); ?> to stock</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Stock <?php echo e($stockImporterFirst->importer()->first()->name); ?> :<strong>   <?php echo e(number_format($stockImporterFirst->total_stock)); ?>  </strong>
            </div>
            <div class="modal-footer">
                <?php echo Form::open(['route' => ['updateStockFromOrder.updateStockFromOrder'], 'method' =>
                      'POST', 'id' => 'FromOrder1-form']); ?>



                <input type="hidden" value="<?php echo e($order->id); ?>" name="order_id" >
                <input type="hidden" value="<?php echo e($order->item_id); ?>" name="item_id" >
                <input type="hidden" value="<?php echo e($order->importer_id); ?>" name="importer_id" >
                <input type="hidden" value="<?php echo e($order->quantity); ?>" name="quantity" >
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
        $("#FromOrder-form").click(function () {
            $("#FromOrder-form").submit();
        });


    </script>


    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/view.blade.php ENDPATH**/ ?>
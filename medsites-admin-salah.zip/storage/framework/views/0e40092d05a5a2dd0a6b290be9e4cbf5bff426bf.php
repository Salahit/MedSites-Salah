<?php $__env->startSection('page-title', 'Backup'); ?>
<?php $__env->startSection('page-heading', 'Backup'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
	<li class="breadcrumb-item active">
        Backup
	</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
    <!-- Default box -->
    <div class="box box-primary">
	
		<div class="box-header with-border">
			<div class="callout">
				<h4><i class="fa fa-question-circle"></i> <?php echo e(trans('backupLang.Help')); ?></h4>
			
				<p><?php echo trans('backupLang.help_backup'); ?></p>
			</div>
		</div>
		
        <div class="box-body">
			
            <button id="create-new-backup-button" href="<?php echo e(url('admin/backups/create')); ?>" class="btn btn-success
            ladda-button
            backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-download"></i> <?php echo e(trans('backupLang.create_a_new_backup_all')); ?></span></button>
	
			<button id="create-new-backup-button1" href="<?php echo e(url('admin/backups/create').'?type=database'); ?>" class="btn
			btn-primary ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-database"></i> <?php echo e(trans('backupLang.create_a_new_backup_database')); ?></span></button>
	
			<button id="create-new-backup-button3" href="<?php echo e(url('admin/backups/create').'?type=languages'); ?>"
					class="btn
			btn-info ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-globe"></i> <?php echo e(trans('backupLang.create_a_new_backup_languages')); ?></span></button>
	
			<button id="create-new-backup-button2" href="<?php echo e(url('admin/backups/create').'?type=files'); ?>" class="btn
			btn-warning ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-files-o"></i> <?php echo e(trans('backupLang.create_a_new_backup_files')); ?></span></button>
	
			<button id="create-new-backup-button4" href="<?php echo e(url('admin/backups/create').'?type=app'); ?>" class="btn
			btn-danger
			ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-industry"></i> <?php echo e(trans('backupLang.create_a_new_backup_app')); ?></span></button>
			
            <br>
            <h3><?php echo e(trans('backupLang.existing_backups')); ?>:</h3>
            <div class="table-responsive" id="users-table-wrapper">
            <table class="table table-borderless table-striped">

                <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(trans('backupLang.location')); ?></th>
                    <th><?php echo e(trans('backupLang.date')); ?></th>
                    <th class="text-right"><?php echo e(trans('backupLang.file_size')); ?></th>
                    <th class="text-right"><?php echo e(trans('backupLang.actions')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($k+1); ?> - <?php echo e(urlencode($b['file_name'])); ?></th>
                        <td><?php echo e($b['disk']); ?></td>
                        <td><?php echo e(\Carbon\Carbon::createFromTimeStamp($b['last_modified'])->formatLocalized('%d %B %Y, %H:%M')); ?></td>
                        <td class="text-right"><?php echo e(round((int)$b['file_size']/1048576, 2).' MB'); ?></td>
                        <td class="text-right">
                            <?php if($b['download']): ?>
                                <a class="btn btn-xs btn-default" href="<?php echo e(url('admin/backups/download/')); ?>?disk=<?php echo e($b['disk']); ?>&path=<?php echo e(urlencode($b['file_path'])); ?>&file_name=<?php echo e(urlencode($b['file_name'])); ?>"><i class="fa fa-cloud-download"></i> <?php echo e(trans('backupLang.download')); ?></a>
                            <?php endif; ?>

                                <a href="<?php echo e(url
                            ('admin/backups/delete/'
                            .$b['file_name'])); ?>?disk=<?php echo e($b['disk']); ?>"

                                   class="btn btn-xs btn-danger"

                                   title="<?php echo app('translator')->getFromJson('app.delete_user'); ?>"
                                   data-toggle="tooltip"
                                   data-placement="top"
                                   data-method="DELETE"
                                   data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
                                   data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
                                   data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
                                    <i class="fas fa-trash"></i>
                                </a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        
        </div><!-- /.box-body -->
    </div><!-- /.box -->
        </div><!-- /.box-body -->
    </div><!-- /.box -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_styles'); ?>
	<!-- Ladda Buttons (loading buttons) -->

	<link rel="stylesheet" href="<?php echo url('assets/plugins/ladda/ladda-themeless.min.css'); ?>"rel="stylesheet" type="text/css" />>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>

        <script>




        jQuery(document).ready(function($) {

            // capture the Create new backup button
            $(".backup-button").click(function(e) {
                e.preventDefault();



                var buttonIdSelector = '#' + $(this).attr('id');
                var create_backup_url = $(this).attr('href');

                // Create a new instance of ladda for the specified button
                var l = Ladda.create( document.querySelector(buttonIdSelector) );

                // Start loading
                l.start();

                // Will display a progress bar for 10% of the button width
                l.setProgress( 0.3 );

                setTimeout(function(){ l.setProgress( 0.6 ); }, 2000);

                // do the backup through ajax
                $.ajax({
                    url: create_backup_url,
                    type: 'PUT',
                    success: function(result) {
                        l.setProgress( 0.9 );

                        // Show an alert with the result
                        if (result.indexOf('failed') >= 0) {
                            new PNotify({
                                title: "<?php echo e(trans('backupLang.create_warning_title')); ?>",
                                text: "<?php echo e(trans('backupLang.create_warning_message')); ?>",
                                type: "warning"
                            });
                        }
                        else
                        {
                            new PNotify({
                                title: "<?php echo e(trans('backupLang.create_confirmation_title')); ?>",
                                text: "<?php echo e(trans('backupLang.create_confirmation_message')); ?>",
                                type: "success"
                            });
                        }

                        // Stop loading
                        l.setProgress( 1 );
                        l.stop();

                        // refresh the page to show the new file
                        setTimeout(function(){ location.reload(); }, 3000);
                    },
                    error: function(result) {
                        l.setProgress( 0.9 );

                        // Show an alert with the result
                        new PNotify({
                            title: "<?php echo e(trans('backupLang.create_error_title')); ?>",
                            text: "<?php echo e(trans('backupLang.create_error_message')); ?>",
                            type: "warning"
                        });

                        // Stop loading
                        l.stop();
                    }
                });
            });









        });



        </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_styles'); ?>


	<link rel="stylesheet" href="<?php echo url('assets/plugins/morris/0.5.1/morris.css'); ?>">
	<!-- DASHBOARD LIST CONTENT - dashboard_styles stack -->
	<?php echo $__env->yieldPushContent('dashboard_styles'); ?>

	<style>
		/* Bootstrap tooltip need to be in single line */
		.tooltip-inner {
			white-space: nowrap;
			max-width: none;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
	<?php echo HTML::script('assets/plugins/ladda/spin.js'); ?>

	<?php echo HTML::script('assets/plugins/ladda/ladda.js'); ?>

	<!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
	<?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/backup/backup.blade.php ENDPATH**/ ?>
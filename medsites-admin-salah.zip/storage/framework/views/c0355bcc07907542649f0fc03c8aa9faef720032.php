<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="shortcut icon" href="<?php echo e(url('favicon.ico')); ?>"/>
    <title>    <?php echo $product['p_title'.langIsAr()]; ?></title>
    <meta name="DESCRIPTION" content=" <?php echo $product['p_description_meta'.langIsAr()]; ?>" />
    <meta name="keywords" content=" <?php echo $product['p_keyword_meta'.langIsAr()]; ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta property="og:site_name" content="Medsites" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="  <?php echo $product['p_title'.langIsAr()]; ?>" />
    <meta property="og:description" content=" <?php echo $product['p_description_meta'.langIsAr()]; ?>" />
    <meta property="twitter:card" content="summary">
    <meta property="twitter:title" content=" <?php echo $product['p_title'.langIsAr()]; ?>" />
    <meta property="twitter:description" content=" <?php echo $product['p_description_meta'.langIsAr()]; ?>" />
    <meta property="twitter:domain" content="www.med-sites.com">

    <?php if(direction()== 'rtl'): ?>
        <link href="https://fonts.googleapis.com/css?family=Cairo|Changa" rel="stylesheet">
        <link href="<?php echo e(url('design')); ?>/css/app.rtl.css" rel="stylesheet">
<?php else: ?>
        <link href="<?php echo e(url('design')); ?>/css/app.css" rel="stylesheet">
        <?php endif; ?>


    <style type="text/css">
        #custom_carousel .item {

            color:#006;

            padding:20px 0;
        }
        #custom_carousel .controls{
            overflow-x: auto;
            overflow-y: hidden;
            padding:10;
            margin:10;
            white-space: nowrap;
            text-align: center;
            position: relative;

        }
        #custom_carousel .controls li {
            display: table-cell;
            width: 1%;
            max-width:90px
        }
        #custom_carousel .controls li.active {

            border-top:3px solid orange;
        }
        #custom_carousel .controls a small {
            overflow:hidden;
            display:block;
            font-size:10px;
            margin-top:5px;
            font-weight:bold
        }
        /* === Body === */

        /* === Header === */
        .navbar-site { position: absolute !important; }
        /* === Footer === */

        /* === Button: Add Listing === */

        /* === Other: Grid View Columns === */



        /* === CSS Fix === */
        .f-category h6 {
            color: #333;
        }
        .photo-count {
            color: #292b2c;
        }
        .page-info-lite h5 {
            color: #ccc;
        }
        h4.item-price {
            color: #292b2c;
        }
        .skin-blue .pricetag {
            color: #fff;


        }


    </style>

    <link href="<?php echo e(url('design')); ?>/css/custom.css" rel="stylesheet">






    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <script>
        paceOptions = {
            elements: true
        };
    </script>
    <script src="<?php echo e(url('design')); ?>/assets/js/pace.min.js"></script>

    <?php echo $__env->yieldContent('after_styles'); ?>
    <?php echo $__env->yieldContent('styles'); ?>

</head><?php /**PATH C:\xampp\htdocs\medsites\resources\views/front/layouts/header_products.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title', 'Orders For ' .  $rowOne->name ); ?>
<?php $__env->startSection('page-heading',  'Orders For ' .  $rowOne->name   ); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('order.index',$id)); ?>"> Orders   </a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('order.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <h5 class="mt-md-0 mt-0 my-0"><?php echo e($rowOne->name); ?>    <span class="badge badge-lg badge-light">
            <?php echo e(count($orders)); ?>

        </span>  </h5>
            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th>Invoice Id</th>

                        <th>QYT </th>
                        <th>Importer </th>

                        <th>V-T-M</th>
                        <th>V-T-MS</th>
                        <th>V-T-EGY</th>
                        <th> </th>
                        <th> Arrival Date</th>
                        <th>  No.</th>
                        <th> Stauts</th>
                        <th><?php echo app('translator')->getFromJson('app.action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php if(count($orders)): ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('order.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>

                    <th> </th>
                    <th><?php echo e(number_format($sumquantity)); ?>  </th>
                    <th> </th>

                    <th><?php echo e(number_format($sumtotal_mother_company)); ?> </th>
                    <th><?php echo e(number_format($sumOrdertotal_wanted)); ?> </th>
                    <th><?php echo e(number_format($sumless_stamp_duties)); ?> </th>
                    <th> </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                <?php echo $orders->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });    $("#importer").change(function () {
            $("#users-form").submit();
        });


    </script>


    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('page-title',trans('app.cashMoney')); ?>
<?php $__env->startSection('page-heading', trans('app.cashMoney')); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item active">
       <?php echo e(trans('app.cashMoney')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">
        <div class="card-body">
            <?php echo $__env->make('cashMoney.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-borderless table-striped">
                    <thead>
                    <tr>
                        <th >#</th>
                        <th >Money From </th>
                        <th >Money To</th>
                        <th >Money</th>

                        <th>Reason	</th>
                        <th>Add By	</th>


                        <th>Date</th>



                        <th class="text-center min-width-150"><?php echo app('translator')->getFromJson('app.action'); ?></th>
                    </tr>
                    </thead>


                    <tbody>
                    <?php if(count($cashMoneys)): ?>
                        <?php $__currentLoopData = $cashMoneys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashMoney): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('cashMoney.partials.row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>          <tfoot>
                        <tr>
                            <th >#</th>
                            <th >Money From </th>
                            <th > </th>
                            <th ><?php echo e(number_format($paginateSum)); ?></th>


                            <th> </th>
                            <th> </th>

                            <th> </th>

                            <th class="text-center min-width-150"> </th>
                        </tr>
                        </tfoot>
                    <?php else: ?>
                        <tr>
                            <td colspan="7"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <?php echo $cashMoneys->render(); ?>

    <div class="card">
    <div class="card-body">
    <div class="  table-responsive" id="users-table-wrapper">
        <table class="table table-striped table-borderless">
            <thead>
            <tr>

                <th>Name</th>
                <th>Cash Money</th>
                <th>Expenses</th>

            </tr>
            </thead>
            <tbody>
            <?php if(count($ListsEmployeesAll)): ?>
                <?php $__currentLoopData = $ListsEmployeesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td class="align-middle"><?php echo e($row->users_id()->first()->present()->nameOrEmail); ?>  </td>
                        <td><?php echo e(number_format($row->cash_money )); ?></td>

                        <td>

                            <a href="<?php echo e(route('expenses.index') .'?user='.$row->employee_id); ?>" class="badge badge-lg badge-light">



                                <h5>     <?php echo e(number_format($row->tobalance)); ?>  </h5>  </a>   </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan="4"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    </div>
    </div>
    </div>  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $("#status").change(function () {
            $("#users-form").submit();
        });

        $("#to").change(function () {
            $("#users-form").submit();
        });
        $("#from").change(function () {
            $("#users-form").submit();
        });
        $("#year").change(function () {
            $("#users-form").submit();
        });
        $("#month").change(function () {
            $("#users-form").submit();
        });
        $("#product_search").change(function () {
            $("#users-form").submit();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/cashMoney/index.blade.php ENDPATH**/ ?>
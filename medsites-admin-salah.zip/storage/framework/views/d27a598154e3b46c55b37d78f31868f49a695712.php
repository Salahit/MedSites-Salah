<?php $__env->startSection('page-title', 'Accounting'); ?>
<?php $__env->startSection('page-heading',  'Accounting'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('expenses.index')); ?>"> Accounting </a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card">


            <div class="card-group ">
                <div class="card">


                    <i class="far fa-money-bill-alt  fa-5x ml-4  mt-2  card-img-top my-0 ">
                        <h1 class="my-0">Expenses </h1>
                        <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-primary btn-rounded   my-0">
                            <i class="fas fa-plus mr-0"></i> Add  </a>
                        <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-primary btn-rounded   my-0">  <i
                                    class="fas fa-list mr-0"></i> List    </a></i>


                    <div class="card-body">

                        <h4 class="card-title">Total :  <?php echo e(number_format($ExpenseSum )); ?> </h4>
        <h4 class="card-title">Total <?php echo e(\Carbon\Carbon::parse(now())->format('Y')); ?> Year   : <?php echo e(number_format
        ($ExpenseSumYear)); ?></h4>




        <h4 class="card-title">Total <?php echo e(\Carbon\Carbon::parse(now())->format('M')); ?> Month   : <?php echo e(number_format
        ($ExpenseSumMonth)); ?></h4>
            <h4 class="card-title">Total <?php echo e(\Carbon\Carbon::parse(now()->subMonth(1))->format('M')); ?> Month   : <?php echo e(number_format($ExpenseSumMonthLast)); ?></h4>

            <h4 class="card-title">Total <?php echo e(\Carbon\Carbon::parse(now()->subYear(1))->format('Y')); ?>  Year   : <?php echo e(number_format
            ($ExpenseSumYearLast)); ?></h4>

                        <div class="  table-responsive" id="users-table-wrapper">
                            <table class="table table-striped table-borderless">
                                <thead>
                                <tr>

                                    <th>Name</th>
                                    <th>Cash Money</th>
                                    <th>Expenses</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($ListsEmployeesAll)): ?>
                                    <?php $__currentLoopData = $ListsEmployeesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td class="align-middle"><?php echo e($row->users_id()->first()->present()->nameOrEmail); ?>  </td>
                                            <td><?php echo e(number_format($row->cash_money )); ?></td>

                                            <td>

        <a href="<?php echo e(route('expenses.index') .'?user='.$row->employee_id); ?>" class="badge badge-lg badge-light">



            <h5>     <?php echo e(number_format($row->tobalance)); ?>  </h5>  </a>   </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card">

                    <i class=" fas fa-donate  fa-5x ml-4  mt-2  card-img-top my-0 ">
                        <h1 class="my-0">Income</h1>
                        <a href="<?php echo e(route('accounting.incomeCreate')); ?>" class="btn btn-primary btn-rounded   my-0">
                            <i class="fas fa-plus mr-0"></i> Add  </a>
                        <a href="<?php echo e(route('accounting.income')); ?>" class="btn btn-primary btn-rounded   my-0">  <i
                                    class="fas fa-list mr-0"></i> List    </a></i>


                    <div class="card-body">


                        <h4 class="card-title">Total :       <?php echo e(number_format($sumOrderYear + $IncomeSumAllYear)); ?>

                          </h4>
                        <h4 class="card-title">Orders : <a href="<?php echo e(route('order.indexInvoiceOrders')); ?>"
                                                           class="badge badge-lg badge-light">

                                  <h3>  <?php echo e(number_format($sumOrderYear)); ?></h3>

                            </a> </h4>
                        <h4 class="card-title">Other : <?php echo e(number_format($IncomeSumAllYear)); ?></h4>



                        <div class="  table-responsive" id="users-table-wrapper">
                            <table class="table table-striped table-borderless">
                                <thead>

                                <tr>

                                    <th>   Total  </th>

                                    <th>   <?php echo e(number_format($sumOrderYear)); ?>  + </th>

                                    <th>   <?php echo e(number_format($IncomeSumAllYear)); ?>  </th>

                                    <th>  = <?php echo e(number_format($IncomeSumAllYear + $sumOrderYear)); ?></th>
                                </tr>
                                </thead>
                                <tbody>


                                <tr>

                                    <td> <?php echo e(\Carbon\Carbon::parse(now())->format('Y')); ?> Total  </td>

                                    <td>  <?php echo e(number_format($sumOrderSubYear  )); ?> + </td>


                                    <td>  <?php echo e(number_format($IncomeSumYear  )); ?>  </td>

                                    <td> = <?php echo e(number_format($sumOrderSubYear + $IncomeSumYear  )); ?></td>

                                </tr>
                                <tr>

                                    <td> <?php echo e(\Carbon\Carbon::parse(now()->subYear(1))->format('Y')); ?>   </td>

                                    <td>  <?php echo e(number_format($sumOrderSub1Year  )); ?> + </td>


                                    <td>  <?php echo e(number_format($IncomeSum1Year  )); ?>  </td>

                                    <td> = <?php echo e(number_format($sumOrderSub1Year + $IncomeSum1Year  )); ?></td>

                                </tr>
                                <tr>

                                    <td> <?php echo e(\Carbon\Carbon::parse(now()->subYear(2))->format('Y')); ?>   </td>

                                    <td>  <?php echo e(number_format($sumOrderSub2Year  )); ?> + </td>


                                    <td>  <?php echo e(number_format($IncomeSum2Year  )); ?>  </td>

                                    <td> = <?php echo e(number_format($sumOrderSub2Year + $IncomeSum2Year  )); ?></td>

                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="card">


                    <i class="fas fa-dollar-sign fa-5x ml-4 card-img-top my-2 ">
                        <h1 class="my-0">Required </h1>
                        <a         data-toggle="modal"
                                   data-target="#exampleModal"

                                   class="btn btn-primary btn-rounded   my-0  " style="color:#ffffff ">
                            <i class="fas fa-plus mr-0">Edit</i>
                        </a>

                        <a href="<?php echo e(route('cashMoney.index')); ?>" class="btn btn-primary btn-rounded   my-0">  <i
                                    class="fas fa-list mr-0"></i> List    </a></i>


                    <div class="card-body">

                        <h4 class="card-title"> <?php echo settings('app_text_wanted'); ?>  </h4>
                        <h4 class="card-title"> <a href="<?php echo e(route('order.indexInvoiceOrders')); ?>"
                                                   class="badge badge-lg badge-light">

                                <h3>  <?php echo e(number_format(settings('Amount_required'))); ?></h3>

                            </a>   </h4>
                        <h6 class="card-title"> Last Update : <?php echo settings('date_update_required'); ?>  </h6>
                        <h6 class="card-title">  Update By  : <?php echo settings('date_update_required_user'); ?>  </h6>

                        <div class="  table-responsive" id="users-table-wrapper">
                            <table class="table table-striped table-borderless">
                                <thead>
                                <tr>

                                    <th>Name</th>
                                    <th>Salary </th>
                                    <th>Expenses</th>

                                </tr>
                                </thead>
                                <tbody>
                                <?php if(count($ListsEmployeesAll)): ?>
                                    <?php $__currentLoopData = $ListsEmployeesAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($row->salary != 0): ?>
                                        <tr>

                                            <td class="align-middle"><?php echo e($row->users_id()->first()->present()->nameOrEmail); ?>  </td>
                                            <td><?php echo e(number_format($row->salary )); ?></td>

                                            <td>

                                                <a href="<?php echo e(route('expenses.index') .'?user='.$row->employee_id); ?>" class="badge badge-lg badge-light">



                                                    <h5>     <?php echo e(number_format($row->tobalance)); ?>  </h5>  </a>   </td>
                                        </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4"><em><?php echo app('translator')->getFromJson('app.no_records_found'); ?></em></td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>


        </div>

    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document"> <?php echo Form::open(['route' => 'settings.general.update', 'id' => 'general-settings-form']); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Required</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="app_text_wanted"> required</label>

                    <textarea rows="4" cols="50" aria-rowcount="20" class="form-control" name="app_text_wanted"
                              id="description" ><?php echo settings('app_text_wanted'); ?></textarea>



                    </div>
                    <div class="form-group">
                        <label for="dollar">Amount required</label>
                        <input type="text" class="form-control" id="Amount_required"
                               name="Amount_required" value="<?php echo e(settings('Amount_required')); ?>">
                    </div>
                </div>
                <div class="modal-footer">

                    <input type="hidden" value="<?php echo e(\Carbon\Carbon::now()); ?>" name="date_update_required" >
                    <input type="hidden" value="<?php echo e(\Auth::user()->username); ?>" name="date_update_required_user" >

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>


                </div>
            </div>
            <?php echo e(Form::close()); ?>   </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('design')); ?>/assets/plugins/simditor/styles/simditor.css" />



    <?php echo $__env->yieldPushContent('dashboard_styles'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>



    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/mobilecheck.js"></script>

    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/module.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/hotkeys.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/uploader.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/simditor.js"></script>
    <script type="text/javascript">
        Simditor.i18n = {
            'en': {
                'blockquote': 'Block Quote',
                'bold': 'Bold',
                'code': 'Code',
                'color': 'Text Color',
                'coloredText': 'Colored Text',
                'hr': 'Horizontal Line',
                'image': 'Insert Image',
                'externalImage': 'External Image',
                'uploadImage': 'Upload Image',
                'uploadFailed': 'Upload failed',
                'uploadError': 'Error occurs during upload',
                'imageUrl': 'Url',
                'imageSize': 'Size',
                'imageAlt': 'Alt',
                'restoreImageSize': 'Restore Origin Size',
                'uploading': 'Uploading',
                'indent': 'Indent',
                'outdent': 'Outdent',
                'italic': 'Italic',
                'link': 'Insert Link',
                'linkText': 'Text',
                'linkUrl': 'Url',
                'linkTarget': 'Target',
                'openLinkInCurrentWindow': 'Open link in current window',
                'openLinkInNewWindow': 'Open link in new window',
                'removeLink': 'Remove Link',
                'ol': 'Ordered List',
                'ul': 'Unordered List',
                'strikethrough': 'Strikethrough',
                'table': 'Table',
                'deleteRow': 'Delete Row',
                'insertRowAbove': 'Insert Row Above',
                'insertRowBelow': 'Insert Row Below',
                'deleteColumn': 'Delete Column',
                'insertColumnLeft': 'Insert Column Left',
                'insertColumnRight': 'Insert Column Right',
                'deleteTable': 'Delete Table',
                'title': 'Title',
                'normalText': 'Text',
                'underline': 'Underline',
                'alignment': 'Alignment',
                'alignCenter': 'Align Center',
                'alignLeft': 'Align Left',
                'alignRight': 'Align Right',
                'selectLanguage': 'Select Language',
                'fontScale': 'Font Size',
                'fontScaleXLarge': 'X Large Size',
                'fontScaleLarge': 'Large Size',
                'fontScaleNormal': 'Normal Size',
                'fontScaleSmall': 'Small Size',
                'fontScaleXSmall': 'X Small Size'
            }
        };

        (function() {
            $(function() {
                var $preview, editor, mobileToolbar, toolbar, allowedTags;
                Simditor.locale = 'en';
                mobileToolbar = ["bold", "italic", "underline", "ul", "ol"];
                if (mobilecheck()) {
                    toolbar = mobileToolbar;
                }


                allowedTags = [];
                editor = new Simditor({
                    textarea: $('#description'),
                    placeholder: 'Describe what makes the product unique ...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    html: true,

                    allowedTags: allowedTags
                });

                $preview = $('#preview');
                if ($preview.length > 0) {
                    return editor.on('valuechanged', function(e) {
                        return $preview.html(editor.getValue());
                    });
                }
            });
        }).call(this);
    </script>
    <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/expense/accounting/index.blade.php ENDPATH**/ ?>
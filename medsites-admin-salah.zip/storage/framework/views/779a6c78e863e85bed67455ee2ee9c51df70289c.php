<tr>

    <td class="align-middle">
        <a href="<?php echo e(route('pages.edit', $page->id)); ?>">
            <?php echo e($page->name ?: trans('app.n_a')); ?>

        </a>
    </td>
    <td class="align-middle">
        <a href="<?php echo e(route('pages.edit', $page->id)); ?>">
            <?php echo e($page->name_ar ?: trans('app.n_a')); ?>

        </a>
    </td>
    <td class="align-middle"><?php echo e($page->title); ?></td>
    <td class="align-middle"><?php echo e($page->title_ar); ?></td>
    <td class="align-middle"><?php echo e($page->menu_sort); ?></td>
    <td class="align-middle"><?php echo e($page->updated_at); ?></td>
    <td class="align-middle">
        <span class="badge badge-lg badge-<?php echo e($page->present()->labelClass); ?>">
            <?php echo e(trans("app.{$page->status}")); ?>

        </span>
    </td>
    <td class="text-center align-middle">


        <a href="<?php echo e(route('pages.edit', $page->id)); ?>"
           class="btn btn-icon edit"
           title="<?php echo app('translator')->getFromJson('app.edit'); ?>"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('pages.delete1', $page->id)); ?>"
           class="btn btn-icon"
           title="<?php echo app('translator')->getFromJson('app.delete'); ?>"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/pages/partials/row.blade.php ENDPATH**/ ?>
<tr>

    <td class="align-middle">

            <?php echo e($message->productss->first()->product_name); ?>


    </td>
    <td class="align-middle"> <span class="mb-0 badge badge-lg
    badge-light"> <a href="<?php echo e(route('message.show', $message->id)); ?>"><?php echo e($message->title); ?></a></span></td>


    <td class="align-middle">  <a href="<?php echo e(route('user.show', $message->user_id)); ?>"><?php echo e($message->users->first()
    ->present()->nameOrEmail); ?></a></td>

    <td class="align-middle">

 <span class="rounded-circle img-thumbnail img-responsive mb-0 badge badge-lg badge-info">
<?php echo e($message->messages_count); ?>

       </span>
    </td>
    <td class="align-middle">

 <span class="rounded-circle img-thumbnail img-responsive mb-0 badge badge-lg badge-light">
<?php echo e($message->approved_messages_count); ?>

       </span>
    </td>
    <td class="align-middle">
        <?php echo e($message->created_at->format(config('app.date_time_format')) . ' - ' . $message->created_at->diffForHumans()); ?>

    </td>



    <td class="align-middle">
        <span class="badge badge-lg badge-<?php echo e($message->present()->labelClass); ?>">
            <?php echo e(trans("app.{$message->status}")); ?>

        </span>
    </td>

    <td class="text-center align-middle">


        <a tabindex="0" role="button" class="btn btn-icon"
           data-trigger="focus"
           data-placement="left"
           data-html="true"
           data-toggle="popover"
           title="Message"
           data-content="<?php echo nl2br($message->message); ?> ">
            <i class="fas fa-info-circle"></i>
        </a>

        <a href="<?php echo e(route('message.show', $message->id )); ?>" class="btn btn-icon edit">
            <i class="fas fa-eye  "></i>

        </a>





        <a href="<?php echo e(route('message.delete', $message->id)); ?>"
           class="btn btn-icon"
           title="<?php echo app('translator')->getFromJson('app.delete_user'); ?>"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/message/partials/row.blade.php ENDPATH**/ ?>
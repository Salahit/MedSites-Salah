<?php $__env->startSection('page-title', 'My Prodrct'); ?>
<?php $__env->startSection('page-heading', 'My Prodrct'); ?>)
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="main-container inner-page">
    <div class="container">
        <div class="section-content">
            <div class="inner-box">
                <h2 class="title-2">
                    <i class="icon-mail"></i> My Prodrct
                </h2>
                    <div class="card">
                        <div class="card-body">
                            <h1><?php echo e(auth()->user()->email); ?> - <?php echo e(count($licenseActivities)); ?></h1>
                            <div class="table-responsive">
                                <table class="table table-borderless table-striped">
                                    <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>License</th>
                                        <th>Product</th>

                                        <th>Support End</th>


                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if(count($licenseActivities)): ?>
                                        <?php $__currentLoopData = $licenseActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $licenseActivity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>

                                                <td class="align-middle">
        <span class="badge badge-lg badge-<?php echo e($licenseActivity->present()->labelClassNum); ?>">
            <?php echo e(trans("app.{$licenseActivity->status}")); ?>

        </span>
                                                </td>
 <td class="align-middle"><?php echo e(\Carbon\Carbon::parse($licenseActivity->date_created)->format ('Y M')); ?>

 </td>


                                                <td>  <?php echo e($licenseActivity->activation); ?> </td>
                                                <td>  <?php echo e($licenseActivity->product_name); ?> - <?php echo e($licenseActivity->version_name); ?></td>
                                                <td>  <?php echo e($licenseActivity->support_e); ?> </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                    <p class="text-muted font-weight-light"><em><?php echo app('translator')->getFromJson('app.no_activity_from_this_user_yet'); ?></em></p>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>      </div>
                    </div>
                </div>    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_styles'); ?>



        <?php echo $__env->yieldPushContent('dashboard_styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/front/user/myprodrct.blade.php ENDPATH**/ ?>
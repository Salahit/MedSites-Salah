<tr>

    <td class="width-80"><?php echo e($activity->invoice_id); ?></td>



    <td class="width-80"><?php echo e(number_format($activity->total_wanted)); ?></td>
    <td class="width-80"><?php echo e($activity->importer()->first()->name); ?></td>
    <td class="width-80"><?php echo e(number_format($activity->quantity)); ?></td>
    <td>
        <?php echo e($activity->invoice_count); ?>


    </td>
    <td class="width-80"> <?php echo e(\Carbon\Carbon::parse($activity->arrival_at)->format('Y M  d D')); ?></td>

    <td class="text-center align-middle">

        <?php if($activity->id == $order->id): ?>
        <a href="#"

           class="btn btn-icon "
           title="This Order View Now"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-arrow-alt-circle-left fa-2x"></i>

        </a>
        <?php else: ?>

        <a href="<?php echo e(route('order.show', $activity->id)); ?>"

           class="btn btn-icon eye"
           title="View Order"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye fa-2x"></i>

        </a>

<?php endif; ?>


    </td>
</tr>
<?php /**PATH C:\xampp\htdocs\medsites\resources\views/order/partials/rowOrder.blade.php ENDPATH**/ ?>
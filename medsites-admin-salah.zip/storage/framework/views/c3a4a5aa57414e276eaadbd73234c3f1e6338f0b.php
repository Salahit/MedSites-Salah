<?php $__env->startSection('page-title', $edit ?   'Edit Prodact'  : 'Add Prodact'); ?>
<?php $__env->startSection('page-heading', $edit ? $product->p_name : 'Edit Prodact'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('products.index')); ?>">Products</a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($edit ? trans('app.edit') : trans('app.create')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<?php if($edit): ?>
    <?php echo Form::open(['route' => ['products.update', $product->id], 'method' => 'PUT', 'id' => 'products-form']); ?>

<?php else: ?>
    <?php echo Form::open(['route' => 'products.store', 'id' => 'products-form']); ?>

<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <h5 class="card-title">
                    Product Details
                </h5>
            </div>


            <div class="col-md-6">
                <div class="form-group">
                    <label for="name"> Name </label>
                    <input type="text" class="form-control" id="p_name"
                           name="p_name" placeholder="p_name" value="<?php echo e($edit ? $product->p_name : old('p_name')); ?>">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="name"> Name Arabic </label>
                    <input type="text" class="form-control" id="p_name"
                           name="p_name_ar" placeholder="Name Arabic" value="<?php echo e($edit ? $product->p_name_ar : old
                           ('p_name')); ?>">
                </div>
            </div>


                <div class="col-md-6">
                <div class="form-group">
                    <label for="p_nc_name">Nick Name</label>
                    <input type="text" class="form-control" id="p_nc_name"
                           name="p_nc_name" placeholder="Nick name" value="<?php echo e($edit ? $product->p_nc_name : old
                           ('p_nc_name')); ?>">
                </div>
                </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_nc_name_ar">Nick Name Arabic</label>
                    <input type="text" class="form-control" id="p_nc_name_ar"
                           name="p_nc_name_ar" placeholder="Nick name" value="<?php echo e($edit ? $product->p_nc_name_ar : old
                           ('p_nc_name_ar')); ?>">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_title">Title</label>
                    <textarea name="p_title"  placeholder="Title"  id="Title" class="form-control"><?php echo e($edit ?
                    $product->p_title : old
                    ('p_title')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_title">Title Arabic</label>
                    <textarea name="p_title_ar" placeholder="Title Arabic" id="Title" class="form-control"><?php echo e($edit ?
                    $product->p_title_ar : old
                    ('p_title_ar')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="editor">Description </label>
                    <textarea name="p_description" id="description" rows="5" class="form-control"><?php echo e($edit ?
                    $product->p_description : old('p_description')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="editor">Description Arabic</label>
                    <textarea name="p_description_ar" id="descriptionar" rows="5" class="form-control"><?php echo e($edit ?
                    $product->p_description_ar : old('p_description_ar')); ?></textarea>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="editor">Description Keyword Price </label>
                    <textarea name="p_description_price" id="p_keyword_price" rows="5" class="form-control"><?php echo e($edit ?
                    $product->p_keyword_price : old('p_keyword_price')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_keyword_price">Description Keyword Price  Arabic</label>
                    <textarea name="p_keyword_price_ar" id="p_keyword_price_ar" rows="5" class="form-control"><?php echo e($edit ?
                    $product->p_keyword_price_ar : old('p_keyword_price_ar')); ?></textarea>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_description_meta">	Description Meta </label>
                    <textarea name="p_description_meta"  placeholder="Description Meta"  id="p_description_meta" class="form-control"><?php echo e($edit ?
                    $product->p_description_meta : old
                    ('p_description_meta')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_description_meta_ar">Description Meta Arabic</label>
                    <textarea name="p_description_meta_ar" placeholder="Description Meta Arabic" id="p_description_meta"
                              class="form-control"><?php echo e($edit ?
                    $product->p_description_meta_ar : old
                    ('p_description_meta_ar')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_keyword_meta">	Keyword Meta </label>
                    <textarea name="p_keyword_meta"  placeholder="keyword Meta"  id="p_keyword_meta" class="form-control"><?php echo e($edit ?
                    $product->p_description_meta : old
                    ('p_description_meta')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_keyword_meta_ar">Keyword Meta Arabic</label>
                    <textarea name="p_keyword_meta_ar" placeholder="keyword Meta Arabic" id="p_description_meta"
                              class="form-control"><?php echo e($edit ?
                    $product->p_keyword_meta_ar : old
                    ('p_keyword_meta_ar')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="features">Features</label>
                    <textarea name="features"  placeholder="features"  id="features" class="form-control"><?php echo e($edit ?
                    $product->features : old
                    ('features')); ?></textarea>
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="features">Features Ar</label>
                    <textarea name="features_ar"  placeholder="features_ar"  id="features_ar" class="form-control"><?php echo e($edit ?
                    $product->features_ar : old
                    ('features_ar')); ?></textarea>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="p_since">Since</label>
         <input type="text" class="form-control" id="p_since"
                           name="p_since" placeholder="Since" value="<?php echo e($edit ? $product->p_since : old
                           ('p_since')); ?>">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="f_price">Price First</label>
                    <input type="text" class="form-control" id="f_price"
                           name="f_price" placeholder="Price First" value="<?php echo e($edit ? $product->f_price : old
                           ('f_price')); ?>">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="status"><?php echo app('translator')->getFromJson('app.status'); ?></label>
                    <?php echo Form::select('status', $statuses, $edit ? $product->status : '',
                ['class' => 'form-control', 'id' => 'status']); ?>

                </div>
            </div>
            </div>
        </div>
    </div>
<div class="col-md-2">
    <button type="submit" class="btn btn-primary">
        <?php echo e($edit ? trans('app.update') : trans('app.create')); ?>

    </button>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('design')); ?>/assets/plugins/simditor/styles/simditor.css" />



    <?php echo $__env->yieldPushContent('dashboard_styles'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>



    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/mobilecheck.js"></script>

    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/module.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/hotkeys.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/uploader.js"></script>
    <script src="<?php echo e(url('design')); ?>/assets/plugins/simditor/scripts/simditor.js"></script>
    <script type="text/javascript">
        Simditor.i18n = {
            'en': {
                'blockquote': 'Block Quote',
                'bold': 'Bold',
                'code': 'Code',
                'color': 'Text Color',
                'coloredText': 'Colored Text',
                'hr': 'Horizontal Line',
                'image': 'Insert Image',
                'externalImage': 'External Image',
                'uploadImage': 'Upload Image',
                'uploadFailed': 'Upload failed',
                'uploadError': 'Error occurs during upload',
                'imageUrl': 'Url',
                'imageSize': 'Size',
                'imageAlt': 'Alt',
                'restoreImageSize': 'Restore Origin Size',
                'uploading': 'Uploading',
                'indent': 'Indent',
                'outdent': 'Outdent',
                'italic': 'Italic',
                'link': 'Insert Link',
                'linkText': 'Text',
                'linkUrl': 'Url',
                'linkTarget': 'Target',
                'openLinkInCurrentWindow': 'Open link in current window',
                'openLinkInNewWindow': 'Open link in new window',
                'removeLink': 'Remove Link',
                'ol': 'Ordered List',
                'ul': 'Unordered List',
                'strikethrough': 'Strikethrough',
                'table': 'Table',
                'deleteRow': 'Delete Row',
                'insertRowAbove': 'Insert Row Above',
                'insertRowBelow': 'Insert Row Below',
                'deleteColumn': 'Delete Column',
                'insertColumnLeft': 'Insert Column Left',
                'insertColumnRight': 'Insert Column Right',
                'deleteTable': 'Delete Table',
                'title': 'Title',
                'normalText': 'Text',
                'underline': 'Underline',
                'alignment': 'Alignment',
                'alignCenter': 'Align Center',
                'alignLeft': 'Align Left',
                'alignRight': 'Align Right',
                'selectLanguage': 'Select Language',
                'fontScale': 'Font Size',
                'fontScaleXLarge': 'X Large Size',
                'fontScaleLarge': 'Large Size',
                'fontScaleNormal': 'Normal Size',
                'fontScaleSmall': 'Small Size',
                'fontScaleXSmall': 'X Small Size'
            }
        };

        (function() {
            $(function() {
                var $preview, editor, mobileToolbar, toolbar, allowedTags;
                Simditor.locale = 'en';
                toolbar = ['bold','italic','underline','fontScale','color','|','ol','ul','blockquote','table','link'];
                mobileToolbar = ["bold", "italic", "underline", "ul", "ol"];
                if (mobilecheck()) {
                    toolbar = mobileToolbar;
                }


                allowedTags = ['br','span','a','img','b','strong','i','strike','u','font','p','ul','ol','li','blockquote','pre','h1','h2','h3','h4','hr','table'];
                editor = new Simditor({
                    textarea: $('#description'),
                    placeholder: 'Describe what makes the product unique ...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    allowedTags: allowedTags
                });

                editor = new Simditor({
                    textarea: $('#features_ar'),
                    placeholder: 'Describe what makes the product unique ...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    allowedTags: allowedTags
                });

                editor = new Simditor({
                    textarea: $('#features'),
                    placeholder: 'Describe what makes the product unique ...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    allowedTags: allowedTags
                });

                editor = new Simditor({
                    textarea: $('#descriptionar'),
                    placeholder: 'صف ما الذي يجعل الممتج فريدا من نوعه...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '<?php echo e(url("design")); ?>/assets/plugins/simditor/images/image.png',
                    upload: false,
                    allowedTags: allowedTags
                });
                $preview = $('#preview');
                if ($preview.length > 0) {
                    return editor.on('valuechanged', function(e) {
                        return $preview.html(editor.getValue());
                    });
                }
            });
        }).call(this);
    </script>
    <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <?php if($edit): ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Product\UpdateProductRequest', '#Product-form'); ?>

    <?php else: ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Product\CreateProductRequest', '#Product-form'); ?>

    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/products/add-edit.blade.php ENDPATH**/ ?>
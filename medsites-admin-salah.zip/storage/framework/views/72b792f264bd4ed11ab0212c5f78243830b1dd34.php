<tr>

    <td class="align-middle">
        <a href="<?php echo e(url( $price->product()->first()->name_link)); ?>">
            <?php echo e($price->product()->first()->p_name); ?>

        </a>
    </td>
    <td class="align-middle"><?php echo e($price->numbers); ?></td>
    <td class="align-middle"><?php echo e($price->product_id_standard); ?>



    <?php if($price->standard_status == 'Active'): ?>
        <span class="badge badge-lg badge-success">
            <i class="fas fa-check-circle"></i>
        </span>
    <?php else: ?>
            <span class="badge badge-lg badge-danger">
            <i class="fas fa-check-circle"></i>
        </span>
    <?php endif; ?>

    </td>

    <td class="align-middle">$<?php echo e($price->price_standard); ?></td>
    <td class="align-middle"><?php echo e($price->product_id_advanced); ?>

        <?php if($price->advanced_status == 'Active'): ?>
        <span class="badge badge-lg badge-success">
            <i class="fas fa-check-circle"></i>
        </span>
        <?php else: ?>
            <span class="badge badge-lg badge-danger">
            <i class="fas fa-check-circle"></i>
        </span>
        <?php endif; ?>


    </td>
    <td class="align-middle">$<?php echo e($price->price_advanced); ?></td>

    <td class="align-middle">
        <span class="badge badge-lg badge-<?php echo e($price->present()->labelClass); ?>">
            <?php echo e(trans("app.{$price->status}")); ?>

        </span>
    </td>
    <td class="text-center align-middle">
        <div class="dropdown show d-inline-block">
            <a class="btn btn-icon"
               href="#" role="button" id="dropdownMenuLink"
               data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-ellipsis-h"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                <a target="_blank" href="<?php echo e(url($price->product()->first()->name_link)); ?>" class="dropdown-item
                text-gray-500">
                    <i class="fas fa-eye mr-2"></i>
                    View Site
                </a>

                <a href="<?php echo e(route('products.edit', $price->product)); ?>" class="dropdown-item text-gray-500">
                    <i class="fas fa-eye mr-2"></i>
                   View Product
                </a>

            </div>
        </div>

        <a href="<?php echo e(route('price.edit', $price->id)); ?>"
           class="btn btn-icon edit"
           title="Edit Price"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('price.delete', $price->id)); ?>"
           class="btn btn-icon"
           title="Delete Price"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="<?php echo app('translator')->getFromJson('app.please_confirm'); ?>"
           data-confirm-text="<?php echo app('translator')->getFromJson('app.are_you_sure_delete_user'); ?>"
           data-confirm-delete="<?php echo app('translator')->getFromJson('app.yes_delete_him'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr><?php /**PATH C:\xampp\htdocs\medsites\resources\views/prices/partials/row.blade.php ENDPATH**/ ?>
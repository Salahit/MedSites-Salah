<?php $__env->startSection('page-title', 'Expenses'); ?>
<?php $__env->startSection('page-heading', $edit ? $expenses->invoice_id : 'Expense'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="breadcrumb-item">
        <a href="<?php echo e(route('expenses.index')); ?>">Expenses</a>
    </li>
    <li class="breadcrumb-item active">
        <?php echo e($edit ? trans('app.edit') : trans('app.create')); ?>

    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($edit): ?>
    <?php echo Form::open(['route' => ['expenses.update', $expenses->id], 'method' => 'PUT', 'id' => 'expense-form', 'enctype' => 'multipart/form-data']); ?>

<?php else: ?>
    <?php echo Form::open(['route' => 'expenses.store', 'id' => 'expense-form', 'enctype' => 'multipart/form-data']); ?>

<?php endif; ?>

<div class="card " style="direction: rtl;  ">
    <div class="card-body float-right">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title float-right">                    تفاصيل المصروف.                </h5>

                <p class="text-muted float-right">
                     حاول ان تكون دقيق فى معلومات المصروف .
               </p>
            </div>


            <div class="col-md-9  float-right">
                <div class="form-group" >
                    <div class="row my-0 flex-md-row flex-column-reverse" style="direction: rtl">
                        <div class="col-md-3 mt-md-0 mt-0">
                            <label class=" float-right " for="by_company">نوع الشركة</label>
                        </div>

                    </div>

                    <?php echo Form::select('expense_company_id', [''=>'أختيار'] +  $listsExpenseCompany    , $edit ?
                    $expenses->expense_company_id : '',
                    ['id' => 'expense_company_id', 'class' => 'form-control ' , 'dir' => 'rtl']); ?>




                </div>
                <div class="form-group" >
                    <div class="row my-0 flex-md-row flex-column-reverse" style="direction: rtl">
                        <div class="col-md-3 mt-md-0 mt-0">
                            <label class=" float-right " for="by_company">نوع المصروف</label>
                        </div>
                        <div class="col-md-2 mt-md-0 mt-0">
 <span class="input-group-append">
            <button class="btn btn-light" type="button" id="create_record_type">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                            </span>
                        </div>
                    </div>

                    <?php echo Form::select('expense_type_id', [''=>'أختيار'] +  $listsExpenseType    , $edit ?
                    $expenses->expense_type_id : '',
                    ['id' => 'by_NameType', 'class' => 'form-control ' , 'dir' => 'rtl']); ?>




                </div>
                <div class="form-group">
                    <div class="row my-0 flex-md-row flex-column-reverse">
                        <div class="col-md-3 mt-md-0 mt-0">
                            <label class=" float-right " for="expense_id">أسم المصروف</label>
                        </div>
                        <div class="col-md-2 mt-md-0 mt-0">
 <span class="input-group-append">
            <button class="btn btn-light" type="button" id="create_record">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                            </span>
                        </div>
                    </div>

                    <?php echo Form::select('expense_id', [''=>'أختيار'] +  $listsNameExpense    , $edit ?
                    $expenses->expense_id : '',
                    ['id' => 'by_NameExpense', 'class' => 'form-control  float-right']); ?>




                </div>

                <div class="form-group ">
                    <label class=" float-right " for="invoice_id">السبب</label>
                    <input type="text" class="form-control" id="reason"
                           name="reason" placeholder="سبب التنقل أو سبب الفاتورة" value="<?php echo e($edit ? $expenses->reason :
                            old
                           ('reason')); ?>">
                </div>



                <div class="form-group ">
                    <label class=" float-right " for="invoice_id">المبلغ</label>
                    <input type="text" class="form-control" id="amount"
                           name="amount" placeholder="المبلغ" value="<?php echo e($edit ? $expenses->amount : old
                           ('amount')); ?>">
                </div>


                <div class="form-group">
                    <label for="picture">Image</label>
                    <input type="file" class="form-control" id="picture"    name="picture" >


                </div>

            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    <?php echo e($edit ? trans('app.update') : trans('app.create')); ?>

</button>

</form>
<div class="modal fade" id="formModal_type"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Type Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="sample_form_type" class="form-horizontal" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <span id="form_result_type"></span>
                    <div class="form-group">
                        <label for="from_company">New Type Expense</label>
                        <input type="text" class="form-control" id="name"
                               name="name" placeholder="Name Type" value="<?php echo e(old ('name')); ?>">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="action" id="action" />
                    <input type="hidden" name="hidden_id" id="hidden_id" />
                    <input type="submit" name="action_button" id="action_button_type" class="btn btn-warning" value="Add" />

                </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="formModal"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="sample_form" class="form-horizontal" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <span id="form_result"></span>
                    <div class="form-group">
                        <label for="from_company">New Expenses Name</label>
                        <input type="text" class="form-control" id="name"
                               name="name" placeholder="Expenses Name" value="<?php echo e(old ('name')); ?>">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="action" id="action" />
                    <input type="hidden" name="hidden_id" id="hidden_id" />
                    <input type="submit" name="action_button" id="action_button" class="btn btn-warning" value="Add" />

                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $('#create_record').click(function(){
        $('.modal-title').text("Add New Record");
        $('#action_button').val("Add");
        $('#action').val("Add");
        $('#formModal').modal('show');
    });

    $('#sample_form').on('submit', function(event){

        event.preventDefault();
        if($('#action').val() == 'Add')
        {
            $.ajax({
                url:"<?php echo e(route('expenses.expensesName')); ?>",
                method:"POST",
                data: new FormData(this),
                contentType: false,
                cache:false,
                processData: false,
                dataType:"json",
                success:function(data)
                {
                    var html = '';
                    if(data.errors)
                    {
                        html = '<div class="alert alert-danger">';
                        for(var count = 0; count < data.errors.length; count++)
                        {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if(data.success)
                    {
                        html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                        $('#sample_form')[0].reset();
                        // $("#user_table").load(" #user_table");

                        $('#by_NameExpense').append('<option value = '+data.id+'>'+data.name+'</option>');


                    }
                    $('#form_result').html(html);
                }
            })
        }




    });


    $('#create_record_type').click(function(){
        $('.modal-title').text("Add New Record");
        $('#action_button').val("Add");
        $('#action').val("Add");
        $('#formModal_type').modal('show');
    });

    $('#sample_form_type').on('submit', function(event){

        event.preventDefault();
        if($('#action').val() == 'Add')
        {
            $.ajax({
                url:"<?php echo e(route('expenses.expensesType')); ?>",
                method:"POST",
                data: new FormData(this),
                contentType: false,
                cache:false,
                processData: false,
                dataType:"json",
                success:function(data)
                {
                    var html = '';
                    if(data.errors)
                    {
                        html = '<div class="alert alert-danger">';
                        for(var count = 0; count < data.errors.length; count++)
                        {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if(data.success)
                    {
                        html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                        $('#sample_form')[0].reset();
                        // $("#user_table").load(" #user_table");

                        $('#by_NameType').append('<option value = '+data.id+'>'+data.name+'</option>');


                    }
                    $('#form_result_type').html(html);
                }
            })
        }




    });
</script>




<?php $__env->startSection('after_styles'); ?>
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2.css'); ?>">
    <link rel="stylesheet" href="<?php echo url('assets/plugins/select2/select2-bootstrap4.css'); ?>">



<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4',
                    width: 'style',
                    placeholder: $(this).attr('placeholder'),
                    allowClear: Boolean($(this).data('allow-clear')),
                    dir: "rtl",
                });
            });
        });

    </script>

    <script src="<?php echo url('assets/plugins/select2/select2.full.js'); ?>"></script>

    <?php echo $__env->yieldPushContent('dashboard_scripts'); ?>
<?php $__env->stopSection(); ?>





<?php if($edit): ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Expense\UpdateExpenseRequest', '#expense-form'); ?>

    <?php else: ?>
        <?php echo JsValidator::formRequest('MedSites\Http\Requests\Expense\CreateExpenseRequest', '#expense-form'); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medsites\resources\views/expense/add-edit.blade.php ENDPATH**/ ?>
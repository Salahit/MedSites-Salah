<?php

/**
 * Authentication
 */

Route::get('login', 'Auth\AuthController@getLogin');
Route::post('login', 'Auth\AuthController@postLogin');

Route::get('logout', [
    'as' => 'auth.logout',
    'uses' => 'Auth\AuthController@getLogout'
]);

// Allow registration routes only if registration is enabled.
if (settings('reg_enabled')) {
    Route::get('register', 'Auth\AuthController@getRegister');
    Route::post('register', 'Auth\AuthController@postRegister');
    Route::get('register/confirmation/{token}', [
        'as' => 'register.confirm-email',
        'uses' => 'Auth\AuthController@confirmEmail'
    ]);
}

// Register password reset routes only if it is enabled inside website settings.
if (settings('forgot_password')) {
    Route::get('password/remind', 'Auth\PasswordController@forgotPassword');
    Route::post('password/remind', 'Auth\PasswordController@sendPasswordReminder');
    Route::get('password/reset/{token}', 'Auth\PasswordController@getReset');
    Route::post('password/reset', 'Auth\PasswordController@postReset');
}

/**
 * Two-Factor Authentication
 */
if (settings('2fa.enabled')) {
    Route::get('auth/two-factor-authentication', [
        'as' => 'auth.token',
        'uses' => 'Auth\AuthController@getToken'
    ]);

    Route::post('auth/two-factor-authentication', [
        'as' => 'auth.token.validate',
        'uses' => 'Auth\AuthController@postToken'
    ]);
}

/**
 * Social Login
 */
Route::get('auth/{provider}/login', [
    'as' => 'social.login',
    'uses' => 'Auth\SocialAuthController@redirectToProvider',
    'middleware' => 'social.login'
]);

Route::get('auth/{provider}/callback', 'Auth\SocialAuthController@handleProviderCallback');

Route::get('auth/twitter/email', 'Auth\SocialAuthController@getTwitterEmail');
Route::post('auth/twitter/email', 'Auth\SocialAuthController@postTwitterEmail');

Route::group(['prefix' => 'admin','middleware' => 'auth'], function () {

    /**
     * Impersonate Routes
     */
    Route::impersonate();

    /**
     * Dashboard
     */

    Route::get('calendar','CalendarController@index');
    Route::post('calendar/create','CalendarController@create');
    Route::post('calendar/update','CalendarController@update');
    Route::post('calendar/delete','CalendarController@destroy');

    Route::post('calendar/expensesName', [
        'as' => 'calendar.expensesName',
        'uses' => 'CalendarController@expensesName'
    ]);
    Route::get('calendar-list/list', [
        'as' => 'calendar.list',
        'uses' => 'CalendarController@list'
    ]);


    /**
     * Roles & Permissions
     */

    Route::get('registration/calendar', [
        'as' => 'registration.index',
        'uses' => 'RegistrationController@index'
    ]);

    Route::get('registration/create', [
        'as' => 'registration.create',
        'uses' => 'RegistrationController@create'
    ]);

    Route::post('registration/store', [
        'as' => 'registration.store',
        'uses' => 'RegistrationController@store'
    ]);

    Route::get('registration/{event}/edit', [
        'as' => 'registration.edit',
        'uses' => 'RegistrationController@edit'
    ]);

    Route::put('registration/{registration}/update', [
        'as' => 'registration.update',
        'uses' => 'RegistrationController@update'
    ]);

    Route::delete('registration/{registration}/delete', [
        'as' => 'registration.delete',
        'uses' => 'RegistrationController@delete'
    ]);



    Route::post('registration/calendar/create-quick-event', [
        'as' => 'registration.createQuickEvent',
        'uses' => 'RegistrationController@createQuickEvent'
    ]);
    Route::post('registration/calendar/edit-quick-event', [
        'as' => 'registration.editQuickEvent',
        'uses' => 'RegistrationController@editQuickEvent'
    ]);


    Route::delete('registration/{registration}/deleteMessage', [
        'as' => 'registration.deleteMessage',
        'uses' => 'RegistrationController@deleteMessage'
    ]);

    Route::get('registration/{event}/show', [
        'as' => 'registration.show',
        'uses' => 'RegistrationController@view'
    ]);

    Route::put('registration/{message}/update-text', [
        'as' => 'registration.updateText',
        'uses' => 'RegistrationController@updateText'
    ]);

    Route::post('registration/storeMessage', [
        'as' => 'registration.storeMessage',
        'uses' => 'RegistrationController@storeMessage'
    ]);

    Route::post('registration/storeType', [
        'as' => 'registration.storeType',
        'uses' => 'RegistrationController@storeType'
    ]);


    Route::get('/', [
        'as' => 'dashboard',
        'uses' => 'DashboardController@index'
    ]);
    Route::get('invoices', [
        'as' => 'invoices',
        'uses' => 'DashboardController@invoice'
    ]);

    Route::get('actions/clear_cache', [
        'as' => 'clearCache',
        'uses' => 'ActivityController@clearCache'
    ]);


   // Route::get('backups', 'BackupController@index');

    Route::get('backups', [
        'as' => 'backups',
        'uses' => 'BackupController@index'
    ]);
    Route::put('backups/create', 'BackupController@create');
    Route::get('backups/download/{file_name?}', 'BackupController@download');
    Route::delete('backups/delete/{file_name?}', 'BackupController@delete')->where('file_name', '(.*)');
    /**
     * User Profile
     */

    Route::get('profile', [
        'as' => 'profile',
        'uses' => 'ProfileController@index'
    ]);

    Route::get('profile/activity', [
        'as' => 'profile.activity',
        'uses' => 'ProfileController@activity'
    ]);

    Route::put('profile/details/update', [
        'as' => 'profile.update.details',
        'uses' => 'ProfileController@updateDetails'
    ]);

    Route::post('profile/avatar/update', [
        'as' => 'profile.update.avatar',
        'uses' => 'ProfileController@updateAvatar'
    ]);

    Route::post('profile/avatar/update/external', [
        'as' => 'profile.update.avatar-external',
        'uses' => 'ProfileController@updateAvatarExternal'
    ]);

    Route::put('profile/login-details/update', [
        'as' => 'profile.update.login-details',
        'uses' => 'ProfileController@updateLoginDetails'
    ]);

    /**
     * Two-Factor Authentication Setup
     */

    if (settings('2fa.enabled')) {
        Route::post('two-factor/enable', [
            'as' => 'two-factor.enable',
            'uses' => 'TwoFactorController@enable'
        ]);

        Route::get('two-factor/verification', [
            'as' => 'two-factor.verification',
            'uses' => 'TwoFactorController@verification',
            'middleware' => 'verify-2fa-phone'
        ]);

        Route::post('two-factor/resend', [
            'as' => 'two-factor.resend',
            'uses' => 'TwoFactorController@resend',
            'middleware' => ['throttle:1,1', 'verify-2fa-phone']
        ]);

        Route::post('two-factor/verify', [
            'as' => 'two-factor.verify',
            'uses' => 'TwoFactorController@verify',
            'middleware' => 'verify-2fa-phone'
        ]);

        Route::post('two-factor/disable', [
            'as' => 'two-factor.disable',
            'uses' => 'TwoFactorController@disable'
        ]);
    }

    /**
     * Sessions
     */

    Route::get('profile/sessions', [
        'as' => 'profile.sessions',
        'uses' => 'ProfileController@sessions'
    ]);

    Route::delete('profile/sessions/{session}/invalidate', [
        'as' => 'profile.sessions.invalidate',
        'uses' => 'ProfileController@invalidateSession'
    ]);

    /**
     * User Management
     */
    Route::get('user', [
        'as' => 'user.list',
        'uses' => 'UsersController@index'
    ]);

    Route::get('user/create', [
        'as' => 'user.create',
        'uses' => 'UsersController@create'
    ]);

    Route::post('user/create', [
        'as' => 'user.store',
        'uses' => 'UsersController@store'
    ]);

    Route::get('user/{user}/show', [
        'as' => 'user.show',
        'uses' => 'UsersController@view'
    ]);

    Route::get('user/{user}/edit', [
        'as' => 'user.edit',
        'uses' => 'UsersController@edit'
    ]);

    Route::put('user/{user}/update/details', [
        'as' => 'user.update.details',
        'uses' => 'UsersController@updateDetails'
    ]);

    Route::put('user/{user}/update/login-details', [
        'as' => 'user.update.login-details',
        'uses' => 'UsersController@updateLoginDetails'
    ]);

    Route::delete('user/{user}/delete', [
        'as' => 'user.delete',
        'uses' => 'UsersController@delete'
    ]);

    Route::post('user/{user}/update/avatar', [
        'as' => 'user.update.avatar',
        'uses' => 'UsersController@updateAvatar'
    ]);

    Route::post('user/{user}/update/avatar/external', [
        'as' => 'user.update.avatar.external',
        'uses' => 'UsersController@updateAvatarExternal'
    ]);

    Route::get('user/{user}/sessions', [
        'as' => 'user.sessions',
        'uses' => 'UsersController@sessions'
    ]);

    Route::delete('user/{user}/sessions/{session}/invalidate', [
        'as' => 'user.sessions.invalidate',
        'uses' => 'UsersController@invalidateSession'
    ]);

    Route::post('user/{user}/two-factor/enable', [
        'as' => 'user.two-factor.enable',
        'uses' => 'UsersController@enableTwoFactorAuth'
    ]);

    Route::post('user/{user}/two-factor/disable', [
        'as' => 'user.two-factor.disable',
        'uses' => 'UsersController@disableTwoFactorAuth'
    ]);

    /**
     * filesMail
     */
    Route::get('filesMail', [
        'as' => 'filesMail.index',
        'uses' => 'FilesMailController@index'
    ]);

    Route::get('filesMail/create', [
        'as' => 'filesMail.create',
        'uses' => 'FilesMailController@create'
    ]);

    Route::post('filesMail/create', [
        'as' => 'filesMail.store',
        'uses' => 'FilesMailController@store'
    ]);

// Add Move File
    Route::get('filesMail/create-move/{fileId}', [
        'as' => 'filesMail.createMoves',
        'uses' => 'FilesMailController@createMoves'
    ]);

    Route::post('filesMail/create-move', [
        'as' => 'filesMail.storeMoves',
        'uses' => 'FilesMailController@storeMoves'
    ]);
// Add Move File
    Route::get('filesMail/{filesMail}/show', [
        'as' => 'filesMail.show',
        'uses' => 'FilesMailController@view'
    ]);

    Route::get('filesMail/{filesMail}/edit', [
        'as' => 'filesMail.edit',
        'uses' => 'FilesMailController@edit'
    ]);
    Route::put('filesMail/{filesMail}/update', [
        'as' => 'filesMail.update',
        'uses' => 'FilesMailController@update'
    ]);
    Route::get('filesMail/{filesMail}/editMoves', [
        'as' => 'filesMail.editMoves',
        'uses' => 'FilesMailController@editMoves'
    ]);
    Route::put('filesMail/{filesMail}/updateMoves', [
        'as' => 'filesMail.updateMoves',
        'uses' => 'FilesMailController@updateMoves'
    ]);
    Route::delete('filesMail/{filesMail}/delete', [
        'as' => 'filesMail.delete',
        'uses' => 'FilesMailController@delete'
    ]);
    Route::delete('filesMail/{filesMail}/deleteMoves', [
        'as' => 'filesMail.deleteMoves',
        'uses' => 'FilesMailController@deleteMoves'
    ]);
    Route::post('filesMail/storeCompany', [
        'as' => 'filesMail.storeCompany',
        'uses' => 'FilesMailController@storeCompany'
    ]);
    Route::post('filesMail/storeAddCompany', [
        'as' => 'filesMail.storeAddCompany',
        'uses' => 'FilesMailController@storeAddCompany'
    ]);
    Route::post('filesMail/storeAddItem', [
        'as' => 'filesMail.storeAddItem',
        'uses' => 'FilesMailController@storeAddItem'
    ]);

    /**
     * Download
     */
    Route::get('download', [
        'as' => 'download.index',
        'uses' => 'DownloadController@index'
    ]);

    Route::delete('download/{id}/delete', [
        'as' => 'download.delete',
        'uses' => 'DownloadController@delete'
    ]);
    Route::get('download/active', [
        'as' => 'download.active_all',
        'uses' => 'DownloadController@active_all'
    ]);
    Route::get('importer', [
        'as' => 'importer.index',
        'uses' => 'ImporterController@index'
    ]);

    Route::get('importer/create/{id?}', [
        'as' => 'importer.create',
        'uses' => 'ImporterController@create'
    ]);

    Route::post('importer/store', [
        'as' => 'importer.store',
        'uses' => 'ImporterController@store'
    ]);

    Route::get('importer/{importer}/edit', [
        'as' => 'importer.edit',
        'uses' => 'ImporterController@edit'
    ]);

    Route::put('importer/{importer}/update', [
        'as' => 'importer.update',
        'uses' => 'ImporterController@update'
    ]);
    Route::put('importer/{importer}/editImporter', [
        'as' => 'importer.editImporter',
        'uses' => 'ImporterController@editImporter'
    ]);
    Route::delete('importer/{role}/delete', [
        'as' => 'importer.delete',
        'uses' => 'ImporterController@delete'
    ]);
    Route::get('importer/{importer}/show', [
        'as' => 'importer.show',
        'uses' => 'ImporterController@view'
    ]);
    Route::get('importer/list-importer', [
        'as' => 'importer.listImporter',
        'uses' => 'ImporterController@viewListImporters'
    ]);
    Route::post('updateStockFromOrder/updateStockFromOrder', [
        'as' => 'updateStockFromOrder.updateStockFromOrder',
        'uses' => 'ImporterController@updateStockFromOrder'
    ]);


    /**
     * Roles & Permissions
     */

    Route::get('role', [
        'as' => 'role.index',
        'uses' => 'RolesController@index'
    ]);

    Route::get('role/create', [
        'as' => 'role.create',
        'uses' => 'RolesController@create'
    ]);

    Route::post('role/store', [
        'as' => 'role.store',
        'uses' => 'RolesController@store'
    ]);

    Route::get('role/{role}/edit', [
        'as' => 'role.edit',
        'uses' => 'RolesController@edit'
    ]);

    Route::put('role/{role}/update', [
        'as' => 'role.update',
        'uses' => 'RolesController@update'
    ]);

    Route::delete('role/{role}/delete', [
        'as' => 'role.delete',
        'uses' => 'RolesController@delete'
    ]);


    Route::post('permission/save', [
        'as' => 'permission.save',
        'uses' => 'PermissionsController@saveRolePermissions'
    ]);

    Route::resource('permission', 'PermissionsController');

    Route::resource('products', 'ProductsController');
    Route::delete('products/{product}/delete', [
        'as' => 'products.delete',
        'uses' => 'ProductsController@delete'
    ]);
    //stock
    //Route::resource('stock', 'StockController');


    Route::get('stock', [
        'as' => 'stock.index',
        'uses' => 'StockController@index'
    ]);

    Route::get('stock/create', [
        'as' => 'stock.create',
        'uses' => 'StockController@create'
    ]);

    Route::post('stock/create', [
        'as' => 'stock.store',
        'uses' => 'StockController@store'
    ]);

    Route::get('stock/{stock}/show', [
        'as' => 'stock.show',
        'uses' => 'StockController@view'
    ]);

    Route::get('stock/{stock}/edit', [
        'as' => 'stock.edit',
        'uses' => 'StockController@edit'
    ]);

    Route::put('stock/{stock}/update', [
        'as' => 'stock.update',
        'uses' => 'StockController@update'
    ]);

    Route::delete('stock/{stock}/delete', [
        'as' => 'stock.delete',
        'uses' => 'StockController@delete'
    ]);



    Route::delete('stock/{stock}/deleteHistory', [
        'as' => 'stock.deleteHistory',
        'uses' => 'StockController@deleteHistory'
    ]);
//
//    Route::get('stock/{stock}/show', [
//        'as' => 'stock.show',
//        'uses' => 'StockController@view'
//    ]);

    Route::post('stock/storeStock', [
        'as' => 'stock.storeStock',
        'uses' => 'StockController@storeStock'
    ]);


    Route::post('stock/storeAverage', [
        'as' => 'stock.storeAverage',
        'uses' => 'StockController@storeAverage'
    ]);

    Route::post('stock/sendEmailStock', [
        'as' => 'stock.sendEmailStock',
        'uses' => 'StockController@sendEmailStock'
    ]);


    Route::put('stock/{stock}/editStock', [
        'as' => 'stock.editStock',
        'uses' => 'StockController@editStock'
    ]);

    Route::get('stock/{stock}/editHistory', [
        'as' => 'stock.editHistory',
        'uses' => 'StockController@editHistory'
    ]);


    Route::put('stock/{stock}/updateAverage', [
        'as' => 'stock.updateAverage',
        'uses' => 'StockController@updateAverage'
    ])->middleware('permission:stock.month.save');
    Route::put('stock/{stock}/updateHistory', [
        'as' => 'stock.updateHistory',
        'uses' => 'StockController@updateHistory'
    ]);


    Route::post('stock/storeHistory', [
        'as' => 'stock.storeHistory',
        'uses' => 'StockController@storeHistory'
    ]);
    //View item history
    Route::get('stock/addHistoryView/{itemId}', [
        'as' => 'stock.addHistoryView',
        'uses' => 'StockController@addHistoryView'
    ]);

    Route::get('stock/history', [
        'as' => 'stock.history',
        'uses' => 'StockController@history'
    ]);


//    License
    Route::resource('license', 'LicenseController');
    Route::delete('license/{license}/delete', [
        'as' => 'license.delete',
        'uses' => 'LicenseController@delete'
    ]);

    Route::get('license/{license}/show', [
        'as' => 'license.show',
        'uses' => 'LicenseController@view'
    ]);
//    License
    Route::resource('price', 'PriceController');
    Route::delete('price/{price}/delete', [
        'as' => 'price.delete',
        'uses' => 'PriceController@delete'
    ]);

    //    pages
    Route::resource('pages', 'PagesController');
    Route::delete('pages/{pages}/delete', [
        'as' => 'pages.delete1',
        'uses' => 'pagesController@delete'
    ]);

    Route::get('pages/{pages}/show', [
        'as' => 'pages.show',
        'uses' => 'pagesController@view'
    ]);
    //    pages
    Route::resource('message', 'MessagesController');





    Route::delete('message/{message}/delete', [
        'as' => 'message.delete',
        'uses' => 'MessagesController@delete'
    ]);

    Route::get('message/{Ticket}/show', [
        'as' => 'message.show',
        'uses' => 'MessagesController@view'
    ]);

    Route::put('message/{message}/update-text', [
        'as' => 'message.updateText',
        'uses' => 'MessagesController@updateText'
    ]);

    /**
     * Roles & Permissions
     */

    Route::get('order/{id}', [
        'as' => 'order.index',
        'uses' => 'OrderController@index'
    ]);
    Route::get('order/{order}/show', [
        'as' => 'order.show',
        'uses' => 'OrderController@view'
    ]);
    Route::get('order/create/{id}', [
        'as' => 'order.create',
        'uses' => 'OrderController@create'
    ]);

    Route::post('order/store', [
        'as' => 'order.store',
        'uses' => 'OrderController@store'
    ]);

    Route::get('order/{order}/edit', [
        'as' => 'order.edit',
        'uses' => 'OrderController@edit'
    ]);

    Route::put('order/{order}/update', [
        'as' => 'order.update',
        'uses' => 'OrderController@update'
    ]);

    Route::delete('order/{order}/delete', [
        'as' => 'order.delete',
        'uses' => 'OrderController@delete'
    ]);
    Route::delete('order/{order}/deleteInvoice', [
        'as' => 'order.deleteInvoice',
        'uses' => 'OrderController@deleteInvoice'
    ]);
    Route::get('order/createInvoice/{id}', [
        'as' => 'order.createInvoice',
        'uses' => 'OrderController@createInvoice'
    ]);

    Route::post('order/storeInvoice', [
        'as' => 'order.storeInvoice',
        'uses' => 'OrderController@storeInvoice'
    ]);
    Route::get('order/invoice/all', [
        'as' => 'order.indexInvoiceOrders',
        'uses' => 'OrderController@indexInvoiceOrders'
    ]);
    /**
     * Settings
     */

    Route::get('settings', [
        'as' => 'settings.general',
        'uses' => 'SettingsController@general',
        'middleware' => 'permission:settings.general'
    ]);

    Route::post('settings/general', [
        'as' => 'settings.general.update',
        'uses' => 'SettingsController@update',
        'middleware' => 'permission:settings.general'
    ]);

    Route::get('settings/auth', [
        'as' => 'settings.auth',
        'uses' => 'SettingsController@auth',
        'middleware' => 'permission:settings.auth'
    ]);

    Route::post('settings/auth', [
        'as' => 'settings.auth.update',
        'uses' => 'SettingsController@update',
        'middleware' => 'permission:settings.auth'
    ]);

// Only allow managing 2FA if AUTHY_KEY is defined inside .env file
    if (env('AUTHY_KEY')) {
        Route::post('settings/auth/2fa/enable', [
            'as' => 'settings.auth.2fa.enable',
            'uses' => 'SettingsController@enableTwoFactor',
            'middleware' => 'permission:settings.auth'
        ]);

        Route::post('settings/auth/2fa/disable', [
            'as' => 'settings.auth.2fa.disable',
            'uses' => 'SettingsController@disableTwoFactor',
            'middleware' => 'permission:settings.auth'
        ]);
    }

    Route::post('settings/auth/registration/captcha/enable', [
        'as' => 'settings.registration.captcha.enable',
        'uses' => 'SettingsController@enableCaptcha',
        'middleware' => 'permission:settings.auth'
    ]);

    Route::post('settings/auth/registration/captcha/disable', [
        'as' => 'settings.registration.captcha.disable',
        'uses' => 'SettingsController@disableCaptcha',
        'middleware' => 'permission:settings.auth'
    ]);

    Route::get('settings/notifications', [
        'as' => 'settings.notifications',
        'uses' => 'SettingsController@notifications',
        'middleware' => 'permission:settings.notifications'
    ]);

    Route::post('settings/notifications', [
        'as' => 'settings.notifications.update',
        'uses' => 'SettingsController@update',
        'middleware' => 'permission:settings.notifications'
    ]);

    Route::get('settings/price', [
        'as' => 'settings.price',
        'uses' => 'SettingsController@price',
        'middleware' => 'permission:settings.price'
    ]);


    Route::post('settings/price', [
        'as' => 'settings.price.update',
        'uses' => 'SettingsController@update',
        'middleware' => 'permission:settings.price'
    ]);

    /**
     * Activity Log
     */

    Route::get('activity', [
        'as' => 'activity.index',
        'uses' => 'ActivityController@index'
    ]);

    Route::get('activity/user/{user}/log', [
        'as' => 'activity.user',
        'uses' => 'ActivityController@userActivity'
    ]);


    /**
     * Expenses Expenses
     */

    Route::get('expenses', [
        'as' => 'expenses.index',
        'uses' => 'ExpensesController@index'
    ]);

    Route::get('expenses/create', [
        'as' => 'expenses.create',
        'uses' => 'ExpensesController@create'
    ]);

    Route::post('expenses/store', [
        'as' => 'expenses.store',
        'uses' => 'ExpensesController@store'
    ]);

    Route::get('expenses/{expenses}/edit', [
        'as' => 'expenses.edit',
        'uses' => 'ExpensesController@edit'
    ]);

    Route::put('expenses/{expenses}/update', [
        'as' => 'expenses.update',
        'uses' => 'ExpensesController@update'
    ]);

    Route::delete('expenses/{expenses}/delete', [
        'as' => 'expenses.delete',
        'uses' => 'ExpensesController@delete'
    ]);

    Route::post('expenses/expensesName', [
        'as' => 'expenses.expensesName',
        'uses' => 'ExpensesController@expensesName'
    ]);
    Route::post('expenses/expensesType', [
        'as' => 'expenses.expensesType',
        'uses' => 'ExpensesController@expensesType'
    ]);

    Route::get('accounting', [
        'as' => 'accounting.accounting',
        'uses' => 'ExpensesController@accounting'
    ])->middleware('permission:accounting');

    Route::get('accounting/income', [
        'as' => 'accounting.income',
        'uses' => 'ExpensesController@incomeList'
    ])->middleware('permission:accounting');

    Route::get('accounting/income/create', [
        'as' => 'accounting.incomeCreate',
        'uses' => 'ExpensesController@incomeCreate'
    ])->middleware('permission:accounting');
    Route::post('income/store', [
        'as' => 'income.store',
        'uses' => 'ExpensesController@incomeStore'
    ]);

    Route::delete('income/{income}/delete', [
        'as' => 'income.delete',
        'uses' => 'ExpensesController@incomeDelete'
    ]);

    Route::get('accounting/expenses/print', [
        'as' => 'expenses.printExpense',
        'uses' => 'ExpensesController@printExpense'
    ])->middleware('permission:accounting');
///CachMoney

    Route::get('cashMoney', [
        'as' => 'cashMoney.index',
        'uses' => 'CashMoneyController@index'
    ]);

    Route::get('cashMoney/create', [
        'as' => 'cashMoney.create',
        'uses' => 'CashMoneyController@create'
    ]);

    Route::post('cashMoney/store', [
        'as' => 'cashMoney.store',
        'uses' => 'CashMoneyController@store'
    ]);

    Route::get('cashMoney/{cashMoney}/edit', [
        'as' => 'cashMoney.edit',
        'uses' => 'CashMoneyController@edit'
    ]);

    Route::put('cashMoney/{cashMoney}/update', [
        'as' => 'cashMoney.update',
        'uses' => 'CashMoneyController@update'
    ]);

    Route::delete('cashMoney/{cashMoney}/delete', [
        'as' => 'cashMoney.delete',
        'uses' => 'CashMoneyController@delete'
    ]);


});


/**
 * Installation
 */

$router->get('install', [
    'as' => 'install.start',
    'uses' => 'InstallController@index'
]);

$router->get('install/requirements', [
    'as' => 'install.requirements',
    'uses' => 'InstallController@requirements'
]);

$router->get('install/permissions', [
    'as' => 'install.permissions',
    'uses' => 'InstallController@permissions'
]);

$router->get('install/database', [
    'as' => 'install.database',
    'uses' => 'InstallController@databaseInfo'
]);

$router->get('install/start-installation', [
    'as' => 'install.installation',
    'uses' => 'InstallController@installation'
]);

$router->post('install/start-installation', [
    'as' => 'install.installation',
    'uses' => 'InstallController@installation'
]);

$router->post('install/install-app', [
    'as' => 'install.install',
    'uses' => 'InstallController@install'
]);

$router->get('install/complete', [
    'as' => 'install.complete',
    'uses' => 'InstallController@complete'
]);

$router->get('install/error', [
    'as' => 'install.error',
    'uses' => 'InstallController@error'
]);


//Route::get('/', function () {
//   return view('front.home.home');
//});

//Route::get('clinic', function () {
//    return view('front.products.clinic');
//});
$router->get('/', [
    'as' => 'products.home',
    'uses' => 'ProductsFrontController@home'
]);
$router->get('aboutus', [
    'as' => 'aboutus',
    'uses' => 'ProductsFrontController@aboutus'
]);

$router->get('partner', [
    'as' => 'partner',
    'uses' => 'ProductsFrontController@partner'
]);





$router->get('medical_billing_software', [
    'as' => 'medical_billing_software',
    'uses' => 'ProductsFrontController@medical_billing_software'
]);


$router->get('hospital_software', [
    'as' => 'products.hospital_software',
    'uses' => 'ProductsFrontController@hospital_software'
]);

$router->get('veterinary_practice_software', [
    'as' => 'products.veterinary_practice_software',
    'uses' => 'ProductsFrontController@veterinary_practice_software'
]);

$router->get('beauty_salon_software', [
    'as' => 'products.beauty_salon_software',
    'uses' => 'ProductsFrontController@beauty_salon_software'
]);

$router->get('purchase_orders_software', [
    'as' => 'products.purchase_orders_software',
    'uses' => 'ProductsFrontController@purchase_orders_software'
]);

$router->get('restaurant_software', [
    'as' => 'products.restaurant_software',
    'uses' => 'ProductsFrontController@restaurant_software'
]);


$router->get('restaurant_software', [
    'as' => 'products.restaurant_software',
    'uses' => 'ProductsFrontController@restaurant_software'
]);


//Route::get('download/{product}/{download}', [
//    'as' => 'products.download',
//    'uses' => 'ProductsFrontController@download_products', 'middleware' => 'auth'
//]);

$router->get('download/{product}/{download}', [
    'as' => 'products.download',
    'uses' => 'ProductsFrontController@download_auth', 'middleware' => 'auth'
]);

//$router->get('download/thankyou/{producturl}', [
//    'as' => 'download.download',
//    'uses' => 'ProductsFrontController@download_thankyou', 'middleware' => 'auth'
//]);
$router->get('thank_you_for_downloading/{producturl}/{download}', [
    'as' => 'products.download',
    'uses' => 'ProductsFrontController@download_thank_you_for', 'middleware' => 'auth'
]);

$router->get('page/{page}', [
    'as' => 'pages.page',
    'uses' => 'PagesFrontController@pages'
]);

$router->get('ticket', [
    'as' => 'tickets.ticket',
    'uses' => 'TicketHomeController@index'
]);
Route::post('ticket/create', [
    'as' => 'ticket.store',
    'uses' => 'TicketHomeController@store'
]);

Route::post('ticket/save', [
    'as' => 'ticket.save',
    'uses' => 'TicketHomeController@save'
]);
Route::post('ticket/close', [
    'as' => 'ticket.close',
    'uses' => 'TicketHomeController@close'
]);
Route::post('/ticket/upload', [
    'as' => 'ticket.upload',
    'uses' => 'TicketHomeController@fileStore'
]);
Route::any('/ticket/{id}/filedelete', [
    'as' => 'ticket.filedelete',
    'uses' => 'TicketHomeController@filedelete'
]);
/**
 * User Profile
 */

Route::get('profile', [
    'as' => 'Homeprofile',
    'uses' => 'ProfileHomeController@index'
]);

Route::get('profile/activity', [
    'as' => 'Homeprofile.activity',
    'uses' => 'ProfileHomeController@activity'
]);

Route::put('profile/details/update', [
    'as' => 'Homeprofile.update.details',
    'uses' => 'ProfileHomeController@updateDetails'
]);

Route::post('profile/avatar/update', [
    'as' => 'Homeprofile.update.avatar',
    'uses' => 'ProfileHomeController@updateAvatar'
]);

Route::post('profile/avatar/update/external', [
    'as' => 'Homeprofile.update.avatar-external',
    'uses' => 'ProfileHomeController@updateAvatarExternal'
]);

Route::put('profile/login-details/update', [
    'as' => 'Homeprofile.update.login-details',
    'uses' => 'ProfileHomeController@updateLoginDetails'
]);

/**
 * Two-Factor Authentication Setup
 */

if (settings('2fa.enabled')) {
    Route::post('two-factor/enable', [
        'as' => 'two-factor.enable',
        'uses' => 'TwoFactorController@enable'
    ]);

    Route::get('two-factor/verification', [
        'as' => 'two-factor.verification',
        'uses' => 'TwoFactorController@verification',
        'middleware' => 'verify-2fa-phone'
    ]);

    Route::post('two-factor/resend', [
        'as' => 'two-factor.resend',
        'uses' => 'TwoFactorController@resend',
        'middleware' => ['throttle:1,1', 'verify-2fa-phone']
    ]);

    Route::post('two-factor/verify', [
        'as' => 'two-factor.verify',
        'uses' => 'TwoFactorController@verify',
        'middleware' => 'verify-2fa-phone'
    ]);

    Route::post('two-factor/disable', [
        'as' => 'two-factor.disable',
        'uses' => 'TwoFactorController@disable'
    ]);
}

/**
 * Sessions
 */

Route::get('profile/sessions', [
    'as' => 'Homeprofile.sessions',
    'uses' => 'ProfileHomeController@sessions'
]);

Route::delete('profile/sessions/{session}/invalidate', [
    'as' => 'Homeprofile.sessions.invalidate',
    'uses' => 'ProfileHomeController@invalidateSession'
]);
Route::get('profile/myprodrct', [
    'as' => 'Homeprofile.myprodrct',
    'uses' => 'ProfileHomeController@myprodrct'
]);

/**
 * User Management
 */


//Route::post('image/delete','ImageUploadController@fileDestroy');

$router->get('lang/{lang}', function ($lang) {
    session()->has('lang')?session()->forget('lang'):'';

    if ($lang == 'ar'){

     session()->put('lang','ar');
        return back();
    }else{
        session()->put('lang','en');
        return back();
    }

});
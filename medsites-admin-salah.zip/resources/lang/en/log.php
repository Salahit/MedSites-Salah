<?php

return [
    'new_product' => 'Created new product called :name.',
    'updated_product' => 'Updated the product named :name.',
    'deleted_product' => 'Deleted product named :name.',
    'new_license' => 'Created new license called :name.',
    'updated_license' => 'Updated the license named :name.',
    'deleted_license' => 'Deleted license named :name.',

    'new_Registration' => 'Created new Registration calendar called :name.',
    'updated_Registration' => 'Updated the Registration calendar named :name.',
    'deleted_Registration' => 'Deleted Registration calendar named :name.',

    'new_permission' => 'Created new permission called :name.',
    'updated_permission' => 'Updated the permission named :name.',
    'deleted_permission' => 'Deleted permission named :name.',

    'new_message' => 'Created new message called :name.',
    'updated_message' => 'Updated the message named :name.',
    'deleted_message' => 'Deleted message named :name.',

    'new_Page' => 'Created new Page called :name.',
    'updated_Page' => 'Updated the Page named :name.',
    'deleted_Page' => 'Deleted Page named :name.',

    'new_role' => 'Created new role called :name.',
    'updated_role' => 'Updated role with name :name.',
    'deleted_role' => 'Deleted role named :name.',

    'new_Files_Mail' => 'Created new Files Mail  :name.',
    'updated_Files_Mail' => 'Updated Files Mail with name :name.',
    'deleted_Files_Mail' => 'Deleted Files Mail named :name.',

    'new_order' => 'Created new order called :name.',
    'updated_order' => 'Updated order with name :name.',
    'deleted_order' => 'Deleted order named :name.',

    'new_order_Invoice' => 'Created Invoice to order with Invoice ID :name.',
    'deleted_order_Invoice' => 'Deleted Invoice to order Invoice ID :name.',

    'new_Importer' => 'Created new Importer called :name.',
    'updated_Importer' => 'Updated Importer with name :name.',
    'deleted_Importer' => 'Deleted Importer named :name.',

    'new_Files_Mail_Move' => 'Created new Files called :name.',
    'updated_Files_Mail_Move' => 'Updated Files with name :name.',
    'deleted_Files_Mail_Move' => 'Deleted Files named :name.',

    'new_CashMoney' => 'Created new CashMoney called :name.',
    'updated_CashMoney' => 'Updated CashMoney with name :name.',
    'deleted_CashMoney' => 'Deleted CashMoney named :name.',


        'new_income' => 'Created new income called :name.',
    'updated_income' => 'Updated income with called :name.',
    'deleted_income' => 'Deleted income ID :name.',
    'new_comment' => 'Created new comment :name.',

    'updated_role_permissions' => 'Updated role permissions.',
    'created_download_for' => 'Add download for Product :name.',
    'logged_in' => 'Logged in.',
    'logged_out' => 'Logged out.',
    'created_account' => 'Created an account.',
    'updated_avatar' => 'Updated profile avatar.',
    'updated_profile' => 'Updated profile details.',
    'deleted_user' => 'Deleted user :name.',
    'banned_user' => 'Banned user :name.',
    'updated_profile_details_for' => 'Updated profile details for :name.',
    'created_account_for' => 'Created an account for user :name.',
    'updated_settings' => 'Updated website settings.',
    'enabled_2fa' => 'Enabled Two-Factor Authentication.',
    'disabled_2fa' => 'Disabled Two-Factor Authentication.',
    'enabled_2fa_for' => 'Enabled Two-Factor Authentication for user :name.',
    'disabled_2fa_for' => 'Disabled Two-Factor Authentication for user :name.',
    'requested_password_reset' => 'Requested password reset email.',
    'reseted_password' => 'Reseted password using "Forgot Password" option.',

    'started_impersonating' => 'Started impersonating user :name (ID: :id)',
    'stopped_impersonating' => 'Stopped impersonating user :name (ID: :id)',
];

<table align="center" border="0" cellpadding="2" cellspacing="0" width="100%">
    <tbody>
    <tr>
        <td> 1- <a href="faq?CATE=0#1">How to get activation code and register the product?</a><br>
            2- <a href="faq?CATE=0#2">How to get activation code without connected to the internet?</a><br>
            3- <a href="faq?CATE=0#3">when ever run the software the following warning occurs.</a><br>
            4- <a href="faq?CATE=0#4">How to install the Software in a network?</a><br>
            5- <a href="faq?CATE=0#5">How to install the Software (SQL version) in a network?</a><br>
            6- <a href="faq?CATE=0#6">What are the username and the password?</a><br>
            7- <a href="faq?CATE=0#7">How can I copy the software to my computer at work?</a><br>
            8- <a href="faq?CATE=0#8">What do I do to make the software working fine again?</a><br>
            9- <a href="faq?CATE=0#9">What do I do if  the continue button for free trail was grayed out?</a><br>
            10- <a href="faq?CATE=0#10">What do I need to use if I want to open a downloaded file?</a><br>
            11- <a href="faq?CATE=0#11">How to setup the software on Windows Server 2003 Small Business server?</a><br>
            12- <a href="faq?CATE=0#12">What about the customizations?</a><br>
            13- <a href="faq?CATE=0#13">What about the Support service?</a><br>
            14- <a href="faq?CATE=0#14">Where are the ICD-9 codes in the software?</a><br>
            15- <a href="faq?CATE=0#15">I cannot locate and the attach database, what should I do?</a><br>
            16- <a href="faq?CATE=0#16">What about the language for windows?</a><br>
            17- <a href="faq?CATE=0#17">How can I transfer my license to new computer?</a><br>
            18- <a href="faq?CATE=0#18">What about the offer on Ebay.com?</a><br>
            19- <a href="faq?CATE=0#19">what the difference between 1 and 12 Payment?</a><br>
            20- <a href="faq?CATE=0#20">What does license here means?</a><br>
            21- <a href="faq?CATE=0#21">How can transfer from Clinicgate to MDBay?</a><br>
            22- <a href="faq?CATE=0#22">The clients contact information</a><br>
            23- <a href="faq?CATE=0#23">What about the Manual help?</a><br>
            24- <a href="faq?CATE=0#24">What is the frontend/programming language?</a><br>
            25- <a href="faq?CATE=0#25">Are we expected to install this MS SQL Express on every computer on the network?</a><br>
            26- <a href="faq?CATE=0#26">how does the software or user ensure quality control of the data?</a><br>
            27- <a href="faq?CATE=0#27">How about import Database?</a><br>
            28- <a href="faq?CATE=0#28">How available and efficient is support?</a><br>
            29- <a href="faq?CATE=0#29">What about the source code of the software?</a><br>
            30- <a href="faq?CATE=0#30">The software can be networked over LAN on multiple basis or terminals?</a><br>
            31- <a href="faq?CATE=0#31">Is this software compatible with Macs?</a><br>
            32- <a href="faq?CATE=0#32">What about Refund?</a><br>
            33- <a href="faq?CATE=0#33">Where do I go to update the billing information?</a><br>
            34- <a href="faq?CATE=0#34">How to download SQL server?</a><br>
            35- <a href="faq?CATE=0#35">Why database login appear when I print  receipt report?</a><br>
            36- <a href="faq?CATE=0#36">how much capacity of patients can you have?</a><br>
            37- <a href="faq?CATE=0#37">What about the Software reseller?</a><br>
            38- <a href="faq?CATE=0#38">How can I change the time for appointments?</a><br>
            39- <a href="faq?CATE=0#39">Both DB (Access and SQL have the same features or not)?</a><br>
            40- <a href="faq?CATE=0#40">Need to know if ClinicGate accepts ERA (auto posting).</a><br>
            41- <a href="faq?CATE=0#41">In the expenses, how can choose the account of employee?</a><br>
            42- <a href="faq?CATE=0#42">In the inventory system. How can I add my items?</a><br>
            43- <a href="faq?CATE=0#43">How can I purchase ClinicGate Software?</a><br>
            44- <a href="faq?CATE=0#44">How stable is the software in real world application? </a><br>
            45- <a href="faq?CATE=0#45">Can we install MS Access and MS SQL Version at the same time?</a><br>
            46- <a href="faq?CATE=0#46">What about the cost?</a><br>
            47- <a href="faq?CATE=0#47">what about the multicurrency system on the software?</a><br>
            48- <a href="faq?CATE=0#48">What about capable of handling a database?</a><br>
            49- <a href="faq?CATE=0#49">What is your experience in my industry?</a><br>
            50- <a href="faq?CATE=0#50">What SEO techniques you use to achieve rankings and what type of risks are involved with them?</a><br>
            51- <a href="faq?CATE=0#51">When I can expect to see results?</a><br>
            52- <a href="faq?CATE=0#52">How much increase in traffic I can expect?</a><br>
            53- <a href="faq?CATE=0#53">What type of help do you expect from my end?</a><br>
            54- <a href="faq?CATE=0#54">What are the processes/procedures involved in the SEO work you are going to do for me?</a><br>
            55- <a href="faq?CATE=0#55">Will submit detailed report after each stage?</a><br>
            56- <a href="faq?CATE=0#56">Will I be able to reach 1st page ranking a?</a><br>
            57- <a href="faq?CATE=0#57">How long will the effects of higher ranking remain?</a><br>
            58- <a href="faq?CATE=0#58">What to Do if my software has Popup Shows License Expired</a><br>
            59- <a href="faq?CATE=0#59">What about ways of Payment?</a><br>
            60- <a href="faq?CATE=0#60">What about Free Lifetime version?</a><br>
            61- <a href="faq?CATE=0#61">How about your billing service cost and how does it work?</a><br>
            62- <a href="faq?CATE=0#62">Can you provide ClinicGate as a web application?</a><br>
            63- <a href="faq?CATE=0#63">What about CMS 1500?</a><br>
            64- <a href="faq?CATE=0#64">How can I go to ebay to purchase this at the special price?</a><br>
            65- <a href="faq?CATE=0#65">What about the appointment data coming out on the screen?</a><br>
            <br>
            <br>
            <br>
            <br>
            <br>
            test <strong>Q1: <a name="1">How to get activation code and register the product?</a></strong><br>
            After installing in the server and client PC, it requires activation code.<br>
            How to get activation code and register the product?<br>
            <br>
            <br>
            <strong>A:</strong> You can get your serial# for your version as follow:<br>
            1.	When you complete your Purchase information in 2checkout.com you will transfer to our web site again to get your serial no. <br>
            2.	Choice &ldquo;get The Serial Online (Purchase Product) ". <br>
            3.	Write your Email in the appropriate column that you used before in 2checkout.com. <br>
            4.	Select your version that you purchased. <br>
            5.	Please Copy the serial no. then Paste it in the appropriate column, Then Click Register. <br>
            6.	Now you can start working with your software! Congratulations. <br>
            <strong>Note that:</strong> This is a one computer license and only for the computer that will be activated online.<br>
            So if you need to setup the software on the network, you need to purchase license for every computer.<br>

            <hr color="#808080">
            <br>
            <br>
            <strong>Q2: <a name="2">How to get activation code without connected to the internet?</a></strong><br>
            How to get activation code and register the product if the computer isn't connected to the internet?<br>
            <br>
            <strong>A:</strong> You can get your serial # as follow:<br>
            <br>
            1.	You need to download the following file:<br>
            <a href="http://www.med-sites.com/downloads_t/Activation1.exe" target="_blank">Click here</a><br>
            2.	Then open it will appear registration #. <br>
            3.	Send us it to generate the serial # for your version and send it to you by Email.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#1"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#3"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q3: <a name="3">when ever run the software the following warning occurs.</a></strong><br>
            I have downloaded trial versions for the software &amp;   installed. But when ever run the software the following warning occurs-<br>
            "fatal error the program will close now".<br>
            <br>
            <br>
            <strong>A:</strong> Please make sure that the language of your Windows is English. <br>
            Till now Our Software must install on English windows. Or at least change the language for windows to English.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#2"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#4"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q4: <a name="4">How to install the Software in a network?</a></strong><br>
            How to install the Software (Access version or trial version) in a network?<br>
            <br>
            <strong>A:</strong> For installation the software on your network, you need to install the software on every computer on your network.<br>
            Then sharing your database on the server computer<br>
            Then contact every Client computer on your network to this sharing database which placed on server.<br>
            As shown in the manual help for ClinicGate in the following link:<br>
            <a href="http://www.med-sites.com/Manual/cg/Setup%20network.html" target="_blank">Click here</a><br>
            <br>
            <div align="right"><a href="faq?CATE=0#3"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#5"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q5: <a name="5">How to install the Software (SQL version) in a network?</a></strong><br>
            When I open software, requests user name (sa) and password, which I do not know?<br>
            <br>
            <strong>A:</strong> For Performing Installation steps for SQL version needs an IT Technician Or individual with Network % SQL setup Savvy. <br>
            You can find it in the following page:<br>
            <a href="http://www.med-sites.com/Manual/hg/StepForSQLServer/ForSQLServer.html" target="_blank">Click here</a> <br>
            <div align="right"><a href="faq?CATE=0#4"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#6"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q6: <a name="6">What are the username and the password?</a></strong><br>
            After I installed the software it has a login screen! What are   the username and the password? And it say invalid!! What do I do to fix   this problem?!?!<br>
            <br>
            <strong>A:</strong> The default username &lsquo;admin&rsquo; and the password &lsquo;admin&rsquo;<br>
            If you   still facing this issue and you need to reset the Login &amp; Password,   Please uninstall the software then please make sure that the folder   with name the software in the following path is removed:<br>
            C:\Program Files\MedSites<br>
            Then install the software again. The username and password will appear automatic again.<br>
            Now you can work with the software successfully.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#5"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#7"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q7: <a name="7">How can I copy the software to my computer at work?</a></strong><br>
            I'd already download the software in my computer at home, and   now I want to copy it to my computer at work, how can I do it? <br>
            <br>
            <strong>A:</strong> You can Download the software again then copy this file with   extension &ldquo;.exe&rdquo; on a CD or flash drive to install it on your computer   at work<br>
            <br>
            Then you can Do Backup for your Database on your computer at home as follow:<br>
            1.	Select Backup Database from the Tools Menu. <br>
            2.	Click Browse Button to select the location of the database to copy and click Create Backup Button. <br>
            3.	Click close Button to close the window. <br>
            <br>
            Also you can make restore for your Database on your computer at work as follow:<br>
            1.	Select Restore Database from the Tools Menu. <br>
            2.	Click Browse Button to select the location of the Backup File and Click the button Restore Database. <br>
            3.	Click close Button to close the window.<br>
            <br>
            <strong>Important Notes:</strong> <br>
            1-To   keep an external backup of your database, Please always make a periodic   copy of your database file on a CD or flash drive to be used in case of   hard drive crash and you require re-installing the software with your   entered data. The database file is located in the hard disc drive where   you install the software e.g. C: or D: drive under the below path: <br>
            C:\Program Files\MedSites\ClinicGate\Database\Clinic08.mdb<br>
            <br>
            2- When you uninstall the software, Please Make sure that the folder with name of the software in the following path is removed:<br>
            C:\Program Files\MedSites\<br>
            <br>
            <div align="right"><a href="faq?CATE=0#6"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#8"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q8: <a name="8">What do I do to make the software working fine again?</a></strong><br>
            The software was running fine! But lately we had a problem with   our computer (for some reason) and now we cannot open it. What do I do   to fix this problem?<br>
            <br>
            <strong>A:</strong> If you have Backup for your database, you can Re-install the   software. Then make restore for your Database again. The Software will   working fine. <br>
            <div align="right"><a href="faq?CATE=0#7"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#9"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q9: <a name="9">What do I do if  the continue button for free trail was grayed out?</a></strong><br>
            I downloaded the trial advance version. After I installed it,   the continue button for free trail was grayed out. This is the first   time I try it. What do I do?<br>
            <br>
            <strong>A:</strong> May be you changed your Date on your Computer. So try installing the software on another computer. <br>
            <div align="right"><a href="faq?CATE=0#8"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#10"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q10: <a name="10">What do I need to use if I want to open a downloaded file?</a></strong><br>
            What do I need to use if I want to open a downloaded file?<br>
            <br>
            <strong>A:</strong> After download the file, you can do duple click on the file to install the software. <br>
            <div align="right"><a href="faq?CATE=0#9"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#11"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q11: <a name="11">How to setup the software on Windows Server 2003 Small Business server?</a></strong><br>
            How to setup the software on Windows Server 2003 Small Business server?<br>
            I have found an error while installing the clinicgate<br>
            <br>
            <strong>A:</strong> You can training more with The manual help in the following link To learn how to setup ClinicGate Software on your PC:<br>
            <a href="http://www.med-sites.com/Manual/cg/" target="_blank">Click here</a><br>
            <br>
            This is not error and it will not effect on your installation, So you can click Continue then continue your installation. <br>
            Then enjoy your work with ClinicGate Software.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#10"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#12"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q12: <a name="12">What about the customizations?</a></strong><br>
            What about the customizations?<br>
            <br>
            <strong>A:</strong> Our company policy for software customizations is acceptable for software order above US$ 5,000 only. <br>
            <div align="right"><a href="faq?CATE=0#11"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#13"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q13: <a name="13">What about the Support service?</a></strong><br>
            What about the Support service?<br>
            <br>
            <strong>A:</strong> Our support service for all over the world online by Remote   Support Service. This Service is free one year for our Clients then you   can purchase this service for 20% from your order. <br>
            <div align="right"><a href="faq?CATE=0#12"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#14"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q14: <a name="14">Where are the ICD-9 codes in the software?</a></strong><br>
            Where are the ICD-9 codes in the software?<br>
            <br>
            <strong>A:</strong> You can find the ICD-9 codes in &ldquo;Patient Medical Record&rdquo; screen from Patients menu. <br>
            <div align="right"><a href="faq?CATE=0#13"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#15"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q15: <a name="15">I cannot locate and the attach database, what should I do?</a></strong><br>
            I cannot locate and the attach database, what should I do?<br>
            <br>
            <strong>A:</strong> If you installed ClinicGate, you Will find the database file   "Clinic08.mdf" is located in the hard disc drive where you install the   software e.g. C: or D: drive under the below path: <br>
            <br>
            C:\Program Files\MedSites\ClinicGate\Database\<br>
            <br>
            <div align="right"><a href="faq?CATE=0#14"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#16"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q16: <a name="16">What about the language for windows?</a></strong><br>
            What about the language for windows?<br>
            <br>
            <strong>A:</strong> Till now Our Software must install on English windows. Or at least change the language for windows to English. <br>
            <div align="right"><a href="faq?CATE=0#15"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#17"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q17: <a name="17">How can I transfer my license to new computer?</a></strong><br>
            I already have loaded the software on my laptop and I   understand that I can only purchase a license for only one machine at a   time so if I wanted to remove the license from my laptop and install the   software on my desktop computer. Is that possible.<br>
            <br>
            <strong>A:</strong> Yes, don&rsquo;t worry about this issue.<br>
            If you need to transfer   your license from your laptop to your desktop Computer, just send us an   email or go to our Live Help in our website www.med-sites.com and we   will be glad to help.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#16"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#18"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q18: <a name="18">What about the offer on Ebay.com?</a></strong><br>
            What about the offer on Ebay.com?<br>
            <br>
            <strong>A:</strong> The offer on Ebay.com is Special Offer for one license only,   and for purchase Multi-User you can Order it from Our Websites   www.med-sites.com <br>
            Also when you ordered one license from Ebay.com we   will ship to you the Access version for the Software because it is   easier in installation and using for one user.<br>
            But if you will use the software for Multi-User, So you need to download the SQL version for the Software.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#17"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#19"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q19: <a name="19">what the difference between 1 and 12 Payment?</a></strong><br>
            I can't understand between 1 and 12 Payment. Is 1 Payment can use long time? What to do after 12 Payment finished?<br>
            <br>
            <strong>A:</strong> You can purchase Our Software by 2 ways.<br>
            <br>
            1- One Payment time, Then you can get the software forever without any charge another that. (1 Payment)<br>
            2-   You can also pay the amount in 12 months, and then you can get the   software forever without any charge another that. (12 Payment)<br>
            <br>
            <div align="right"><a href="faq?CATE=0#18"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#20"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q20: <a name="20">What does license here means?</a></strong><br>
            What does license here means? User or number of computer or   times of installation software when we need to change computer?<br>
            <br>
            <strong>A:</strong> Our License/Computer This mean that it is a one computer   license and only for the computer that will be activated online.<br>
            In   case you need to change your Computer, just send us an email or go to   our Live Help in our website and we will be glad to help.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#19"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#21"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q21: <a name="21">How can transfer from Clinicgate to MDBay?</a></strong><br>
            How can transfer from Clinicgate to MDBay?<br>
            <br>
            <strong>A:</strong> You can transfer your data from your side to MDbay (Because   there is different between ClinicGate database and MDbay Database). <br>
            <div align="right"><a href="faq?CATE=0#20"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#22"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q22: <a name="22">The clients contact information</a></strong><br>
            I would like to speak to someone using the software. Would appreciate Tel No. or email id of people using the software?<br>
            <br>
            <strong>A:</strong> Our clients contact information are protected by our company   policy, if you wish to contact any of UAE clients you can find them   listed in our website and in UAE local directory. <br>
            <div align="right"><a href="faq?CATE=0#21"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#23"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q23: <a name="23">What about the Manual help?</a></strong><br>
            I would like for you to send me a copy of the manual so that I can begin to set up my software and use it!<br>
            <br>
            <br>
            <strong>A:</strong> Our software manual is included inside the software and it is   in digital format where you can print all pages or any needed section.   We have also the same manual online if needed.<br>
            <br>
            If you wish us to ship you the CD which contain the help manual, please let me know and we will do immediately. <br>
            <div align="right"><a href="faq?CATE=0#22"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#24"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q24: <a name="24">What is the frontend/programming language?</a></strong><br>
            What is the frontend/programming language?<br>
            <br>
            <strong>A:</strong> VB.NET <br>
            <div align="right"><a href="faq?CATE=0#23"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#25"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q25: <a name="25">Are we expected to install this MS SQL Express on every computer on the network?</a></strong><br>
            I saw this in the manual &ldquo;To Manage and Back up Data, You need   download SQL Server Management Studio Express.&rdquo; Are we expected to   install this MS SQL Express on every computer on the network or just the   server?<br>
            <br>
            <strong>A:</strong> Yes, you will install MS SQL Express in each machine and this   FREE of charge version and comes with our software, no extra payment to   purchase MS SQL Database for each PC. <br>
            <div align="right"><a href="faq?CATE=0#24"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#26"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q26: <a name="26">how does the software or user ensure quality control of the data?</a></strong><br>
            What mechanisms does the software have inbuilt that is able to   detect and/or prevent errors in the data? Or how does the software or   user ensure quality control of the data?<br>
            <br>
            <strong>A:</strong> Our Software has all the needed validations to prevent error and preventing human error to keep a clean data. <br>
            <div align="right"><a href="faq?CATE=0#25"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#27"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q27: <a name="27">How about import Database?</a></strong><br>
            How easy is it to extract data from the database and use for   research purposes? Is the stored data pre-coded in some easily   retrievable format?<br>
            <br>
            <strong>A:</strong> Very easy you can import your data to Excel, PDF or Word Document from our HospitalGate Software. <br>
            <div align="right"><a href="faq?CATE=0#26"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#28"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q28: <a name="28">How available and efficient is support?</a></strong><br>
            How available and efficient is support, in the event that it is needed?<br>
            <br>
            <br>
            <strong>A:</strong> We are providing online support for our international clients   and we can access remotely your computers to provide any support needed.   Our support follows our company working hours.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#27"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#29"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q29: <a name="29">What about the source code of the software?</a></strong><br>
            Could the source code of this software package be given to us for future feasibility and flexibility?<br>
            <br>
            <strong>A:</strong> Our company policy we do not provide software source code. <br>
            <div align="right"><a href="faq?CATE=0#28"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#30"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q30: <a name="30">The software can be networked over LAN on multiple basis or terminals?</a></strong><br>
            I just want to know whether the hospitalgate or clinicgate can be networked over LAN on multiple basis or terminals?<br>
            <br>
            <br>
            <strong>A:</strong> Our software (CLinicGate and HospitalGate) are working on Network Multiple PCs and Multiple users.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#29"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#31"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q31: <a name="31">Is this software compatible with Macs?</a></strong><br>
            Is this software compatible with Macs?<br>
            <br>
            <strong>A:</strong> Our software for Microsoft Windows 98, ME, XP, NT, 2000, 2003, Vista. <br>
            <div align="right"><a href="faq?CATE=0#30"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#32"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q32: <a name="32">What about Refund?</a></strong><br>
            What about Refund?<br>
            <br>
            <br>
            <strong>A:</strong> Our company software refund policy which you can read it from the below link, you will be refunded within 30 days.<br>
            <br>
            <a href="http://www.med-sites.com/main/Refund-Policy-Software.asp" target="_blank">Click here</a> <br>
            <div align="right"><a href="faq?CATE=0#31"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#33"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q33: <a name="33">Where do I go to update the billing information?</a></strong><br>
            Where do I go to update the billing information? <br>
            <br>
            <br>
            <br>
            <strong>A:</strong> <a href="https://www.2checkout.com/2co/admin/change_billing_method" target="_blank">Click here</a><br>
            https://www.2checkout.com/2co/admin/change_billing_method<br>
            <br>
            You'll   simply copy and paste the link directly into your address bar. You'll   then enter the first 6 and last 2 digits currently on file and click on   the SEARCH FOR ORDER button. Do not worry about the postal code portion   of the page, it won't be necessary. You'll then enter your new billing   information, and you may change your email address at that time. Once   completed, you will receive a confirmation email of the change. If the   order needs to bill immediately, the new card will bill within the next   24 hours.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#32"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#34"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q34: <a name="34">How to download SQL server?</a></strong><br>
            How to download SQL server?<br>
            <br>
            <br>
            <br>
            <strong>A:</strong> You can download ClinicGate SQL Version from the following link:<br>
            <a href="http://www.med-sites.com/downloads_t/clinicgate_SQL.exe" target="_blank">Click here</a><br>
            <br>
            <div align="right"><a href="faq?CATE=0#33"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#35"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q35: <a name="35">Why database login appear when I print  receipt report?</a></strong><br>
            However when I select receipt button to print, it goes database login again!!! What shall I do?<br>
            <br>
            <br>
            <strong>A:</strong> Please make sure that you have logo in ClinicData Screen.<br>
            Then print your receipt.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#34"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#36"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q36: <a name="36">how much capacity of patients can you have?</a></strong><br>
            ClinicGate software how much capacity of patients can you have? <br>
            <br>
            <br>
            <strong>A:</strong> You can use ClinicGate Software (Access version) with 64000 records of patients. <br>
            Also you can use ClinicGate Software (SQL version) with +1 Million records of patients.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#35"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#37"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q37: <a name="37">What about the Software reseller?</a></strong><br>
            What about the Software reseller?<br>
            What is involved in becoming an accredited representative?<br>
            We needed some information about detailed for marketing process?<br>
            <br>
            <br>
            <strong>A:</strong> For accredited representative you can read about and learn about way of payment from the below link.<br>
            <a href="http://www.med-sites.com/Main/Software-reseller.asp" target="_blank">Click here</a><br>
            <br>
            <div align="right"><a href="faq?CATE=0#36"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#38"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q38: <a name="38">How can I change the time for appointments?</a></strong><br>
            Trying to edit appointments for example Monday, Tuesday,   Wednesday we open at 10am but Thursday we open at 12pm. How can I make   that change?<br>
            <br>
            <strong>A:</strong> Our software enables you to edit one time for your appointment screen. <br>
            <div align="right"><a href="faq?CATE=0#37"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#39"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q39: <a name="39">Both DB (Access and SQL have the same features or not)?</a></strong><br>
            Both DB (Access and SQL have the same features or not), and what about the price for SQL version<br>
            <br>
            <strong>A:</strong> Yes, Access and SQL version for ClinicGate have the same features.<br>
            So you can see Multi-User Prices for ClnicGate Software in the following link:<br>
            <a href="http://www.med-sites.com/Clinicgate/Medical_Billing_Software_CG08_Price_list.asp" target="_blank">Click here</a><br>
            <br>
            The Access version for the Software is easier in installation and using for one user.<br>
            But   if you will use the software for Multi-User, So you need to download   the SQL version for the Software from the following link:<br>
            <a href="http://www.med-sites.com/downloads_t/clinicgate_SQL.exe" target="_blank">Click here</a><br>
            <br>
            <div align="right"><a href="faq?CATE=0#38"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#40"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q40: <a name="40">Need to know if ClinicGate accepts ERA (auto posting).</a></strong><br>
            Need to know if ClinicGate accepts ERA (auto posting).<br>
            <br>
            <strong>A:</strong> ClinicGate haven&rsquo;t this option, But you can Export The Data to   Excel or Word or PDF or file Database Access then send it by email to   your insurance company. <br>
            <div align="right"><a href="faq?CATE=0#39"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#41"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q41: <a name="41">In the expenses, how can choose the account of employee?</a></strong><br>
            In the expenses, how can choose the account of employee?<br>
            <br>
            <strong>A:</strong> You can choose the account of employee after Fill the values of   Units &amp; the price of units and the amount of paid. Then you can   choose the account of employee and click on the cell of the Total to   write the amount of paid for every Doctor as shown in the following   picture:<br>
            <br>
            <a href="http://www.med-sites.com/images/Expenses.png" target="_blank">Click here</a><br>
            <br>
            <div align="right"><a href="faq?CATE=0#40"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#42"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q42: <a name="42">In the inventory system. How can I add my items?</a></strong><br>
            In the inventory system. How can I add my items and the   quantity is record in the inventory and I need to know the stock   remaining?<br>
            <br>
            <strong>A:</strong> In the first you need to receive this quantity of your items to   record in the inventory. Also you can click on Print Stock Button is to   view/print the total Products' Inventory in the stock as shown in the   following Page:<br>
            <br>
            <a href="http://www.med-sites.com/Manual/hg/Pharmacy/Purchace.html" target="_blank">Click here</a><br>
            <br>
            <div align="right"><a href="faq?CATE=0#41"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#43"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q43: <a name="43">How can I purchase ClinicGate Software?</a></strong><br>
            How can I purchase ClinicGate Software?<br>
            <br>
            <strong>A:</strong> You can see the Multi-User Prices in the following link:<br>
            <a href="http://www.med-sites.com/Clinicgate/Medical_Billing_Software_CG08_Price_list.asp" target="_blank">Click here</a><br>
            <br>
            <br>
            So you can order CLinicGate Software online.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#42"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#44"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q44: <a name="44">How stable is the software in real world application? </a></strong><br>
            How stable is the software in real world application? Keeping   in consideration that for us, it will be installed in over 150 desktop   computers networked throughout the hospital and with constant access and   modification by all these (occasionally all at the same time)?<br>
            <br>
            <strong>A:</strong> HospitalGate Advanced with MS SQL Express is very stable   software and can be installed in 150+ desktop computers in a Networked. <br>
            <div align="right"><a href="faq?CATE=0#43"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#45"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q45: <a name="45">Can we install MS Access and MS SQL Version at the same time?</a></strong><br>
            Can we install MS Access and MS SQL Version at the same time?<br>
            <br>
            <strong>A:</strong> You can install only MS Access or MS SQL Version. <br>
            <div align="right"><a href="faq?CATE=0#44"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#46"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q46: <a name="46">What about the cost?</a></strong><br>
            What would be the cost for your software for a hospital with over 300 beds?<br>
            <br>
            <strong>A:</strong> Our software can cover any number of hospital beds and our cost is by licenses number <br>
            <div align="right"><a href="faq?CATE=0#45"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#47"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q47: <a name="47">what about the multicurrency system on the software?</a></strong><br>
            Is there any way of having a multicurrency system on your HospitalGate software?<br>
            <br>
            <br>
            <strong>A:</strong> Now HospitalGate working with one Currency as follow:<br>
            You can add new currency on HospitalGate software as follow:<br>
            1.	Select Hospital Data from Master Menu. <br>
            2.	In General Tab: You can find Date format, Base Currency &amp; Financial year. <br>
            3.  	Also you can add new currency by click Add Icon to open pop up window   and write the currency and its symbol then click add in pop up window.<br>
            4.	Cancel button in pop up window to clear Currency and symbol fields to add new one.<br>
            5.	Delete currency by select it from Base Currency list and click delete Icon.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#46"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#48"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q48: <a name="48">What about capable of handling a database?</a></strong><br>
            Is the ClinicGate capable of handling a database of more than 40,000 patients?<br>
            <br>
            <br>
            <strong>A:</strong> Yes ClinicGate with MS SQL Express database is capable to handle more than 40,000 patients<br>
            <br>
            <div align="right"><a href="faq?CATE=0#47"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#49"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q49: <a name="49">What is your experience in my industry?</a></strong><br>
            What is your experience in my industry?<br>
            <br>
            <strong>A:</strong> To do SEO we search the highest searched keywords for each industry to include in your website meta tag. <br>
            <div align="right"><a href="faq?CATE=0#48"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#50"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q50: <a name="50">What SEO techniques you use to achieve rankings and what type of risks are involved with them?</a></strong><br>
            What SEO techniques you use to achieve rankings and what type of risks are involved with them?<br>
            <br>
            <strong>A:</strong> We use only ethical techniques that focus on organic natural   search results and all of our practices following Major search engines   webmaster guidelines such as Google, Yahoo and Bing. <br>
            <div align="right"><a href="faq?CATE=0#49"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#51"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q51: <a name="51">When I can expect to see results?</a></strong><br>
            When I can expect to see results?<br>
            <br>
            <strong>A:</strong> After 90 days. <br>
            <div align="right"><a href="faq?CATE=0#50"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#52"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q52: <a name="52">How much increase in traffic I can expect?</a></strong><br>
            How much increase in traffic I can expect?<br>
            <br>
            <strong>A:</strong> At least 50% traffic increase which will grow more gradually. <br>
            <div align="right"><a href="faq?CATE=0#51"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#53"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q53: <a name="53">What type of help do you expect from my end?</a></strong><br>
            What type of help do you expect from my end?<br>
            <br>
            <strong>A:</strong> Update your meta tag with one that we will make for you or   provide us with FTP access to your website and our team will do it. <br>
            <div align="right"><a href="faq?CATE=0#52"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#54"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q54: <a name="54">What are the processes/procedures involved in the SEO work you are going to do for me?</a></strong><br>
            What are the processes/procedures involved in the SEO work you are going to do for me?<br>
            <br>
            <strong>A:</strong> Keywords research for your website, rewrite meta tag and creates backlinks to your website in high PR4-5 directories. <br>
            <div align="right"><a href="faq?CATE=0#53"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#55"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q55: <a name="55">Will submit detailed report after each stage?</a></strong><br>
            Will submit detailed report after each stage?<br>
            <br>
            <strong>A:</strong> You get one monthly report for the keyword(s) ranking in Google, Yahoo and Bing. <br>
            <div align="right"><a href="faq?CATE=0#54"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#56"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q56: <a name="56">Will I be able to reach 1st page ranking a?</a></strong><br>
            Will I be able to reach 1st page ranking a?<br>
            <br>
            <strong>A:</strong> We guarantee to put your websites in top 10 ranking for the Keyword(s) selected. <br>
            <div align="right"><a href="faq?CATE=0#55"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#57"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q57: <a name="57">How long will the effects of higher ranking remain?</a></strong><br>
            How long will the effects of higher ranking remain?<br>
            <br>
            <strong>A:</strong> As long as you are paying our package you will be always in top 10 ranking. <br>
            <div align="right"><a href="faq?CATE=0#56"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#58"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q58: <a name="58">What to Do if my software has Popup Shows License Expired</a></strong><br>
            What to Do if my software has Popup Shows License Expired?<br>
            <br>
            <strong>A:</strong> We add quarterly updates to our software therefor Support   purchase is a must to receive the new updates online, first year support   is FREE when you purchased your license(s) and thereafter isupport cost   is US$60 per Year per License. <br>
            <br>
            If the software displays a Popup that License Expired, this means that you did not renew your support payment.<br>
            <br>
            Steps Remove License Expired from our software.<br>
            <br>
            1- Order yearly support for your license(s) from our website. <br>
            <br>
            2- After your support payment your license will be activated online within 6-12 hours. <br>
            <div align="right"><a href="faq?CATE=0#57"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#59"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q59: <a name="59">What about ways of Payment?</a></strong><br>
            What about ways of Payment?<br>
            <br>
            <strong>A:</strong> 1.You can purchase by 2checkout.com online. And 2checkout.com. Using visa or master cards online.<br>
            <br>
            2.Transfer to our company bank account below:<br>
            Company Name: MedSites Computer <br>
            A/C #: 1011076397101 <br>
            Bank Name: Emirates Bank International <br>
            Branch: Main branch <br>
            Address: P.O.Box 2923 Dubai , United Arab Emirates <br>
            Swift Code: EBILAEAD <br>
            <br>
            3.Payment by Western union my name and address below:<br>
            Hisham Elkhatib <br>
            4 Ghana Street, Cairo – Egypt<br>
            Tel Cairo:      +202 2452 6161<br>
            <br>
            <div align="right"><a href="faq?CATE=0#58"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#60"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q60: <a name="60">What about Free Lifetime version?</a></strong><br>
            What about Free Lifetime version?<br>
            <br>
            <strong>A:</strong> We offer The Basic version is Free Lifetime.<br>
            And the Trial version is Demo for Advanced version and it free for 21 Days.<br>
            <br>
            So you can get your serial# for Basic version as follow:<br>
            <br>
            1.	Choose the 'Get the Serial Online (Purchase Product)' <br>
            2.	Write your Email in the appropriate field. <br>
            3.	Select Basic version. <br>
            4.	Click Get Serial# to transfer you to our web site to get your serial no. <br>
            5.	Please Copy the serial no. then Paste it in the appropriate field, Then Click Register. <br>
            6.	Now you can start working with Basic version for the software! Congratulations.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#59"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#61"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q61: <a name="61">How about your billing service cost and how does it work?</a></strong><br>
            For an optometric practice how much does your billing service cost and how does it work?<br>
            <br>
            <strong>A:</strong> We are not a medical billing service we develop and sell medical billing software. <br>
            <div align="right"><a href="faq?CATE=0#60"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#62"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q62: <a name="62">Can you provide ClinicGate as a web application?</a></strong><br>
            Can you provide ClinicGate as a web application? <br>
            <br>
            <br>
            <strong>A:</strong> ClinicGate is available now as desktop software only.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#61"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#63"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q63: <a name="63">What about CMS 1500?</a></strong><br>
            I am interested in ClinicGate and want to know whether the program is prepared for billing with Alberta Health, Canada?<br>
            <br>
            <strong>A:</strong> Our software ClinicGate Advanced can be use to create CMS 1500   medical billing claim for any medical billing service, you can make your   CMS 1500 forms then email it to your billing service.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#62"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#64"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q64: <a name="64">How can I go to ebay to purchase this at the special price?</a></strong><br>
            How can I go to ebay to purchase this at the special price?<br>
            <br>
            <strong>A:</strong> You can have the software and CD shipped and the download   option when order through Ebay special offer from the following link:<br>
            <br>
            <a href="http://cgi.ebay.com/ClinicGate-Advanced-Medical-Billing-software_W0QQcmdZViewItemQQ_trkparmsZalgoQ3dSICQ26itsQ3dIQ252BCQ26ituQ3dUCIQ252BIAQ252BUAQ252BFICSQ252BUFIQ26otnQ3d8Q26poQ3dLVIQ26psQ3d54QQ_trksidZp3907Q2em263QQcategoryZ3770QQitemZ260436807052QQsalenotsupported" target="_blank">Click here</a> <br>
            <div align="right"><a href="faq?CATE=0#63"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> <a href="faq?CATE=0#65"><i class="fas fa-arrow-alt-circle-right"></i></a></div>
            <br>
            <hr color="#808080">
            <br>
            <br>
            <strong>Q65: <a name="65">What about the appointment data coming out on the screen?</a></strong><br>
            The appointments that I have booked for tomorrow are not coming out on the screen!<br>
            <br>
            <br>
            <strong>A:</strong> Please make sure that you selected Doctor Name from Doctor Menu in Appointment Screen.<br>
            <br>
            <div align="right"><a href="faq?CATE=0#64"><i class="fas
                                                fa-arrow-alt-circle-left"></i></a> <a href="faq?CATE=0#top"><i class="fas fa-arrow-alt-to-top"></i></a> </div></td>
    </tr>
    </tbody>
</table>
@extends('layouts.app')

@section('page-title', $edit ? 'Edit Price ' : 'Add Price')
@section('page-heading', $edit ? 'Edit Price ' .  $price->id  : 'Add Price' )

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('price.index') }}">Prices</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')





@if ($edit)
    {!! Form::open(['route' => ['price.update', $price->id], 'method' => 'PUT', 'id' => 'Price-form']) !!}
@else
    {!! Form::open(['route' => 'price.store', 'id' => 'Price-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <h5 class="card-title">
                    @lang('app.details')
                </h5>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="product_id">Product</label>


                    {!! Form::select('product',[''=>'Select'] + $productList, $edit ? $price->product : '',
                ['class' => 'form-control', 'id' => 'product']) !!}


                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="numbers"> Numbers</label>
                    <input type="text" class="form-control" id="numbers"
                           name="numbers" placeholder="Numbers"
                           value="{{ $edit ? $price->numbers : old('numbers') }}">
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="status">@lang('app.status')</label>
                    {!! Form::select('status', $statuses, $edit ? $price->status : '',
                ['class' => 'form-control', 'id' => 'status']) !!}
                </div>
            </div>
        </div>

            <div class="row">
            <div class="col-md-3">
                <div class="form-group">

                    <label for="Product ID Basic"> Basic </label>
                    <input type="text" class="form-control" id="product_id_basic"
                           name="product_id_basic" placeholder="ID"
                           value="{{ $edit ? $price->product_id_basic : old('product_id_basic') }}">


                </div>
                <input type="text" class="form-control" id="price_basic"
                       name="price_basic" placeholder="Price"
                       value="{{ $edit ? $price->price_basic : old('price_basic') }}">   </div>

            <div class="form-group my-4 pand" >

                    <div class="switch">
                        <input type="hidden" value="Banned" name="basic_status">

                        <input type="checkbox"
                               name="basic_status"
                               class="switch"
                               value="Active"
                               id="switch-id_basic"
                                {{ settings('notifications_signup_email') ? 'checked' : '' }}>

                        <label for="switch-id_basic"></label>
                    </div>

             </div>


            <div class="col-md-3">
                <div class="form-group">
                    <label for="product_id_standard">Standard </label>
                    <input type="text" class="form-control" id="product_id_standard"
                           name="product_id_standard" placeholder="ID"
                           value="{{ $edit ? $price->product_id_standard : old('product_id_standard') }}">
                     </div>
                <input type="text" class="form-control" id="price"
                       name="price_standard" placeholder="Price"
                       value="{{ $edit ? $price->price_standard : old('price_standard') }}">  </div>

            <div class="form-group my-4 pand" >

                <div class="switch">
                    <input type="hidden" value="Banned" name="standard_status">

                    <input type="checkbox"
                           name="standard_status"
                           class="switch"
                           value="Active"
                           id="switch-standard_status"
                            {{ settings('notifications_signup_email') ? 'checked' : '' }}>

                    <label for="switch-standard_status"></label>
                </div>

            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="product_id_advanced">Advanced </label>
                    <input type="text" class="form-control" id="product_id_advanced"
                           name="product_id_advanced" placeholder="ID"
                           value="{{ $edit ? $price->product_id_advanced : old('product_id_advanced') }}">


                </div>  <input type="text" class="form-control" id="price_advanced"
                               name="price_advanced" placeholder="Price"
                               value="{{ $edit ? $price->price_advanced : old('price_advanced') }}">
            </div>

            <div class="form-group my-4 pand" >

                <div class="switch">
                    <input type="hidden" value="Banned" name="advanced_status">

                    <input type="checkbox"
                           name="advanced_status"
                           class="switch"
                           value="Active"
                           id="switch-advanced_status"
                            {{ settings('notifications_signup_email') ? 'checked' : '' }}>

                    <label for="switch-advanced_status"></label>
                </div>

            </div>


</div>


<div class="row my-4 ">
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">
            {{ $edit ? trans('app.update') : trans('app.create') }}
        </button>
    </div>
</div>

@stop
@section('after_styles')

    @stack('dashboard_styles')

<style>.pand{padding-top: 35px;} </style>

@endsection
@section('after_scripts')


    @stack('dashboard_scripts')
@endsection

@section('scripts')

    @if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Price\UpdatePriceRequest', '#Price-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Price\CreatePriceRequest', '#Price-form') !!}
    @endif


@stop


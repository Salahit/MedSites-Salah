@extends('layouts.app')

@section('page-title', 'Backup')
@section('page-heading', 'Backup')

@section('breadcrumbs')
	<li class="breadcrumb-item active">
        Backup
	</li>
@stop

@section('content')

    <div class="card">
        <div class="card-body">
    <!-- Default box -->
    <div class="box box-primary">
	
		<div class="box-header with-border">
			<div class="callout">
				<h4><i class="fa fa-question-circle"></i> {{ trans('backupLang.Help') }}</h4>
			
				<p>{!! trans('backupLang.help_backup') !!}</p>
			</div>
		</div>
		
        <div class="box-body">
			
            <button id="create-new-backup-button" href="{{ url('admin/backups/create') }}" class="btn btn-success
            ladda-button
            backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-download"></i> {{ trans('backupLang.create_a_new_backup_all') }}</span></button>
	
			<button id="create-new-backup-button1" href="{{ url('admin/backups/create').'?type=database' }}" class="btn
			btn-primary ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-database"></i> {{ trans('backupLang.create_a_new_backup_database') }}</span></button>
	
			<button id="create-new-backup-button3" href="{{ url('admin/backups/create').'?type=languages' }}"
					class="btn
			btn-info ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-globe"></i> {{ trans('backupLang.create_a_new_backup_languages') }}</span></button>
	
			<button id="create-new-backup-button2" href="{{ url('admin/backups/create').'?type=files' }}" class="btn
			btn-warning ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-files-o"></i> {{ trans('backupLang.create_a_new_backup_files') }}</span></button>
	
			<button id="create-new-backup-button4" href="{{ url('admin/backups/create').'?type=app' }}" class="btn
			btn-danger
			ladda-button backup-button" data-style="zoom-in"><span class="ladda-label"><i class="fa fa-industry"></i> {{ trans('backupLang.create_a_new_backup_app') }}</span></button>
			
            <br>
            <h3>{{ trans('backupLang.existing_backups') }}:</h3>
            <div class="table-responsive" id="users-table-wrapper">
            <table class="table table-borderless table-striped">

                <thead>
                <tr>
                    <th>#</th>
                    <th>{{ trans('backupLang.location') }}</th>
                    <th>{{ trans('backupLang.date') }}</th>
                    <th class="text-right">{{ trans('backupLang.file_size') }}</th>
                    <th class="text-right">{{ trans('backupLang.actions') }}</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($backups as $k => $b)
                    <tr>
                        <th scope="row">{{ $k+1 }} - {{ urlencode($b['file_name']) }}</th>
                        <td>{{ $b['disk'] }}</td>
                        <td>{{ \Carbon\Carbon::createFromTimeStamp($b['last_modified'])->formatLocalized('%d %B %Y, %H:%M') }}</td>
                        <td class="text-right">{{ round((int)$b['file_size']/1048576, 2).' MB' }}</td>
                        <td class="text-right">
                            @if ($b['download'])
                                <a class="btn btn-xs btn-default" href="{{ url('admin/backups/download/') }}?disk={{
                                $b['disk']
                                 }}&path={{ urlencode($b['file_path']) }}&file_name={{ urlencode($b['file_name']) }}"><i class="fa fa-cloud-download"></i> {{ trans('backupLang.download') }}</a>
                            @endif

                                <a href="{{ url
                            ('admin/backups/delete/'
                            .$b['file_name']) }}?disk={{ $b['disk'] }}"

                                   class="btn btn-xs btn-danger"

                                   title="@lang('app.delete_user')"
                                   data-toggle="tooltip"
                                   data-placement="top"
                                   data-method="DELETE"
                                   data-confirm-title="@lang('app.please_confirm')"
                                   data-confirm-text="@lang('app.are_you_sure_delete_user')"
                                   data-confirm-delete="@lang('app.yes_delete_him')">
                                    <i class="fas fa-trash"></i>
                                </a>

                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        
        </div><!-- /.box-body -->
    </div><!-- /.box -->
        </div><!-- /.box-body -->
    </div><!-- /.box -->
    </div>
@stop

@section('after_styles')
	<!-- Ladda Buttons (loading buttons) -->

	<link rel="stylesheet" href="{!! url('assets/plugins/ladda/ladda-themeless.min.css') !!}"rel="stylesheet" type="text/css" />>
@endsection



@section('scripts')

        <script>




        jQuery(document).ready(function($) {

            // capture the Create new backup button
            $(".backup-button").click(function(e) {
                e.preventDefault();



                var buttonIdSelector = '#' + $(this).attr('id');
                var create_backup_url = $(this).attr('href');

                // Create a new instance of ladda for the specified button
                var l = Ladda.create( document.querySelector(buttonIdSelector) );

                // Start loading
                l.start();

                // Will display a progress bar for 10% of the button width
                l.setProgress( 0.3 );

                setTimeout(function(){ l.setProgress( 0.6 ); }, 2000);

                // do the backup through ajax
                $.ajax({
                    url: create_backup_url,
                    type: 'PUT',
                    success: function(result) {
                        l.setProgress( 0.9 );

                        // Show an alert with the result
                        if (result.indexOf('failed') >= 0) {
                            new PNotify({
                                title: "{{ trans('backupLang.create_warning_title') }}",
                                text: "{{ trans('backupLang.create_warning_message') }}",
                                type: "warning"
                            });
                        }
                        else
                        {
                            new PNotify({
                                title: "{{ trans('backupLang.create_confirmation_title') }}",
                                text: "{{ trans('backupLang.create_confirmation_message') }}",
                                type: "success"
                            });
                        }

                        // Stop loading
                        l.setProgress( 1 );
                        l.stop();

                        // refresh the page to show the new file
                        setTimeout(function(){ location.reload(); }, 3000);
                    },
                    error: function(result) {
                        l.setProgress( 0.9 );

                        // Show an alert with the result
                        new PNotify({
                            title: "{{ trans('backupLang.create_error_title') }}",
                            text: "{{ trans('backupLang.create_error_message') }}",
                            type: "warning"
                        });

                        // Stop loading
                        l.stop();
                    }
                });
            });









        });



        </script>
@stop

@section('after_styles')


	<link rel="stylesheet" href="{!! url('assets/plugins/morris/0.5.1/morris.css') !!}">
	<!-- DASHBOARD LIST CONTENT - dashboard_styles stack -->
	@stack('dashboard_styles')

	<style>
		/* Bootstrap tooltip need to be in single line */
		.tooltip-inner {
			white-space: nowrap;
			max-width: none;
		}
	</style>
@endsection

@section('after_scripts')
	{!! HTML::script('assets/plugins/ladda/spin.js') !!}
	{!! HTML::script('assets/plugins/ladda/ladda.js') !!}
	<!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
	@stack('dashboard_scripts')
@endsection





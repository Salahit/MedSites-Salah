
    <nav class=" sidebar "  >




    <div class="user-box text-center mb-0 pt-0 pb-0">

        <ul class="list-inline mb-0">
            <li class="list-inline-item">
                <a href="{{ route('profile') }}" title="@lang('app.my_profile')">
                    <i class="fas fa-cog"></i>
                </a>
            </li>

            <li class="list-inline-item">
                <a href="{{ route('auth.logout') }}" class="text-custom" title="@lang('app.logout')">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </li>
        </ul>
    </div>


    <div class="sidebar-sticky mt-0">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link {{ Route::is('dashboard') ? 'active' : ''  }}" href="{{ route('dashboard') }}">
                    <i class="fas fa-home"></i>
                    <span>@lang('app.dashboard')</span>
                </a>
            </li>
            @permission('accounting')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('accounting*') ? 'active' : ''  }}" href="{{ route('accounting.accounting') }}">
                    <i class="far fa-money-bill-alt"></i>
                    <span> Accounting</span>
                </a>
            </li>
            @endpermission
            @permission('expenses.list')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('expenses*') ? 'active' : ''  }}" href="{{ route('expenses.index') }}">
                    <i class="fas fa-dollar-sign"></i>
                    <span>Expenses</span>
                </a>
            </li>
            @endpermission
            @permission('cashMoney.list')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('cashMoney*') ? 'active' : ''  }}" href="{{ route('cashMoney.index') }}">
                    <i class="far fa-money-bill-alt"></i>
                    <span> Cash Money</span>
                </a>
            </li>
            @endpermission
            @permission('stock.list')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('stock*') ? 'active' : ''  }}" href="{{ route('stock.index') }}">
                    <i class="fas fa-pills"></i>
                    <span>Pharmaceutical</span>
                </a>
            </li>
            @endpermission



            @permission('importers')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('importer*') ? 'active' : ''  }}" href="{{ route('importer.index') }}">
                    <i class="fas fa-capsules"></i>
                    <span>Importer</span>
                </a>
            </li>
            @endpermission
            @permission('Registration.List')
            <li class="nav-item">
  <a class="nav-link {{ Route::is('registration*') ? 'active' : ''  }}" href="{{ route('registration.index') }}">

      <i class="fas fa-calendar-alt"></i>
                    <span> Registration</span>
                </a>
            </li>
            @endpermission

            @permission('filesMail.list')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('filesMail*') ? 'active' : ''  }}" href="{{ route('filesMail.index') }}">
                    <i class="fas fa-paste"></i>
                    <span>Files Mail List</span>
                </a>
            </li>
            @endpermission
            @permission('license.list')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('license*') ? 'active' : ''  }}" href="{{ route('license.index') }}">
                    <i class="fa fa-h-square"></i>
                    <span>License</span>
                </a>
            </li>
            @endpermission
            @permission('message.list')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('message*') ? 'active' : ''  }}" href="{{ route('message.index') }}">
                    <i class="fas fa-envelope-open"></i>

                    <span>Tickets</span>
                </a>
            </li>
            @endpermission
            @permission('users.manage')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('user*') ? 'active' : ''  }}" href="{{ route('user.list') }}">
                    <i class="fas fa-users"></i>
                    <span>@lang('app.users')</span>
                </a>
            </li>
            @endpermission

            @permission('users.activity')
            <li class="nav-item">
                <a class="nav-link {{ Route::is('activity*') ? 'active' : ''  }}" href="{{ route('activity.index') }}">
                    <i class="fas fa-server"></i>
                    <span>@lang('app.activity_log')</span>
                </a>
            </li>
            @endpermission

            @permission(['product.list'], false)
            <li class="nav-item">
                <a href="#site-dropdown"
                   class="nav-link"
                   data-toggle="collapse"
                   aria-expanded="{{ Route::is('products*') || Route::is('download*') || Route::is('pages*') ? 'true' : 'false' }}">
                    <i class="fas fa-cogs"></i>
                    <span>Site</span>
                </a>
                <ul class="{{ Route::is('products*') || Route::is('download*') || Route::is('pages*')  ? '' : 'collapse' }} list-unstyled sub-menu"
                    id="site-dropdown">
                    @permission('product.list')
                    <li class="nav-item nav-sub"  >
                        <a class="nav-link  {{ Route::is('products*') ? 'active' : ''  }}"
                           href="{{ route('products.index') }}">
                            <i class="fas fa-cubes"></i>
                            <span>Products List</span>
                        </a>
                    </li>
                    @endpermission

                    @permission('download.list')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('download*') ? 'active' : ''  }}" href="{{ route('download.index')
                }}">
                            <i class="fas fa-download"></i>
                            <span>Download List</span>
                        </a>
                    </li>
                    @endpermission
                    @permission('page.list')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('pages*') ? 'active' : ''  }}" href="{{ route('pages.index')
                }}">
                            <i class="fas fa-basketball-ball"></i>
                            <span>Pages List</span>
                        </a>
                    </li>
                    @endpermission
                </ul>
            </li>
            @endpermission






            @permission(['roles.manage', 'permissions.manage'])
            <li class="nav-item">
                <a href="#roles-dropdown"
                   class="nav-link"
                   data-toggle="collapse"
                   aria-expanded="{{ Route::is('role*') || Route::is('permission*') ? 'true' : 'false' }}">
                    <i class="fas fa-users-cog"></i>
                    <span>Roles </span>
                </a>
                <ul class="{{ Route::is('role*') || Route::is('permission*') ? '' : 'collapse' }} list-unstyled
                sub-menu" id="roles-dropdown">
                    @permission('roles.manage')
                    <li class="nav-item">
                        <a class="nav-link {{ Route::is('role*') ? 'active' : '' }}"
                           href="{{ route('role.index') }}">@lang('app.roles')</a>
                    </li>
                    @endpermission
                    @permission('permissions.manage')
                    <li class="nav-item">
                        <a class="nav-link {{ Route::is('permission*') ? 'active' : '' }}"
                           href="{{ route('permission.index') }}">@lang('app.permissions')</a>
                    </li>
                    @endpermission
                </ul>
            </li>
            @endpermission

            @permission(['backup.page, settings.general', 'settings.auth', 'settings.price', 'settings
            .notifications'], false)
            <li class="nav-item">
                <a href="#settings-dropdown"
                   class="nav-link"
                   data-toggle="collapse"
                   aria-expanded="{{ Route::is('settings*') || Route::is('backups*')  ? 'true' : 'false' }}">
                    <i class="fas fa-cogs"></i>
                    <span>@lang('app.settings')</span>
                </a>
                <ul class="{{ Route::is('settings*') || Route::is('backups*') ? '' : 'collapse' }} list-unstyled
                sub-menu"
                    id="settings-dropdown">
                    @permission('backup.page')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('backups*') ? 'active' : ''  }}"
                           href="{{ route('backups') }}">
                            Backups
                        </a>
                    </li>
                    @endpermission

                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('clearCache*') ? 'active' : ''  }}"
                           href="{{ route('clearCache') }}">
                            Clear Cache
                        </a>
                    </li>

                    @permission('settings.general')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('settings*') ? 'active' : ''  }}"
                           href="{{ route('settings.general') }}">
                            @lang('app.general')
                        </a>
                    </li>
                    @endpermission

                    @permission('settings.auth')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('settings/auth') ? 'active' : ''  }}"
                           href="{{ route('settings.auth') }}">@lang('app.auth_and_registration')</a>
                    </li>
                    @endpermission
                    @permission('settings.price')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('settings/price') ? 'active' : ''  }}"
                           href="{{ route('settings.price') }}">Price</a>
                    </li>
                    @endpermission

                    @permission('settings.notifications')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('settings/notifications') ? 'active' : ''  }}"
                           href="{{ route('settings.notifications') }}">@lang('app.notifications')</a>
                    </li>
                    @endpermission

                    @permission('settings.notifications')
                    <li class="nav-item nav-sub">
                        <a class="nav-link {{ Route::is('settings/notifications') ? 'active' : ''  }}"
                           href="{{ route('settings.notifications') }}">@lang('app.notifications')</a>
                    </li>
                    @endpermission
                </ul>
            </li>
            @endpermission
        </ul>




    </div>


</nav>


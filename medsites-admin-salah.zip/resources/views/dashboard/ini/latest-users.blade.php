
    <h5 class="card-title">Users Active on Day</h5>

		<div class="chart" id="barChartUsers" style="height: 300px;"></div>





@push('dashboard_styles')
@endpush

@push('dashboard_scripts')
    <script>
        $(function () {
            "use strict";
        
            // USERS STATS
            var area = new Morris.Bar({
                element: 'barChartUsers',
                resize: true,
                data: {!! $UsersChart !!},
                xkey: 'y',
                ykeys: ['activated', 'unactivated'],
                labels: ['Active', 'Unactivated'],
                lineColors: ['#3c8dbc', '#a0d0e0'],
                hideHover: 'auto',
                parseTime: false
            });
        });
    </script>
@endpush



<div class="box box-primary">
	<h5 class="card-title">Download all </h5>

	<div class="box-body chart-responsive">

			<canvas id="pieChartUsers"></canvas>

	</div>
</div>


@push('dashboard_styles')
	<style>
		canvas {
			-moz-user-select: none;
			-webkit-user-select: none;
			-ms-user-select: none;
		}
	</style>
@endpush

@push('dashboard_scripts')

    <script>


			
			var config = {
				type: 'pie', /* pie, doughnut */
				data: {!! $usersPerCountry !!},
				options: {
					responsive: true,
					legend: {
						display: true,
						position: 'right'
					},
					title: {
						display: false
					},
					animation: {
						animateScale: true,
						animateRotate: true
					}
				}
			};
			
			$(function () {
				var ctx = document.getElementById('pieChartUsers').getContext('2d');
				window.myUsersDoughnut = new Chart(ctx, config);
			});

    </script>
@endpush


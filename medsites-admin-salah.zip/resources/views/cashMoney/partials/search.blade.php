<form action="" method="GET" id="users-form" class="pb-2 mb-3 border-bottom-light">
    <div class="row my-1 flex-md-row flex-column-reverse">
        <div class="col-md-3 mt-md-0 mt-0">
            <div class="input-group custom-search-form">
                <input type="text"
                       class="form-control input-solid"
                       name="search"
                       value="{{ Input::get('search') }}"
                       placeholder="Search Reason
">

                <span class="input-group-append">
                                @if (Input::has('search') && Input::get('search') != '')
                        <a href="{{ route('cashMoney.index') }}"
                           class="btn btn-light d-flex align-items-center text-muted"
                           role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                    @endif
                    <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-search text-muted"></i>
                                </button>
                            </span>
            </div>
        </div>
        <div class="col-md-2 mt-md-0 mt-0">
            {!! Form::select('from', [''=>'Select From'] +  $listsEmployees   ,Input::get('from'),
                                     ['id' => 'from', 'class' => 'form-control input-solid']) !!}

        </div>
        <div class="col-md-2 mt-md-0 mt-0">
            {!! Form::select('to', [''=>'Select To'] +  $listsEmployees  ,Input::get('to'),
                                     ['id' => 'to', 'class' => 'form-control input-solid']) !!}

        </div>


        <div class="col-1 mt-3 mt-md-0">
            <select name="year"   class="form-control input-solid min-width-80" id="year">
                <option value="">Year</option>
                <?php  $currentDate =   \Carbon\ Carbon::now()->addYear(5); ?>

                @for ($i = 2014; $i <= $currentDate->year; $i++)

                    <option @if(Input::get('year') == $i) selected @endif value="{{ $i }}"> {{ $i
                                    }}</option>
                @endfor



            </select>

        </div>
        <div class="col-md-2 mt-0 mt-md-0">
            {!! Form::select('month',  [''=>'Month',
                 '1'=>'January', '2'=>'February','3'=>'March','4'=>'April','5'=>'May','6'=>'June',
                '7'=>'July','8'=>'August','9'=>'September','10'=>'October','11'=>'November', '12'=>'December']
                  ,Input::get('month') , ['id' => 'month', 'class' => 'form-control input-solid min-width-100']) !!}

        </div>
        <div class="col-md-2">
            <a href="{{ route('cashMoney.create' ) }}" class="btn btn-primary btn-rounded
            float-right">
                <i class="fas fa-plus mr-2"></i>
                Add Cash
            </a>
        </div>
    </div>
</form>
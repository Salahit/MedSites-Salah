@extends('layouts.app')

@section('page-title', trans('app.cashMoney'))
@section('page-heading', $edit ? $cashMoney->cash_money : trans('app.create_new_cashMoney'))

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('cashMoney.index') }}">@lang('app.cashMoney')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['cashMoney.update', $cashMoney->id], 'method' => 'PUT', 'id' => 'cashMoney-form']) !!}
@else
    {!! Form::open(['route' => 'cashMoney.store', 'id' => 'cashMoney-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    @lang('app.cashMoney_details_big')
                </h5>
                <p class="text-muted">
                    A general Cash Money information.
               </p>
            </div>
            <div class="col-md-9">


                <div class="form-group">
                    <label for="from_id">Money From  </label>

                    {!! Form::select('from_id', [''=>'Select'] +  $listsEmployees   ,$edit ? $cashMoney->from_id : '',
                                       ['id' => 'from_id', 'class' => 'form-control input-solid']) !!}

                </div>
                <div class="form-group">
                    <label for="to_id">Money To </label>

                    {!! Form::select('to_id', [''=>'Select'] +  $listsEmployees   ,$edit ? $cashMoney->to_id : '',
                                       ['id' => 'to_id', 'class' => 'form-control input-solid']) !!}

                </div>

                <div class="form-group">
                    <label for="reason">Reason</label>
                    <input type="text" class="form-control" id="reason"
                           name="reason" placeholder="reason" value="{{ $edit ? $cashMoney->reason : old
                           ('reason') }}">
                </div>

                <div class="form-group">
                    <label for="cash_money">Cash Money</label>
                    <input type="number" class="form-control" id="cash_money"
                           name="cash_money" placeholder="Cash Money" value="{{ $edit ? $cashMoney->cash_money : old
                           ('cash_money') }}">
                </div>



            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    {{ $edit ? trans('app.update_cashMoney') : trans('app.create_cashMoney') }}
</button>

</form>
<br>
<div class="card">
    <div class="card-body">
        <div class="  table-responsive" id="users-table-wrapper">
            <table class="table table-striped table-borderless">
                <thead>
                <tr>

                    <th>Name</th>
                    <th>Cash Money</th>
                    <th>Expenses</th>

                </tr>
                </thead>
                <tbody>
                @if (count($ListsEmployeesAll))
                    @foreach ($ListsEmployeesAll as $row)
                        <tr>

                            <td class="align-middle">{{  $row->users_id()->first()->present()->nameOrEmail  }}  </td>
                            <td>{{ number_format($row->cash_money )}}</td>

                            <td>

                                <a href="{{ route('expenses.index') .'?user='.$row->employee_id  }}" class="badge badge-lg badge-light">



                                    <h5>     {{ number_format($row->tobalance) }}  </h5>  </a>   </td>
                        </tr>
                    @endforeach
                @else
                    <tr>
                        <td colspan="4"><em>@lang('app.no_records_found')</em></td>
                    </tr>
                @endif
                </tbody>
            </table>
        </div>
    </div>
</div>





@stop

@section('scripts')

@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2-bootstrap4.css') !!}">



@endsection

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4',
                    width: 'style',
                    placeholder: $(this).attr('placeholder'),
                    allowClear: Boolean($(this).data('allow-clear')),

                });
            });
        });

    </script>

    <script src="{!! url('assets/plugins/select2/select2.full.js') !!}"></script>

    @stack('dashboard_scripts')
@endsection


@if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\CashMoney\UpdateCashMoneyRequest', '#cashMoney-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\CashMoney\CreateCashMoneyRequest', '#cashMoney-form') !!}
    @endif
@stop
<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, Without shrink-to-fit specified">

    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('page-title') - {{ settings('app_name') }}</title>

    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="{{ url('assets/img/icons/apple-touch-icon-144x144.png') }}" />
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="{{ url('assets/img/icons/apple-touch-icon-152x152.png') }}" />
    <link rel="icon" type="image/png" href="{{ url('assets/img/icons/favicon-32x32.png') }}" sizes="32x32" />
    <link rel="icon" type="image/png" href="{{ url('assets/img/icons/favicon-16x16.png') }}" sizes="16x16" />
    <meta name="application-name" content="{{ settings('app_name') }}"/>
    <meta name="msapplication-TileColor" content="#FFFFFF" />
    <meta name="msapplication-TileImage" content="{{ url('assets/img/icons/mstile-144x144.png') }}" />

    <link media="all" type="text/css" rel="stylesheet" href="{{ url(mix('assets/css/vendor.css')) }}">
    <link media="all" type="text/css" rel="stylesheet" href="{{ url(mix('assets/css/app.css')) }}">
    <link media="all" type="text/css" rel="stylesheet" href="{{ url('assets/plugins/pnotify/pnotify.custom.min.css') }}">

    @yield('after_styles')
    @yield('styles')
</head>
<body >
    @include('partials.navbar')

    <div class="container-fluid">
        <div class="row">
            @include('partials.sidebar')

            <div class="content-page" >
                <main role="main" class="px-2">
                    @yield('content')
                </main>
            </div>
        </div>
    </div>

    <script src="{{ url(mix('assets/js/vendor.js')) }}"></script>
    <script src="{{ url('assets/js/as/app.js') }}"></script>
    @yield('after_scripts')
    @yield('scripts')
    <script src="{{ url('assets/plugins/pnotify/pnotify.custom.min.js') }}"></script>


    {{-- Bootstrap Notifications using Prologue Alerts --}}
    <script type="text/javascript">
        jQuery(document).ready(function ($) {

            PNotify.prototype.options.styling = "bootstrap3";
            PNotify.prototype.options.styling = "fontawesome";

            @foreach (Alert::getMessages() as $type => $messages)
            @foreach ($messages as $message)

            $(function () {
                @if ($message == 'demo_mode_message')
                new PNotify({
                    title: 'Information',
                    text: "{{ $message }}",
                    type: "{{ $type }}"
                });
                @else
                new PNotify({
                    text: "{{ $message }}",
                    type: "{{ $type }}",
                    icon: false
                });
                @endif
            });

            @endforeach
            @endforeach
        });
    </script>
</body>
</html>

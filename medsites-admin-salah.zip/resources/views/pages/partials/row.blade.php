<tr>

    <td class="align-middle">
        <a href="{{ route('pages.edit', $page->id) }}">
            {{ $page->name ?: trans('app.n_a') }}
        </a>
    </td>
    <td class="align-middle">
        <a href="{{ route('pages.edit', $page->id) }}">
            {{ $page->name_ar ?: trans('app.n_a') }}
        </a>
    </td>
    <td class="align-middle">{{ $page->title }}</td>
    <td class="align-middle">{{ $page->title_ar }}</td>
    <td class="align-middle">{{ $page->menu_sort }}</td>
    <td class="align-middle">{{ $page->updated_at }}</td>
    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $page->present()->labelClass }}">
            {{ trans("app.{$page->status}") }}
        </span>
    </td>
    <td class="text-center align-middle">


        <a href="{{ route('pages.edit', $page->id) }}"
           class="btn btn-icon edit"
           title="@lang('app.edit')"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('pages.delete1', $page->id) }}"
           class="btn btn-icon"
           title="@lang('app.delete')"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
@extends('layouts.app')

@section('page-title', 'Downloads')
@section('page-heading', 'Downloads')

@section('breadcrumbs')
    <li class="breadcrumb-item active">
        Downloads
    </li>
@stop

@section('content')

@include('partials.messages')

<div class="card">
    <div class="card-body">

        <div class="row">

        <div class="col-xl-3 col-md-6">
            <div class="card widget">
                <div class="card-body">
                    <div class="row">
                        <div class="p-3 text-primary flex-1">
                            <i class="fa fa-download fa-3x"></i>
                        </div>

                        <div class="pr-3">
                            <h2 class="text-right">{{ number_format($stats['total']) }}</h2>
                            <div class="text-muted">Total Download </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card widget">
                <div class="card-body">
                    <div class="row">
                        <div class="p-3 text-default flex-1">
                            <i class="fa fa-download fa-check-square  fa-3x"></i>
                        </div>

                        <div class="pr-3">
                            <h2 class="text-right">{{ number_format($stats['new']) }}</h2>
                            <div class="text-muted">Downloads This Month</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card widget">
                <div class="card-body">
                    <div class="row">
                        <div class="p-3 text-success flex-1">
                            <i class="fa fa-eye  fa-3x"></i>
                        </div>

                        <div class="pr-3">
                            <h2 class="text-right">{{ number_format($stats['active']) }}</h2>
                            <div class="text-muted"> Download  Active</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card widget">
                <div class="card-body">
                    <div class="row">
                        <div class="p-3 text-warning flex-1">
                            <i class="fa fa-eye-slash fa-3x"></i>
                        </div>

                        <div class="pr-3">
                            <h2 class="text-right">{{ number_format($stats['unconfirmed']) }}</h2>
                            <div class="text-muted"> Download  UnActive</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

        <form action="" method="GET" id="users-form" class="pb-2 mb-3 border-bottom-light">
            <div class="row my-3 flex-md-row flex-column-reverse">
                <div class="col-md-4 mt-md-0 mt-2">
                    <div class="input-group custom-search-form">
                        <input type="text"
                               class="form-control input-solid"
                               name="search"
                               value="{{ Input::get('search') }}"
                               placeholder="@lang('app.search_for_downloads')">

                        <span class="input-group-append">
                                @if (Input::has('search') && Input::get('search') != '')
                                <a href="{{ route('download.index') }}"
                                   class="btn btn-light d-flex align-items-center text-muted"
                                   role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                            @endif
                            <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-search text-muted"></i>
                                </button>
                            </span>
                    </div>
                </div>

                <div class="col-md-2 mt-2 mt-md-0">
                    <select id="product_search" class="form-control input-solid" name="product_search">
                        <option value="">All</option>
                        @foreach (menu_all() as $product)
                        <option @if($product->id == Input::get('product_search'))
                                selected="selected"
                                @endif
                                value="{{$product->id}}">{{$product->p_name}}  </option>
                        @endforeach
                    </select>

                    </div>

                <div class="col-md-2 mt-2 mt-md-0">
                    {!! Form::select('status', $statuses, Input::get('status'), ['id' => 'status', 'class' => 'form-control input-solid']) !!}
                </div>
                <div class="col-md-4">
                    <a href="{{url('admin/download/active')}}" class="btn btn-primary btn-rounded float-right">

                        Active All   <span class="badge badge-lg badge-light text-right"> {{ number_format(count($products))  }}</span>

                    </a>
                </div>
            </div>
        </form>
        <div class="table-responsive" id="users-table-wrapper">
            <table class="table table-borderless table-striped">
                <thead>
                <tr>
                    <th >#</th>
                    <th >User</th>
                    <th >Product</th>
                    <th>Date</th>
                    <th class="min-width-80">@lang('app.status')</th>
                    <th class="text-center min-width-150">@lang('app.action')</th>
                </tr>
                </thead>
                <tbody>
                    @if (count($products))
                        @foreach ($products as $product)
                            @include('download.partials.row')
                        @endforeach
                    @else
                        <tr>
                            <td colspan="7"><em>@lang('app.no_records_found')</em></td>
                        </tr>
                    @endif
                </tbody>
            </table>

            {!! $products->render() !!}
        </div>
    </div>
</div>





@stop

@section('scripts')
    <script>
        $("#status").change(function () {
            $("#users-form").submit();
        });
        $("#product_search").change(function () {
            $("#users-form").submit();
        });
    </script>
@stop

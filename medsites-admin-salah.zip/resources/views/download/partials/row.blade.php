<tr>

    <td class="align-middle">
        <a href="{{ route('user.show', $product->id) }}">
            {{ $product->id ?: trans('app.n_a') }}
        </a>
    </td>
    <td class="align-middle">{!! $product->users_id()->first()->present()->nameOrEmail    !!}  </td>
    <td class="align-middle">{{ $product->products_id()->first()->p_name }}</td>
    <td class="align-middle">{{ $product->created_at . ' - ' . $product->created_at->diffForHumans()}}</td>


    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $product->present()->labelClass }}">
            {{ trans("app.{$product->status}") }}
        </span>
    </td>

    <td class="text-center align-middle">



        <a href="{{ route('download.delete', $product->id) }}"
           class="btn btn-icon"
           title="@lang('app.delete')"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>

    </td>
</tr>
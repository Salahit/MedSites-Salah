<form action="" method="GET" id="users-form" class="pb-2 mb-3 border-bottom-light">
    <div class="row my-1 flex-md-row flex-column-reverse">
        <div class="col-md-3 mt-md-0 mt-0">
            <div class="input-group custom-search-form">
                <input type="text"
                       class="form-control input-solid"
                       name="search"
                       value="{{ Input::get('search') }}"
                       placeholder="Search Registration
">

                <span class="input-group-append">
                                @if (Input::has('search') && Input::get('search') != '')
                        <a href="{{ route('registration.index') }}"
                           class="btn btn-light d-flex align-items-center text-muted"
                           role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                    @endif
                    <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-search text-muted"></i>
                                </button>
                            </span>
            </div>
        </div>

        <div class="col-md-2 mt-0 mt-md-0">
            <div class="input-group custom-search-form"">
                {!! Form::select('type', [''=>'Type'] +  $listsType   ,Input::get('type'),
        ['id' => 'by_type', 'class' => 'form-control input-solid']) !!}
                <span class="input-group-append">

                                     <button class="btn btn-light" type="button" id="create_record_type">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                  </span>
            </div>
        </div>



        <div class="col-md-3 mt-md-0 mt-0">
            <div class="input-group custom-search-form">
        {!! Form::select('item', [''=>'Select'] +  $listsAddItem   ,Input::get('item'),
                                             ['id' => 'item', 'class' => 'form-control input-solid']) !!}
                <span class="input-group-append">

                          <a href="{{ route('registration.index') }}"
                             class="btn btn-light d-flex align-items-center text-muted"
                             role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                  </span>
    </div></div>


        <div class="col-1 mt-3 mt-md-0">
            <select name="year"   class="form-control input-solid min-width-80" id="year">
                <option value="">Year</option>
                <?php  $currentDate =   \Carbon\ Carbon::now()->addYear(5); ?>

                @for ($i = 2014; $i <= $currentDate->year; $i++)

                    <option @if(Input::get('year') == $i) selected @endif value="{{ $i }}"> {{ $i
                                    }}</option>
                @endfor



            </select>

        </div>
        <div class="col-md-2 mt-0 mt-md-0">
            <div class="input-group custom-search-form">
            {!! Form::select('month',  [''=>'Month',
            '1'=>'January', '2'=>'February','3'=>'March','4'=>'April','5'=>'May','6'=>'June',
           '7'=>'July','8'=>'August','9'=>'September','10'=>'October','11'=>'November', '12'=>'December']
             ,Input::get('month') , ['id' => 'month', 'class' => 'form-control input-solid min-width-100']) !!}

                <span class="input-group-append">

                          <a href="{{ route('registration.create') }}"
                             class="btn btn-light d-flex align-items-center text-muted"
                             role="button">
                                        <i class="fas fa-plus"></i>
                                    </a>
                  </span>
        </div>
        </div>
    </div>
</form>
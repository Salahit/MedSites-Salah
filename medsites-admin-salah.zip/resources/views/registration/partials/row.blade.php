<tr>

    <td>

        <a href="{{ route('registration.show', $EventsLis->id) }}"> {{ \Illuminate\Support\Str::limit
        ($EventsLis->UsersId()->first()->present()->nameOrEmail ,6)  }}
        </a>
    </td>
    <td><a href="{{ route('registration.edit', $EventsLis->id) }}">{{ \Illuminate\Support\Str::limit($EventsLis->title,
    20)  }}    </a>
        <a tabindex="0" role="button" class="btn btn-icon float-right"
           data-trigger="focus"
           data-placement="left"
           data-html="true"
           data-toggle="popover"
           title="Title"
           data-content="{!! nl2br($EventsLis->title)  !!} ">
            <i class="fas fa-info-circle"></i>
        </a>
    </td>



    <td  >

               <span class="badge badge-lg badge-{{ $EventsLis->present()->labelClass }}" style="background-color:{{
        $EventsLis->colorss  }} ">
            {{ $EventsLis->ItemId()->first()->name  }}
        </span>



    </td>
    <td>{{ \Illuminate\Support\Str::limit($EventsLis->description, 50)  }}
        <a tabindex="0" role="button" class="btn btn-icon float-right"
           data-trigger="focus"
           data-placement="left"
           data-html="true"
           data-toggle="popover"
           title="Description"
           data-content="{!! nl2br($EventsLis->description)  !!} ">
            <i class="fas fa-info-circle"></i>
        </a>
    </td>
    <td> {{ \Carbon\Carbon::parse($EventsLis->start)->format('D d F Y ') }}</td>

    <td>

        <a href=""

                      class="btn btn-icon eye"
                      title="View Event "
                      data-toggle="tooltip" data-placement="top">
          {{ $EventsLis->comments_count }}

        </a>
        <a href="{{ route('registration.show', $EventsLis->id)  }}"

           class="btn btn-icon eye"
           title="View Event "
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye fa-2x"></i>

        </a>
        <a href="{{ route('registration.edit', $EventsLis->id) }}"
           class="btn btn-icon edit"
           title=" Edit Calendar "
           data-toggle="tooltip"
           data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('registration.delete', $EventsLis->id) }}"
           class="btn btn-icon"
           title="Delete Calendar"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
@extends('layouts.app')

@section('page-title', 'Comments ')
@section('page-heading', $event->title)
ؤ
@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('registration.index') }}">   Registration </a>
    </li>
    <li class="breadcrumb-item active">
        {{ $event->title }}
    </li>
@stop

@section('content')

    @include('partials.messages')

    <div class="row" >
        <div class="col-lg-4 col-xl-5">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">
                        @lang('app.details') Ticket

                        <small class="float-right">


                        </small>
                    </h5>



                    <ul class="list-group list-group-flush mt-3">


                        <li class="list-group-item">

                            {{ $event->start }} <br><strong>{{ $event->created_at->diffForHumans() }} </strong>
                        </li>
                        <li class="list-group-item">
                            <strong>Add by:</strong>
                            <a href="{{ route('user.show', $event->user_id) }}">  {{ $event->usersid->first()
                            ->present()->nameOrEmail   }}</a>
                        </li>
                        <li class="list-group-item">
                            <strong>Title:</strong>
                      {{ $event->title }}
                        </li>
                        <li class="list-group-item">
                            <strong>Description :</strong>
                            {!! $event->description  !!}
                        </li>

                    </ul>

                    {!! Form::open(['route' => 'registration.storeMessage', 'id' => 'message-form']) !!}

                        <input type="hidden" value="{{ $event->user_id   }}" name="user_id" >
                        <input type="hidden" value="{{ $event->id   }}" name="registration_id" >
                        <div class="row" id="container">
                        <div class="col-md-12" >
                            <div class="form-group">
                                <label for="message">Comment  <a href="#" id="toggle_fullscreen">Toggle
                                        Fullscreen</a></label>
                                <textarea name="message" id="description" rows="5" class="form-control">{{
                    old('message') }}</textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-primary">
                                 Send Comment
                                </button>
                            </div>
                        </div>
                            {!! Form::close() !!}
                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-8 col-xl-7 " >
            <div class="scroll-1  square scrollbar-cyan bordered-cyan">
                <div class="card">
                    <div class="card-body mt-md-0 mt-0">


                        @if (count($message2))
                            @foreach($message2 as $licenseActivity)
                                @if ($licenseActivity->user_id != auth()->user()->id)
                                    <div class="card text-primary bg-white mt-md-0 mt-0">
                                        @else
                                            <div class="card bg-primary text-light mt-md-0 mt-0"  >
                                                @endif
                                                <span class="badge badge position-absolute mt-md-0 mt-0"> {{$licenseActivity->created_at->diffForHumans()}}
                                                    @if ($licenseActivity->user_id == auth()->user()->id)
                                                          @endif - {{   $licenseActivity->usersid->first()->present()
                       ->nameOrEmail }}


                       </span>




                                                    <div class="dropdown show d-inline-block float-right mt-md-0 mt-0">

                                                           <a class="btn btn-icon float-right"
                                                       href="#" role="button" id="dropdownMenuLink"
                                                       data-toggle="dropdown"
                                                       data-html="true"
                                                       aria-haspopup="true" aria-expanded="true">
                                                               @if ($licenseActivity->user_id == auth()->user()->id)    <i class="fas fa-edit"></i>
                                                               @endif  </a>
                                                        @if ($licenseActivity->user_id == auth()->user()->id)
                                                        <div class="col-md-12 dropdown-menu dropdown-menu-right"
                                                         aria-labelledby="dropdownMenuLink">
                                                        <div class="col-md-12 mt-md-0 mt-0">

                                                            {!! Form::open(['route' => ['registration.updateText', $licenseActivity->id],
                                                             'method' => 'PUT', 'id' =>
                                                            'stockEdit-form']) !!}

                                                            <div class="form-group my-0">
  <textarea name="message"  rows="5" class="form-control">{{  html_entity_decode($licenseActivity->message)  }}
  </textarea>


                                                            </div>
                                                        </div>

                                                        <div class="form-group my-3   ml-5">
                                                            <button type="submit" class="btn btn-primary">
                                                                Save
                                                            </button>
                                                        </div>
                                                        {!! Form::close() !!}
                                                    </div>
                                                        @endif


                                                </div>

                                                <div class="mt-md-0 mt-0 ml-1">

                                                    {!! $licenseActivity->message !!}


                                                </div>
                                            </div>
                                            @endforeach


                                            @else
                                                <p class="text-muted font-weight-light"><em>no message from this user yet</em></p>
                                            @endif
                                    </div>
                    </div>
                </div>
            </div>


            @stop
            @section('after_styles')
                <link rel="stylesheet" type="text/css" href="{{ url('design')}}/assets/plugins/simditor/styles/simditor.css" />



                @stack('dashboard_styles')

                <style>




                    .scrollbar-cyan::-webkit-scrollbar-track {
                        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
                        background-color: #F5F5F5;
                        border-radius: 10px; }

                    .scrollbar-cyan::-webkit-scrollbar {
                        width: 12px;
                        background-color: #F5F5F5; }

                    .scrollbar-cyan::-webkit-scrollbar-thumb {
                        border-radius: 10px;
                        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
                        background-color: #00bcd4; }

                    .scrollbar-dusty-grass::-webkit-scrollbar-track {
                        -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.1);
                        background-color: #F5F5F5;
                        border-radius: 10px; }



                    .bordered-deep-purple::-webkit-scrollbar-track {
                        -webkit-box-shadow: none;
                        border: 1px solid #512da8; }

                    .bordered-deep-purple::-webkit-scrollbar-thumb {
                        -webkit-box-shadow: none; }

                    .bordered-cyan::-webkit-scrollbar-track {
                        -webkit-box-shadow: none;
                        border: 1px solid #00bcd4; }

                    .bordered-cyan::-webkit-scrollbar-thumb {
                        -webkit-box-shadow: none; }

                    .square::-webkit-scrollbar-track {
                        border-radius: 0 !important; }

                    .square::-webkit-scrollbar-thumb {
                        border-radius: 0 !important; }

                    .thin::-webkit-scrollbar {
                        width: 6px; }

                    .scroll-1 {
                        position: relative;
                        overflow-y: scroll;

                        height: 600px;
                    }


                </style>

            @endsection
            @section('after_scripts')



                <script src="{{ url('design')}}/assets/plugins/simditor/scripts/mobilecheck.js"></script>

                <script src="{{ url('design')}}/assets/plugins/simditor/scripts/module.js"></script>
                <script src="{{ url('design')}}/assets/plugins/simditor/scripts/hotkeys.js"></script>
                <script src="{{ url('design')}}/assets/plugins/simditor/scripts/uploader.js"></script>
                <script src="{{ url('design')}}/assets/plugins/simditor/scripts/simditor.js"></script>
                <script type="text/javascript">
                    Simditor.i18n = {
                        'en': {
                            'blockquote': 'Block Quote',
                            'bold': 'Bold',
                            'code': 'Code',
                            'color': 'Text Color',
                            'coloredText': 'Colored Text',
                            'hr': 'Horizontal Line',
                            'image': 'Insert Image',
                            'externalImage': 'External Image',
                            'uploadImage': 'Upload Image',
                            'uploadFailed': 'Upload failed',
                            'uploadError': 'Error occurs during upload',
                            'imageUrl': 'Url',
                            'imageSize': 'Size',
                            'imageAlt': 'Alt',
                            'restoreImageSize': 'Restore Origin Size',
                            'uploading': 'Uploading',
                            'indent': 'Indent',
                            'outdent': 'Outdent',
                            'italic': 'Italic',
                            'link': 'Insert Link',
                            'linkText': 'Text',
                            'linkUrl': 'Url',
                            'linkTarget': 'Target',
                            'openLinkInCurrentWindow': 'Open link in current window',
                            'openLinkInNewWindow': 'Open link in new window',
                            'removeLink': 'Remove Link',
                            'ol': 'Ordered List',
                            'ul': 'Unordered List',
                            'strikethrough': 'Strikethrough',
                            'table': 'Table',
                            'deleteRow': 'Delete Row',
                            'insertRowAbove': 'Insert Row Above',
                            'insertRowBelow': 'Insert Row Below',
                            'deleteColumn': 'Delete Column',
                            'insertColumnLeft': 'Insert Column Left',
                            'insertColumnRight': 'Insert Column Right',
                            'deleteTable': 'Delete Table',
                            'title': 'Title',
                            'normalText': 'Text',
                            'underline': 'Underline',
                            'alignment': 'Alignment',
                            'alignCenter': 'Align Center',
                            'alignLeft': 'Align Left',
                            'alignRight': 'Align Right',
                            'selectLanguage': 'Select Language',
                            'fontScale': 'Font Size',
                            'fontScaleXLarge': 'X Large Size',
                            'fontScaleLarge': 'Large Size',
                            'fontScaleNormal': 'Normal Size',
                            'fontScaleSmall': 'Small Size',
                            'fontScaleXSmall': 'X Small Size'
                        }
                    };

                    (function() {
                        $(function() {
                            var $preview, editor, mobileToolbar, toolbar, allowedTags;
                            Simditor.locale = 'en';
                            toolbar = ['bold','italic','underline','fontScale','color','|','ol','ul','blockquote','table','link'];
                            mobileToolbar = ["bold", "italic", "underline", "ul", "ol"];
                            if (mobilecheck()) {
                                toolbar = mobileToolbar;
                            }


                            allowedTags = ['br','span','a','img','b','strong','i','strike','u','font','p','ul','ol','li','blockquote','pre','h1','h2','h3','h4','hr','table'];
                            editor = new Simditor({
                                textarea: $('#description'),
                                placeholder: 'Message',
                                toolbar: toolbar,
                                pasteImage: false,
                                defaultImage: '{{ url("design")}}/assets/plugins/simditor/images/image.png',
                                upload: false,
                                allowedTags: allowedTags
                            });
                            editor = new Simditor({
                                textarea: $('#descriptionar'),
                                placeholder: 'صف ما الذي يجعل الممتج فريدا من نوعه...',
                                toolbar: toolbar,
                                pasteImage: false,
                                defaultImage: '{{ url("design")}}/assets/plugins/simditor/images/image.png',
                                upload: false,
                                allowedTags: allowedTags
                            });
                            $preview = $('#preview');
                            if ($preview.length > 0) {
                                return editor.on('valuechanged', function(e) {
                                    return $preview.html(editor.getValue());
                                });
                            }
                        });
                    }).call(this);

                    $('#toggle_fullscreen').on('click', function(){
                        // if already full screen; exit
                        // else go fullscreen
                        if (
                            document.fullscreenElement ||
                            document.webkitFullscreenElement ||
                            document.mozFullScreenElement ||
                            document.msFullscreenElement
                        ) {
                            if (document.exitFullscreen) {
                                document.exitFullscreen();
                            } else if (document.mozCancelFullScreen) {
                                document.mozCancelFullScreen();
                            } else if (document.webkitExitFullscreen) {
                                document.webkitExitFullscreen();
                            } else if (document.msExitFullscreen) {
                                document.msExitFullscreen();
                            }
                        } else {
                            element = $('#container').get(0);
                            if (element.requestFullscreen) {
                                element.requestFullscreen();
                            } else if (element.mozRequestFullScreen) {
                                element.mozRequestFullScreen();
                            } else if (element.webkitRequestFullscreen) {
                                element.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
                            } else if (element.msRequestFullscreen) {
                                element.msRequestFullscreen();
                            }
                        }
                    });

                </script>
                <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->

    @stack('dashboard_scripts')
@endsection

@section('scripts')



        {!! JsValidator::formRequest('MedSites\Http\Requests\Registration\CreateMessageRequest', '#message-form') !!}
        {!! JsValidator::formRequest('MedSites\Http\Requests\Registration\UpdateMessageRequest', '#stockEdit-form') !!}


@stop
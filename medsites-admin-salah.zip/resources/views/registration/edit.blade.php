@extends('layouts.app')

@section('page-title', trans('app.registration_calendar') )
@section('page-heading', $edit ? $event->id : $event->id .' '.  trans('app.create_new_registration_calendar'))

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('registration.index',$event->id) }}">@lang('app.registration_calendar')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

    @include('partials.messages')


        {!! Form::open(['route' => ['registration.update', $event->id], 'method' => 'PUT', 'id' =>
        'Registration-form']) !!}


    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <h5 class="card-title">
                        Registration Calendar Details                </h5>
                    <p class="text-muted">
                        A general Registration Calendar information.
                    </p>
                </div>

                <div class="col-md-9">
                    <div class="form-group">
                        <div class="row my-0 flex-md-row flex-column-reverse">
                            <div class="col-md-3 mt-md-0 mt-0">
                                <label for="by_company">Item</label>
                            </div>
                            <div class="col-md-2 mt-md-0 mt-0">
    <span class="input-group-append">

                               </span>
                            </div>
                        </div>

                        {!! Form::select('item_id', [''=>'Select'] +  $listsAddItem   ,$event->item_id ,
                                           ['id' => 'add_item_id', 'class' => 'form-control input-solid']) !!}



                    </div>
                    <div class="form-group">
                        <label for="colorss">Type Event</label>


                        <select name="colorss" id="colorss" class="form-control input-solid" >

                            <option {{  $event->colorss == "#6699cc" ? "selected" : '' }} style="background:
                                   #6699cc; color: #fff;"
                                    value="#6699cc">Information</option>
                            <option {{  $event->colorss == "#009900" ? "selected" : ''}} style="background:
                                   #009900; color: #fff;"
                                    value="#009900">Success</option>
                            <option {{  $event->colorss == "#cc3333" ? "selected" : ''}} style="background:
                                   #cc3333; color: #fff;"  value="#cc3333">Submit
                                Papers</option>
                            <option {{  $event->colorss == "#99ccff" ? "selected" : ''}} style="background:
                                   #99ccff; color: #fff;" value="#99ccff">Follow Up</option>
                            <option {{  $event->colorss == "#6699cc" ? "selected" : ''}} style="background:
                                   #660000; color: #fff;" value="#660000">Scientific
                                office</option>
                            <option {{  $event->colorss == "#ffea00" ? "selected" : ''}} style="background:
                                   #ffea00; color: #fff;" value="#ffea00">Response</option>
                            <option {{  $event->colorss == "#ff9933" ? "selected" : ''}} style="background:
                                   #ff9933; color: #fff;"
                                    value="#ff9933">Important</option>
                            <option {{  $event->colorss == "#006633" ? "selected" : ''}} style="background:
                                   #006633; color: #fff;" value="#006633">Execution</option>
                            <option {{  $event->colorss == "#003333" ? "selected" : ''}} style="background:
                                   #003333; color: #fff;"  value="#003333">Request</option>
                            <option {{  $event->colorss == "#663300" ? "selected" : ''}} style="background:
                                   #663300; color: #fff;" value="#663300">Future</option>
                        </select>


                    </div>
                    <div class="form-group">
                        <label for="from_company">Title</label>
                        <input type="text" class="form-control"
                               name="title" placeholder="Title" value="{{ $event->title }}" >

                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea name="description"  class="form-control">{{$event->description}}</textarea>


                    </div>
                    <div class="form-group">
                        <label for="start">Start</label>


                        <input name="start" class="form-control" type="text"
                               value="{{ \Carbon\Carbon::parse($event->start)->format('Y-m-d') }}">


                    </div>


                    <input type="hidden" class="form-control" value="{{ $event->id }}"  name="id"  >



                </div>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">
        {{ $edit ? trans('app.update_registration_calendar') : trans('app.create_registration_calendar') }}
    </button>

    </form>



@stop

@section('scripts')

    {!! JsValidator::formRequest('MedSites\Http\Requests\Registration\UpdateRegistrationRequest', '#Registration-form') !!}


@stop
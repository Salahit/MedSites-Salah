@extends('layouts.errors')

@section('title', 'Be Right Back')

@section('content')
    <h1 class="mt-5">Be Right Back.</h1>
    <p class="lead">Application is currently being updated.  Please check back in few minutes.</p>
@stop
@extends('layouts.errors')

@section('title', 'Forbidden!')

@section('content')
    <h1 class="mt-5">Forbidden!</h1>
    <p class="lead">You don't have permission to access this page.</p>
@stop
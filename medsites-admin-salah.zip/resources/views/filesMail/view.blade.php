@extends('layouts.app')

@section('page-title', $filesMail->file_name)
@section('page-heading', $filesMail->file_name)

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('filesMail.index') }}">@lang('app.filesMail')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $filesMail->file_name  }}
    </li>
@stop

@section('content')

<div class="row">
    <div class="col-lg-4 col-xl-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    @lang('app.details')

                    <small class="float-right">


                        <a href="{{ route('filesMail.edit', $filesMail->id) }}" class="edit"
                           data-toggle="tooltip" data-placement="top" title="@lang('app.edit')">
                            @lang('app.edit')
                        </a>
                    </small>
                </h5>


                <ul class="list-group list-group-flush mt-3">
                    <div class="d-flex align-items-center flex-column pt-3">
                        <div>
                          {!!  $filesMail->present()->picture !!}
                        </div>
                    </div>


                    <li class="list-group-item">

                        {{ $filesMail->file_name }}
                    </li>
                    <li class="list-group-item"><strong> Out or In :</strong>
                        @if($filesMail->status_out_in === 'In')

<span class="badge badge-lg badge-success">
 {{ $filesMail->status_out_in }}
 @else
 <span class="badge badge-lg badge-secondary">
 {{ $filesMail->status_out_in }} @endif

 </span>






                    </li>

                    <li class="list-group-item">
                        Date Create<br>
                        <strong>{{ \Carbon\Carbon::parse($filesMail->created_at)->format('Y F  d D') }}<br>
                       {{ $filesMail->created_at->diffForHumans()}}
                        </strong>
                    </li>

                </ul>
            </div>
        </div>
    </div>

    <div class="col-lg-8 col-xl-9">
        <div class="card">
            <div class="card-body">

                @include('filesMail.partials.search')


                @if (count($fileMoves))
                    <table class="table table-borderless table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>By</th>
                            <th>To hand</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Reason</th>

                            <th><-></th>

                            <th class="text-center min-width-150">@lang('app.action')</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($fileMoves as $moves)
                            @include('filesMail.partials.rowMoves')
                        @endforeach
                        </tbody>
                    </table>
                @else
                    <p class="text-muted font-weight-light"><em>No moves  from this files  yet.</em></p>
                @endif
                {!! $fileMoves->render() !!}
            </div>
        </div>
    </div>
</div>
@stop
<form action="" method="GET" id="users-form" class="pb-2 mb-3 border-bottom-light">
    <div class="row my-1 flex-md-row flex-column-reverse">
        <div class="col-md-4 mt-md-0 mt-0">
            <div class="input-group custom-search-form">
                <input type="text"
                       class="form-control input-solid"
                       name="search"
                       value="{{ Input::get('search') }}"
                       placeholder="Search Files
">

                <span class="input-group-append">
                                @if (Input::has('search') && Input::get('search') != '')
                        <a href="{{ route('license.index') }}"
                           class="btn btn-light d-flex align-items-center text-muted"
                           role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                    @endif
                    <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-search text-muted"></i>
                                </button>
                            </span>
            </div>
        </div>


        <div class="col-md-2 mt-2 mt-md-0">
            {!! Form::select('status', ['' => 'Select' , 'In' => 'In', 'Out' => 'Out'], Input::get('status'),
            ['id' =>
             'status',
            'class'
             =>
            'form-control
            input-solid']) !!}
        </div>



        <div class="col-md-6">
            <a href="{{ route('filesMail.createMoves',$filesMail->id) }}" class="btn btn-primary btn-rounded
            float-right">
                <i class="fas fa-plus mr-2"></i>
                Add File
            </a>
        </div>
    </div>
</form>
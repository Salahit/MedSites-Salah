<tr>

    <td class="align-middle">
        <a href="{{ route('user.show', $moves->id) }}">
            {{ $moves->id ?: trans('app.n_a') }}
        </a>
    </td>


    <td class="align-middle">{!! $moves->byCompanyId()->first()->name    !!}  </td>
    <td class="align-middle">{!! $moves->byHandsId()->first()->name    !!}  </td>



    <td class="align-middle">{!! $moves->CompanyId()->first()->name    !!}  </td>
    <td class="align-middle">{!! $moves->CompanyIdOut()->first()->name    !!}  </td>
    <td class="align-middle">
        {!! \Illuminate\Support\Str::limit($moves->reason, 15 ) !!}</td>

    <td class="align-middle">
        @if($moves->in_or_out === 'In')

            <span class="badge badge-lg badge-success">
 {{ $moves->in_or_out }}
                @else
                    <span class="badge badge-lg badge-secondary">
 {{ $moves->in_or_out }} @endif

 </span>

    </td>



    <td class="text-center align-middle">
        <a href="{{ route('filesMail.show', $moves->id) .'?year='.\Carbon\Carbon::now()->format('Y') }}"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-0"></i>

        </a>

        <a href="{{ route('filesMail.editMoves', $moves->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('filesMail.deleteMoves', $moves->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
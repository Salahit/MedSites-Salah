<tr>

    <td class="align-middle">
        <a href="{{ route('user.show', $filesMail->id) }}">
            {{ $filesMail->id ?: trans('app.n_a') }}
        </a>
    </td>


    <td class="align-middle">{!! $filesMail->byCompanyId()->first()->name    !!}  </td>
    <td class="align-middle">{{ $filesMail->file_name }}</td>
    <td class="align-middle">{!! $filesMail->ItemId()->first()->name    !!}  </td>

    <td class="align-middle">{!! $filesMail->CompanyId()->first()->name    !!}  </td>
    <td class="align-middle">{{ $filesMail->moves_count }}</td>


    <td class="align-middle">
        @if($filesMail->status_out_in === 'In')

            <span class="badge badge-lg badge-success">
 {{ $filesMail->status_out_in }}
                @else
                    <span class="badge badge-lg badge-secondary">
 {{ $filesMail->status_out_in }} @endif

 </span>

    </td>

    <td class="text-center align-middle">
        <a href="{{ route('filesMail.show', $filesMail->id) .'?year='.\Carbon\Carbon::now()->format('Y') }}"

           class="btn btn-icon eye"
           title="View File"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

        <a href="{{ route('filesMail.edit', $filesMail->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('filesMail.delete', $filesMail->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
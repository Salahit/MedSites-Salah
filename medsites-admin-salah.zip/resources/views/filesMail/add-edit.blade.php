@extends('layouts.app')

@section('page-title', trans('app.filesMail'))
@section('page-heading', $edit ? $filesMail->file_name : trans('app.create_new_filesMail'))

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('filesMail.index') }}">@lang('app.filesMail')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['filesMail.update', $filesMail->id], 'method' => 'PUT', 'id' => 'filesMail-form', 'enctype' => 'multipart/form-data']) !!}
@else
    {!! Form::open(['route' => 'filesMail.store', 'id' => 'filesMail-form' , 'enctype' => 'multipart/form-data']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    @lang('app.filesMail_details_big')
                </h5>
                <p class="text-muted">
                    A general Files Mail information.
               </p>
            </div>
            <div class="col-md-9">
                <div class="form-group">
                    <label for="name">@lang('app.name')</label>
                    <input type="text" class="form-control" id="file_name"
                           name="file_name" placeholder="@lang('app.filesMail_name')" value="{{ $edit ?
                           $filesMail->file_name : old
                           ('file_name') }}">
                </div>

                <div class="form-group">
                    <div class="row my-0 flex-md-row flex-column-reverse">
                        <div class="col-md-3 mt-md-0 mt-0">
                            <label for="by_company">By Company</label>
                        </div>
                        <div class="col-md-2 mt-md-0 mt-0">
 <span class="input-group-append">
            <button class="btn btn-light" type="button" id="create_record">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                            </span>
                        </div>
                    </div>

                    {!! Form::select('by_company_id', [''=>'Select'] +  $listsCompany    , $edit ? $filesMail->by_company_id : '',
                    ['id' => 'by_company', 'class' => 'form-control input-solid']) !!}



                </div>

                <div class="form-group">
                    <div class="row my-0 flex-md-row flex-column-reverse">
                        <div class="col-md-3 mt-md-0 mt-0">
                            <label for="by_company">From Company</label>
                        </div>
                        <div class="col-md-2 mt-md-0 mt-0">
 <span class="input-group-append">
            <button class="btn btn-light" type="button" id="AddCompany_record">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                            </span>
                        </div>
                    </div>

                    {!! Form::select('company_id', [''=>'Select'] +  $listsAddCompany   , $edit ? $filesMail->company_id : '',
                    ['id' => 'add_company_id', 'class' => 'form-control input-solid']) !!}
   </div>


                <div class="form-group">
                    <div class="row my-0 flex-md-row flex-column-reverse">
                        <div class="col-md-3 mt-md-0 mt-0">
                            <label for="by_company">Item</label>
                        </div>
                        <div class="col-md-2 mt-md-0 mt-0">
 <span class="input-group-append">
            <button class="btn btn-light" type="button" id="AddItem_record">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                            </span>
                        </div>
                    </div>

 {!! Form::select('item_id', [''=>'Select'] +  $listsAddItem   ,$edit ? $filesMail->item_id : '',
                    ['id' => 'add_item_id', 'class' => 'form-control input-solid']) !!}



                </div>

                <div class="form-group">
                    <label for="reason">Reason</label>
                    <input type="text" class="form-control" id="reason"
                           name="reason" placeholder="reason" value="{{ $edit ? $filesMail->reason : old
                           ('reason') }}">
                </div>

                <div class="form-group">
                    <label for="created_arrive">Date Arrive</label>
                    <input type="date" class="form-control" id="created_arrive"
                           name="created_arrive"   value="{{ $edit ? $filesMail->created_arrive
                            : old('created_arrive') }}">
                </div>
                <div class="form-group">
                    <label for="picture">Image</label>
                    <input type="file" class="form-control" id="picture"    name="picture" >


                </div>

                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" id="note" class="form-control">{{ $edit ? $filesMail->note : old('note')
                    }}</textarea>
                </div>
            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    {{ $edit ? trans('app.update_filesMail') : trans('app.create_filesMail') }}
</button>

</form>


<!-- Modal -->
<div class="modal fade" id="formModal"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="sample_form" class="form-horizontal" enctype="multipart/form-data">
                @csrf
            <div class="modal-body">
                <span id="form_result"></span>
                <div class="form-group">
                    <label for="from_company">New Company</label>
                    <input type="text" class="form-control" id="name"
                           name="name" placeholder="From Company" value="{{ $edit ? $filesMail->name : old
                           ('name') }}">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <input type="hidden" name="action" id="action" />
                <input type="hidden" name="hidden_id" id="hidden_id" />
                <input type="submit" name="action_button" id="action_button" class="btn btn-warning" value="Add" />

            </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="formModalAddCompany"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="AddCompany_form" class="form-horizontal" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <span id="form_result_add_company"></span>
                    <div class="form-group">
                        <label for="from_company">New Company File</label>
                        <input type="text" class="form-control" id="name"
                               name="name" placeholder="From Company" value="{{ $edit ? $filesMail->name : old
                           ('name') }}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="actionAddCompany" id="action" />
                    <input type="hidden" name="hidden_id" id="hidden_id" />
                    <input type="submit" name="action_button" id="action_buttonAddCompany" class="btn btn-warning" value="Add" />

                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="formModalAddItem"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="AddItem_form" class="form-horizontal" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <span id="form_result_add_item"></span>
                    <div class="form-group">
                        <label for="from_company">New Item</label>
                        <input type="text" class="form-control" id="name"
                               name="name" placeholder="New Item" value="{{ old
                           ('name') }}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="actionAddCompany" id="action" />
                    <input type="hidden" name="hidden_id" id="hidden_id" />
                    <input type="submit" name="action_button" id="action_buttonAddItem" class="btn btn-warning" value="Add" />

                </div>
            </form>
        </div>
    </div>
</div>

@stop

@section('scripts')
    <script>
        $('#AddItem_record').click(function(){
            $('.modal-title').text("Add New Record");
            $('#action_buttonAddItem').val("Add");
            $('#action').val("Add");
            $('#formModalAddItem').modal('show');
        });


        $('#AddCompany_record').click(function(){
            $('.modal-title').text("Add New Record");
            $('#action_buttonAddCompany').val("Add");
            $('#action').val("Add");
            $('#formModalAddCompany').modal('show');
        });

            $('#create_record').click(function(){
                $('.modal-title').text("Add New Record");
                $('#action_button').val("Add");
                $('#action').val("Add");
                $('#formModal').modal('show');
            });

            $('#sample_form').on('submit', function(event){

                event.preventDefault();
                if($('#action').val() == 'Add')
                {
                    $.ajax({
                        url:"{{ route('filesMail.storeCompany') }}",
                        method:"POST",
                        data: new FormData(this),
                        contentType: false,
                        cache:false,
                        processData: false,
                        dataType:"json",
                        success:function(data)
                        {
                            var html = '';
                            if(data.errors)
                            {
                                html = '<div class="alert alert-danger">';
                                for(var count = 0; count < data.errors.length; count++)
                                {
                                    html += '<p>' + data.errors[count] + '</p>';
                                }
                                html += '</div>';
                            }
                            if(data.success)
                            {
                                html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                                $('#sample_form')[0].reset();
                               // $("#user_table").load(" #user_table");

                                    $('#by_company').append('<option value = '+data.id+'>'+data.name+'</option>');


                            }
                            $('#form_result').html(html);
                        }
                    })
                }




            });

        $('#AddCompany_form').on('submit', function(event){

            event.preventDefault();
            if($('#action').val() == 'Add')
            {
                $.ajax({
                    url:"{{ route('filesMail.storeAddCompany') }}",
                    method:"POST",
                    data: new FormData(this),
                    contentType: false,
                    cache:false,
                    processData: false,
                    dataType:"json",
                    success:function(data)
                    {
                        var html = '';
                        if(data.errors)
                        {
                            html = '<div class="alert alert-danger">';
                            for(var count = 0; count < data.errors.length; count++)
                            {
                                html += '<p>' + data.errors[count] + '</p>';
                            }
                            html += '</div>';
                        }
                        if(data.success)
                        {
                            html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                            $('#AddCompany_form')[0].reset();
                            // $("#user_table").load(" #user_table");

                            $('#add_company_id').append('<option value = '+data.id+'>'+data.name+'</option>');


                        }
                        $('#form_result_add_company').html(html);
                    }
                })
            }




        });

        $('#AddItem_form').on('submit', function(event){

            event.preventDefault();
            if($('#action').val() == 'Add')
            {
                $.ajax({
                    url:"{{ route('filesMail.storeAddItem') }}",
                    method:"POST",
                    data: new FormData(this),
                    contentType: false,
                    cache:false,
                    processData: false,
                    dataType:"json",
                    success:function(data)
                    {
                        var html = '';
                        if(data.errors)
                        {
                            html = '<div class="alert alert-danger">';
                            for(var count = 0; count < data.errors.length; count++)
                            {
                                html += '<p>' + data.errors[count] + '</p>';
                            }
                            html += '</div>';
                        }
                        if(data.success)
                        {
                            html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                            $('#AddItem_form')[0].reset();
                            // $("#user_table").load(" #user_table");

                            $('#add_item_id').append('<option value = '+data.id+'>'+data.name+'</option>');


                        }
                        $('#form_result_add_item').html(html);
                    }
                })
            }




        });

    </script>

@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2-bootstrap4.css') !!}">



@endsection

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4',
                    width: 'style',
                    placeholder: $(this).attr('placeholder'),
                    allowClear: Boolean($(this).data('allow-clear')),

                });
            });
        });

    </script>

    <script src="{!! url('assets/plugins/select2/select2.full.js') !!}"></script>

    @stack('dashboard_scripts')
@endsection


@if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\FilesMail\UpdateFilesMailRequest', '#filesMail-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\FilesMail\CreateFilesMailRequest', '#filesMail-form') !!}
    @endif
@stop
@extends('layouts.app')

@section('page-title', 'Income')
@section('page-heading',  'Income')

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('expenses.index') }}"> Income </a>
    </li>

@stop

@section('content')

    @include('partials.messages')

    <div class="card">
        <div class="card-body">
            @include('expense.accounting.income.partials.search')

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th> ID</th>
                        <th> Amount</th>
                        <th>	Price Dollar </th>

                        <th>Income Type</th>
                        <th>Name </th>
                        <th>Add By </th>

                        <th> Arrival Date</th>
                        <th>Create Date</th>
                        <th>@lang('app.action')</th>
                    </tr>
                    </thead>
                    <tbody>
                        @if (count($incomes))
                            @foreach ($incomes as $income)
                                @include('expense.accounting.income.partials.row')
                            @endforeach
                        @else
                            <tr>
                                <td colspan="8"><em>@lang('app.no_records_found')</em></td>
                            </tr>
                        @endif
                    </tbody>
                    <tfoot>

                    <th>  </th>
                    <th><h4>{{number_format($paginateIncomeSum)}} </h4></th>

                    <th> </th>
                    <th>  </th>
                    <th>   </th>
                    <th>  </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                {!! $incomes->render() !!}
            </div>
        </div>
    </div>
@stop

@section('scripts')


    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $("#month").change(function () {
            $("#users-form").submit();
        });

        $("#company").change(function () {
            $("#users-form").submit();
        });

        $("#type").change(function () {
            $("#users-form").submit();
        });

        $("#name").change(function () {
            $("#users-form").submit();
        });


    </script>


@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2-bootstrap4.css') !!}">



@endsection

@section('after_scripts')
    <script>


        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4 ',

                });
            });
        });

    </script>

    <script src="{!! url('assets/plugins/select2/select2.full.js') !!}"></script>

    @stack('dashboard_scripts')
@endsection





@stop
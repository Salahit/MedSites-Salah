@extends('layouts.app')

@section('page-title','Income' )
@section('page-heading', $edit ? $income->invoice_id : 'Income' )

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('accounting.income') }}">Income</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['income.update', $income->id], 'method' => 'PUT', 'id' => 'income-form']) !!}
@else
    {!! Form::open(['route' => 'income.store', 'id' => 'income-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    @lang('app.filesMail_details_big')
                </h5>
                <p class="text-muted">
                    A general Income information.
                </p>
            </div>
            <div class="col-md-9">

                <div class="form-group">
                    <label for="reason">Income ID</label>
                    <input type="text" class="form-control" id="income_id"
                           name="income_id" placeholder="Income Id" value="{{ $edit ? $income->income_id : old
                           ('income_id') }}">
                </div>





                <div class="form-group">
                    <label for="name"> Income Type </label>
                    {!! Form::select('income_type', [''=>'Select'] +  $listsIncomeInvoiceType     , $edit ?
                         $income->income_type : '',
                         ['id' => 'income_type', 'class' => 'form-control ' ]) !!}

                </div>
                <div class="form-group">
                    <label for="reason"> Amount</label>
                    <input type="number" class="form-control" id="amount"
                           name="amount" placeholder="00 $" value="{{ $edit ? $income->amount : old
                           ('amount') }}">
                </div>

                <div class="form-group">
                    <label for="reason"> Name</label>
                    <input type="text" class="form-control" id="name"
                           name="name" placeholder="Name" value="{{ $edit ? $income->name : old
                           ('name') }}">
                </div>






                <div class="form-group">
                    <label for="arrive_at">Date Arrivel</label>
                    <input type="date" class="form-control" id="arrival_at"
                           name="arrival_at"   value="{{ $edit ? $income->arrival_at
                            : old('arrival_at') }}">
                </div>


                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" id="note" class="form-control">{{ $edit ? $income->note : old('note')
                    }}</textarea>
                </div>
            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    {{ $edit ? trans('app.update') : trans('app.create') }}
</button>

</form>

<!-- Modal -->
<div class="modal fade" id="formModal"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="sample_form" class="form-horizontal" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <span id="form_result"></span>
                    <div class="form-group">
                        <label for="from_company">New Name Expense</label>
                        <input type="text" class="form-control" id="name"
                               name="name" placeholder="Name Expense" value="{{  old ('name') }}">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="action" id="action" />
                    <input type="hidden" name="hidden_id" id="hidden_id" />
                    <input type="submit" name="action_button" id="action_button" class="btn btn-warning" value="Add" />

                </div>
            </form>
        </div>
    </div>
</div>
@stop

@section('scripts')

<script>
    $('#create_record').click(function(){
        $('.modal-title').text("Add New Record");
        $('#action_button').val("Add");
        $('#action').val("Add");
        $('#formModal').modal('show');
    });

    $('#sample_form').on('submit', function(event){

        event.preventDefault();
        if($('#action').val() == 'Add')
        {
            $.ajax({
                url:"{{ route('expenses.expensesName') }}",
                method:"POST",
                data: new FormData(this),
                contentType: false,
                cache:false,
                processData: false,
                dataType:"json",
                success:function(data)
                {
                    var html = '';
                    if(data.errors)
                    {
                        html = '<div class="alert alert-danger">';
                        for(var count = 0; count < data.errors.length; count++)
                        {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if(data.success)
                    {
                        html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                        $('#sample_form')[0].reset();
                        // $("#user_table").load(" #user_table");

                        $('#by_NameExpense').append('<option value = '+data.id+'>'+data.name+'</option>');


                    }
                    $('#form_result').html(html);
                }
            })
        }




    });

</script>




@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2-bootstrap4.css') !!}">



@endsection

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4',
                    width: 'style',
                    placeholder: $(this).attr('placeholder'),
                    allowClear: Boolean($(this).data('allow-clear')),
                    dir: "rtl",
                });
            });
        });

    </script>

    <script src="{!! url('assets/plugins/select2/select2.full.js') !!}"></script>

    @stack('dashboard_scripts')
@endsection





@if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Expense\Income\UpdateIncomeRequest', '#income-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Expense\Income\CreateIncomeRequest', '#income-form') !!}
    @endif
@stop
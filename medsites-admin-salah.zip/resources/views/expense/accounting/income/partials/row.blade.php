<tr>





    <td >{{  $income->id  }}  </td>
    <td >{{  number_format($income->amount)  }}  </td>
    <td >{{  $income->price_dollar  }}  </td>
    <td >{!! $income->typeId()->first()->name  !!}  </td>
    <td >{{  $income->name  }}  </td>


    <td >{{  $income->UsersId()->first()->present()->nameOrEmail  }}  </td>

    <td >{{ \Carbon\Carbon::parse($income->arrival_at)->format('D d F Y ') }}</td>
    <td >{{ \Carbon\Carbon::parse($income->created_at)->format('D d F Y ') }}</td>




    <td class="text-center align-middle">
        <a href="{{ route('order.show', $income->id) }}"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

        <a href="{{ route('order.edit', $income->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('income.delete', $income->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
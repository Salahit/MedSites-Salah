@extends('layouts.app')

@section('page-title', 'Expenses')
@section('page-heading', 'Expenses ')

@section('breadcrumbs')


    <li class="breadcrumb-item active">
        <a href="{{ route('expenses.index') }}"> Expenses </a>
    </li>   <li class="breadcrumb-item text-muted">
        Print
    </li>
@stop




@section('content')


    <section class="content" id="invoice-stmt">
        <div class="row">
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header bg-success text-white">
                        <span><i data-name="tablet" data-size="30" data-loop="true" data-c="#fff"
                                 data-hc="#fff"></i> Print  At <bold>{{ \Carbon\Carbon::now()->format(config('app.date_time_format')) }}</bold></span>


                    </div>
                    <div class="card-body"  >
                        <div class="row my-0 flex-md-row flex-column-reverse" >
                            <div class=" col-md-12 mt-md-0 mt-0">
           <img src="{{ url('assets/img/medsites-logo.png') }}" alt="logo" class="img-fluid">
                                <h5 class="mt-md-0 my-10 float-right">
                                    @if(Input::get('user') != '')


                                Print By    {{  auth()->user()->present()->nameOrEmail }}
                                        -   <b> {{  $listsEmployeesme->users_id()->first()->present()->nameOrEmail  }}</b>
                                        @else

                                        All -



                                    @endif
                                        @if(Input::get('user') == '')  {{  $listsEmployeesme->users_id()->first()->present()->nameOrEmail  }}  @endif - Cash Money {{ number_format
                                        ($listsEmployeesme->cash_money)
                                    }}

                                        <br>
                                        @if(Input::get('from') != '')

                                            {{ Input::get('from') }} To  {{ Input::get('to') }}
                                        @endif

                                </h5>

                            </div>


                        </div>

                        </div>
                        <div class="row" style="padding:15px;">
                            <div class="col-md-12 col-12 col-lg-12">
                                <div class="table-responsive-lg table-responsive-md table-responsive-sm">


                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th> ID</th>

                                            <th>نوع الشركه</th>
                                            <th> القيمة</th>
                                            <th>نوع </th>
                                            <th> أسم المصروف </th>
                                            <th> السبب</th>
                                            <th> بتاريخ</th>

                                        </tr>
                                        </thead>
                                        <tbody>
                                        @if (count($expenses))
                                            @foreach ($expenses as $expense)
                                                <tr>





                                                    <td class="align-middle">{{  $expense->id  }}  </td>

                                                    <td class="align-middle">{!! $expense->companyId()->first()->name    !!}  </td>
                                                    <td class="align-middle">{{ number_format($expense->amount)   }}  </td>
                                                    <td class="align-middle">{!! $expense->typeId()->first()->name    !!}  </td>
                                                    <td class="align-middle">{!! $expense->expenseId()->first()->name    !!}  </td>
                                                    <td class="align-middle">{!! $expense->present()->reason   !!}  </td>


                                                    <td class="align-middle">{{ \Carbon\Carbon::parse($expense->created_at)->format('D d F Y ') }}</td>


                                                </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td colspan="8"><em>@lang('app.no_records_found')</em></td>
                                            </tr>
                                        @endif
                                        </tbody>
                                        <tfoot>

                                        <th>  </th>

                                        <th> </th>
                                        <th>{{ number_format($paginateSum)}}<h2> </h2></th>
                                        <th>  </th>
                                        <th>   </th>
                                        <th>  </th>
                                        <th> </th>


                                        </tfoot>
                                    </table>





                                </div>
                            </div>
                        </div>
                        <div style="background-color: #eee;padding:15px;" id="footer-bg">

                                 <div style="margin:10px 20px;text-align:center;" class="btn-section">
                                <button type="button" class="btn btn-responsive btn_marTop button-alignment btn-info"
                                        data-toggle="button">
                                    <a style="color:#fff;" onclick="javascript:window.print();">
                                        <i class="livicon" data-name="printer" data-size="16" data-loop="true"
                                           data-c="#fff" data-hc="white" style="position:relative;top:3px;"></i>
                                        Print
                                    </a>
                                </button>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@stop
@section('after_styles')
    <link rel="stylesheet" type="text/css" href="{{ url('assets')}}/css/invoice.css" />



    @stack('dashboard_styles')



@endsection
@section('after_scripts')



    <script src="{{ url('assets')}}/js/invoice.js"></script>



    @stack('dashboard_scripts')
@endsection

@section('scripts')



@stop
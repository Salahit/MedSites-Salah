<tr>





    <td class="align-middle">{{  $expense->id  }}  </td>

    <td class="align-middle">{!! $expense->companyId()->first()->name    !!}  </td>
    <td class="align-middle">{{ number_format($expense->amount)   }}  </td>
    <td class="align-middle">{!! $expense->typeId()->first()->name    !!}  </td>
    <td class="align-middle">{!! $expense->expenseId()->first()->name    !!}  </td>
    <td class="align-middle">{!! $expense->present()->reason   !!}  </td>
    <td class="align-middle"> {!!  $expense->present()->pictureexpenses !!}</td>

    <td class="align-middle">{{ \Carbon\Carbon::parse($expense->created_at)->format('D d F Y ') }}</td>




    <td class="text-center align-middle">


            @if(\Carbon\Carbon::parse($expense->created_at)->format('m') == \Carbon\Carbon::now()->format('m') and
\Carbon\Carbon::parse($expense->created_at)->format('Y') == \Carbon\Carbon::now()->format('Y') )

        <a href="{{ route('expenses.edit', $expense->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('expenses.delete', $expense->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    @endif
    </td>
</tr>
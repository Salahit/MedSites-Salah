@extends('layouts.app')

@section('page-title', $order->invoice_id .' '.$order->ItemId()->first()->name  )
@section('page-heading',  $order->invoice_id .' '.$order->ItemId()->first()->name   )

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('order.index',$order->item_id) }}">Order</a>
    </li>
    <li class="breadcrumb-item active">
        {{  number_format($order->quantity) }}
    </li>
@stop

@section('content')

<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    @lang('app.details')

                    <small class="float-right">




                        <a href="{{ route('order.edit', $order->id) }}" class="edit"
                           data-toggle="tooltip" data-placement="top" title="@lang('app.edit_user')">
                            @lang('app.edit')
                        </a>
                    </small>
                </h5>
                <ul class="list-group list-group-flush mt-1">
                <li class="list-group-item">
                    <span class="badge badge-lg badge-{{ $order->present()->labelClassOrder}}">
            {{ trans("app.{$order->status_order}") }}
        </span>
                </li>

                    <li class="list-group-item">
                        Add By :
                        <strong> {{  $order->UsersId()->first()->present()->nameOrEmail  }} </strong>
                    </li>
                    <li class="list-group-item">
                        Price :
                        <strong>  {{ $order->price_dollar }}  $ </strong>
                    </li>


                    <li class="list-group-item">
                        Quantity :
                        <strong>   {{  number_format($order->quantity) }}  </strong> Item
                    </li>

                    <li class="list-group-item">
                        Total Price :
                        <strong>  {{  number_format($order->total_price)}}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to italy  :
                        <strong>  {{  number_format($order->total_mother_company)		 }}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to MedSites  :
                        <strong>  {{  number_format($order->total_wanted) }}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to  {{ $order->importer }} :
                        <strong>  {{  number_format($order->less_stamp_duties)	 }}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        <strong>  Rate MedSites : {{ $order->rate_company }}
                         % </strong>
                    </li>

                    <li class="list-group-item">
                      Importer:
                        <strong>  {{ $order->importer }} -  {{ $order->rate_importer}} % </strong>
                    </li>
                    <li class="list-group-item">
                        Pay Day After :</strong>
                        <strong> {{ $order->pay_day_after }}</strong>
                    </li>
                    <li class="list-group-item">
                        <strong>@lang('app.last_logged_in'):</strong>
                        {{ $order->present()->arrivalDateLogin }}
                    </li>
                    <li class="list-group-item">
                        <strong>Updated At:</strong>
                        {{ $order->updated_at->format(config('app.date_time_format')) }}
                    </li>


                </ul>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">

                        Invoice to Medsites    {{ $order->invoice_id }}

                        <span class="badge badge-lg badge-dark">
 {{  number_format($order->total_wanted) }}  $

        </span>

                            <small class="float-right">
   <a href="{{ route('order.createInvoice',$order->id) }}" class="btn btn-primary ms btn-rounded
            float-right">
                                    <i class="fas fa-plus mr-2"> </i>

                                      Invoice
                                </a>

                            </small>

                    </h5>

                @if (count($listOrderInvoice))
                <table class="table table-borderless table-striped">
                    <thead>
                    <tr>

                        <th>Amount </th>
                        <th></th>

                        <th>Arrival At</th>

                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($listOrderInvoice as $invoice)
                        @include('order.partials.rowInvoice')
                    @endforeach
                    </tbody>
                    <tfoot>
                    <tr>
                    <th>{{ number_format($sumOrderInvoice) }} $


                        <th><span class="badge badge-lg badge-info">
{{ number_format($sumRateOrderInvoice) }} %
        </span> </th>
                    </th>
                    <th>Arrival At</th>

                        <th></th> </tr> </tfoot>
                </table>
            @else
                <p class="text-muted font-weight-light"><em> no invoice for this order</em></p>
            @endif
                </div>
                </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-0 mt-0">


                                @if (count($orderActivities))

                                    List  <span class="badge badge-dark">
   {{  number_format (count($orderActivities)) }}</span> of year  <span class="badge badge-light">
   {{  \Carbon\Carbon::parse($order->arrival_at)->format('Y')}}</span> this order

                                <small class="float-right">
                                        <a href="{{ route('order.index', $order->item_id) }}" class="edit"
                                           data-toggle="tooltip" data-placement="top" title="Back">
                                            @lang('app.view_all')
                                        </a>
                                    </small>
                                @endif
                            </h4>

                            <ul class="list-inline mb-0 mt-0">

                                <li class="list-inline-item"><h6 class="text-lg-center">Quantity<br>
                                        <span class="badge badge-primary">
  Total : {{  number_format ($sumquantity) }}</span>
                                    </h6></li>


                                <li class="list-inline-item center">
     <h6 class="text-lg-center">MedSite<br>
  <span class="badge badge-primary">
  Total : {{  number_format ($sumOrdertotal_wanted) }}</span>
                                    </h6>
                                     </li>

                                <li class="list-inline-item"><h6 class="text-lg-center">Mother Company<br>
                                        <span class="badge badge-primary">
  Total : {{  number_format ($sumtotal_mother_company) }}</span>
                                    </h6></li>

                                <li class="list-inline-item"><h6 class="text-lg-center">EgyDrug<br>
                                        <span class="badge badge-primary">
  Total : {{  number_format ($sumless_stamp_duties) }}</span>
                                    </h6></li>

                            </ul>

                            @if (count($orderActivities))
                                <div class="table-responsive" id="users-table-wrapper">
                                    <table class="table table-borderless table-striped">
                                    <thead>
                                    <tr>
                                        <th class="width-80"> Invoice ID</th>
                                        <th class="width-80">To MedSites</th>
                                        <th class="width-80">Quantity</th>
                                        <th class="width-80">Arrival At</th>

                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($orderActivities as $activity)
                                        @include('order.partials.rowOrder')
                                    @endforeach


                                </table>
                            @else
                                <p class="text-muted font-weight-light"><em>@lang('app.no_activity_from_this_user_yet')</em></p>
                            @endif

                                </div>

        </div>
        </div>
    </div>


</div>
@stop

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
    </script>


    @stack('dashboard_scripts')
@endsection
@extends('layouts.app')

@section('page-title', 'Expenses')
@section('page-heading',  'Expenses')

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('expenses.index') }}"> Expenses </a>
    </li>

@stop

@section('content')

    @include('partials.messages')

    <div class="card">
        <div class="card-body">
            @include('expense.partials.search')
            <section class="content" id="invoice-stmt">
            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th> ID</th>

                        <th>نوع الشركه</th>
                        <th> القيمة</th>
                        <th>نوع </th>
                        <th> أسم المصروف </th>
                        <th> السبب</th>
                        <th> ملف </th>
                        <th> بتاريخ</th>
                        <th>@lang('app.action')</th>
                    </tr>
                    </thead>
                    <tbody>
                        @if (count($expenses))
                            @foreach ($expenses as $expense)
                                @include('expense.partials.row')
                            @endforeach
                        @else
                            <tr>
                                <td colspan="8"><em>@lang('app.no_records_found')</em></td>
                            </tr>
                        @endif
                    </tbody>
                    <tfoot>

                    <th>  </th>

                    <th> </th>
                    <th>{{ number_format($paginateSum)}}<h2> </h2></th>
                    <th>  </th>
                    <th>   </th>
                    <th>  </th>
                    <th> </th>
                    <th> <?php
                        $params = Input::get();

                        $params = http_build_query($params);
                        ?>

                        <button type="button" class="btn btn-responsive btn_marTop button-alignment btn-info" >

                            <a style="color:#fff;" href="{{ route('expenses.printExpense') }}?{{$params}}">

                                Print
                            </a>
                        </button> </th>

                    </tfoot>
                </table>


                {!! $expenses->render() !!}
            </div>
            </section>
        </div>
    </div>
@stop

@section('scripts')


    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });

        $("#month").change(function () {
            $("#users-form").submit();
        });
        $("#user").change(function () {
            $("#users-form").submit();
        });



        $("#company").change(function () {
            $("#users-form").submit();
        });

        $("#type").change(function () {
            $("#users-form").submit();
        });

        $("#name").change(function () {
            $("#users-form").submit();
        });


    </script>


@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/select2/select2-bootstrap4.css') !!}">

    <link rel="stylesheet" type="text/css" href="{{ url('assets')}}/css/invoice.css" />

@endsection

@section('after_scripts')
    <script>


        $(function () {
            $('select').each(function () {
                $(this).select2({

                    theme: 'bootstrap4 ',

                });
            });
        });

    </script>

    <script src="{!! url('assets/plugins/select2/select2.full.js') !!}"></script>
    <script src="{{ url('assets')}}/js/invoice.js"></script>
    @stack('dashboard_scripts')
@endsection





@stop
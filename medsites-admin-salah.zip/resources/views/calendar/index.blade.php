@extends('layouts.app')

@section('page-title', trans('app.activity_log'))
@section('page-heading' )

@section('breadcrumbs')

@stop

@section('content')
    <div class="card">
        <div class="card-body">

    <div id='calendar'></div>
    </div>
    </div>


    <div class="modal fade" id="formModal"  role="dialog" >
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Record</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" id="sample_form" class="form-horizontal" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <span id="form_result"></span>

                        <div class="form-group">
                            <label for="from_company">Title</label>
                            <input type="text" class="form-control" id="title"
                                   name="title" placeholder="Title" value="{{  old ('title') }}">

                        </div>

                            <div id="addText"> </div>


                        </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="hidden" name="action" id="action" />
                        <input type="hidden" name="hidden_id" id="hidden_id" />
                        <input type="submit" name="action_button" id="action_button" class="btn btn-warning" value="Add" />

                    </div>
                </form>
            </div>
        </div>
    </div>

@stop
@section('scripts')
    <script>
        $('#create_record').click(function(){
            $('.modal-title').text("Add New Record");
            $('#action_button').val("Add");
            $('#action').val("Add");
            $('#formModal').modal('show');
        });

        $('#sample_form').on('submit', function(event){

            event.preventDefault();
            if($('#action').val() == 'Add')
            {
                $.ajax({
                    url:"{{ route('calendar.expensesName') }}",
                    method:"POST",
                    data: new FormData(this),
                    contentType: false,
                    cache:false,
                    processData: false,
                    dataType:"json",
                    success:function(data)
                    {
                        var html = '';
                        if(data.errors)
                        {
                            html = '<div class="alert alert-danger">';
                            for(var count = 0; count < data.errors.length; count++)
                            {
                                html += '<p>' + data.errors[count] + '</p>';
                            }
                            html += '</div>';
                        }
                        if(data.success)
                        {
                            html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                            $('#sample_form')[0].reset();
                           //  $("#calendar").load("#calendar");



                        }
                        $('#form_result').html(html);
                       location.reload('#calendar');
                    }
                })
            }




        });

    </script>

        <script>

            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');

                var calendar = new FullCalendar.Calendar(calendarEl, {
                    plugins: [ 'interaction', 'dayGrid', 'timeGrid', 'list' ],
                    header: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
                    },
                    defaultDate: '2019-08-12',
                    editable: false,

                    selectable: true,
                    selectHelper: true,
                    eventRender: function(info) {
                        $(info.el).tooltip({
                            title: info.event.extendedProps.description,
                            placement: "top",
                            trigger: "hover",
                            container: "body"
                        });
                    },
                    dateClick: function(info) {

                        $('.modal-title').text("Add New Record");
                        $('#action_button').val("Add");
                        $('#action').val("Add");

                        $('#addText').append('<input type="hidden" name="start" value = '+info.dateStr+'>');
                        $('#formModal').modal('show');




                    },
                    navLinks: true, // can click day/week names to navigate views
                    eventLimit: true, // allow "more" link when too many events
                    events : [
                            @foreach($list as $appointment)
                        {
                            title : '{{ $appointment->title }}',
                            start : '{{ $appointment->start }}',
                            description: '{{ $appointment->title }}',
                            url: '{{url('/')}}',
                            backgroundColor: '#00000',
                            @if ($appointment->end)
                            end: '{{ $appointment->end }}',
                            @endif
                        },
                        @endforeach
                    ]


                });

                calendar.render();
            });
    </script>




@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/core/main.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/timegrid/main.css') !!}">
    <script src="{!! url('assets/js/popper.min.js') !!}"></script>
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/list/main.css') !!}">
    <link rel="stylesheet" href="{!! url('plugins/fullcalendar/packages/core/main.css') !!}">


    <style>

        /*
        i wish this required CSS was better documented :(
        https://github.com/FezVrasta/popper.js/issues/674
        derived from this CSS on this page: https://popper.js.org/tooltip-examples.html
        */
        #calendar {
            max-width: 100%;

        }

    </style>


@endsection

@section('after_scripts')


    <script src="{!! url('assets/plugins/fullcalendar/packages/moment/moment.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/core/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/interaction/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/daygrid/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/timegrid/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/list/main.js') !!}"></script>

    @stack('dashboard_scripts')
@endsection





@stop
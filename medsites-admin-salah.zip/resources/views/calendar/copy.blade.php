@extends('layouts.app')

@section('page-title', trans('app.activity_log'))
@section('page-heading' )

@section('breadcrumbs')

@stop

@section('content')

  
    <!-- Main content -->
    <section class="content pr-3 pl-3">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-12">
                <div class="box">
                    <div class="box-title">
                        <h3 class="my-2">Draggable Events</h3>
                        <div class="float-right box-toolbar">
                            <a href="#" class="btn btn-link btn-xs" data-toggle="modal" data-target="#myModal">
                                <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div class="box-body">
                        <div id='external-events'>
                            <div class='external-event palette-warning fc-event'>Team Out <i
                                        class="fa fa-times event-clear" aria-hidden="true"></i></div>
                            <div class='external-event palette-primary fc-event'>Product Seminar <i
                                        class="fa fa-times event-clear" aria-hidden="true"></i></div>
                            <div class='external-event palette-danger fc-event'>Client Meeting <i
                                        class="fa fa-times event-clear" aria-hidden="true"></i></div>
                            <div class='external-event palette-info fc-event'>Repeating Event <i
                                        class="fa fa-times event-clear" aria-hidden="true"></i></div>
                            <div class='external-event palette-success fc-event'>Anniversary Celebrations <i
                                        class="fa fa-times event-clear" aria-hidden="true"></i></div>
                            <p class="well no-border no-radius">
                                <input type='checkbox' class="custom-checkbox" id='drop-remove'
                                       style="opacity:1 !important"/>
                                <label for='drop-remove'>remove after drop</label>
                            </p>
                        </div>
                    </div>
                    <div class="box-footer">
                        <a href="#" class="btn btn-success btn-block createevent_btn" data-toggle="modal"
                           data-target="#myModal">Create event</a>
                    </div>
                </div>
                <!-- /.box -->
            </div>
            <div class="col-md-9 col-lg-9 col-12">
                <div class="box">
                    <div class="box-body">
                        <div class="container">
                            <div class="response"></div>
                            <div id='calendar'></div>
                        </div>

                        <div id="fullCalModal" class="modal fade">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span
                                                    aria-hidden="true">×</span> <span class="sr-only">close</span>
                                        </button>
                                        <h4 id="modalTitle" class="modal-title"></h4>
                                    </div>
                                    <div id="modalBody" class="modal-body">
                                        <i class="mdi-action-alarm-on"></i>&nbsp;&nbsp;Start: <span
                                                id="startTime"></span>&nbsp;&nbsp;- End: <span id="endTime"></span>
                                        <h4 id="eventInfo"></h4>
                                        <br>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-raised btn-danger" data-dismiss="modal">
                                            Close
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
             aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">
                            <i class="fa fa-plus"></i> Create Event
                        </h4>
                        <button type="button" class="close reset" data-dismiss="modal" aria-hidden="true">&times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group">
                            <input type="text" id="new-event" class="form-control" placeholder="Event">
                            <div class="input-group-btn">
                                <button type="button" id="color-chooser-btn"
                                        class="color-chooser btn btn-info dropdown-toggle" data-toggle="dropdown">
                                    Type
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu float-right" id="color-chooser">
                                    <li>
                                        <a class="palette-primary" href="#">Primary</a>
                                    </li>
                                    <li>
                                        <a class="palette-success" href="#">Success</a>
                                    </li>
                                    <li>
                                        <a class="palette-info" href="#">Info</a>
                                    </li>
                                    <li>
                                        <a class="palette-warning" href="#">warning</a>
                                    </li>
                                    <li>
                                        <a class="palette-danger" href="#">Danger</a>
                                    </li>
                                    <li>
                                        <a class="palette-default" href="#">Default</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- /btn-group -->
                        </div>
                        <!-- /input-group -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success mr-auto" id="add-new-event" data-dismiss="modal">
                            <i class="fa fa-plus"></i> Add
                        </button>
                        <button type="button" class="btn btn-danger float-right reset" data-dismiss="modal">
                            Close
                            <i class="fa fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="evt_modal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">
                            <i class="fa fa-plus"></i>
                            Edit Event
                        </h4>

                        <button type="button" class="close reset" data-dismiss="modal" aria-hidden="true">&times;
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="input-group">
                            <input type="text" id="event_title" class="form-control" placeholder="Event">
                            <div class="input-group-btn">
                                <button type="button" id="color-chooser-btn_edit"
                                        class="color-chooser btn btn-info dropdown-toggle " data-toggle="dropdown">
                                    Type
                                    <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu float-right" id="color-chooser">
                                    <li>
                                        <a class="palette-primary" href="#">Primary</a>
                                    </li>
                                    <li>
                                        <a class="palette-success" href="#">Success</a>
                                    </li>
                                    <li>
                                        <a class="palette-info" href="#">Info</a>
                                    </li>
                                    <li>
                                        <a class="palette-warning" href="#">warning</a>
                                    </li>
                                    <li>
                                        <a class="palette-danger" href="#">Danger</a>
                                    </li>
                                    <li>
                                        <a class="palette-default" href="#">Default</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- /btn-group -->
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success  mr-auto text_save" data-dismiss="modal">
                            Update
                        </button>
                        <button type="button" class="btn btn-danger float-right" data-dismiss="modal">
                            Close
                            <i class="fa fa-times"></i>
                        </button>

                    </div>
                </div>
            </div>
        </div>
    </section>

@stop
@section('scripts')
    <script src='https://unpkg.com/popper.js/dist/umd/popper.min.js'></script>
    <script src='https://unpkg.com/tooltip.js/dist/umd/tooltip.min.js'></script>

        <script>

        document.addEventListener('DOMContentLoaded', function() {
            var Calendar = FullCalendar.Calendar;
            var Draggable = FullCalendarInteraction.Draggable;

            var containerEl = document.getElementById('external-events');
            var calendarEl = document.getElementById('calendar');
            var checkbox = document.getElementById('drop-remove');

            // initialize the external events
            // -----------------------------------------------------------------

            new Draggable(containerEl, {
                itemSelector: '.fc-event',
                eventData: function(eventEl) {
                    return {
                        title: eventEl.innerText
                    };
                }
            });

            // initialize the calendar
            // -----------------------------------------------------------------

            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                plugins: [ 'interaction', 'dayGrid', 'timeGrid', 'list' ],
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
                },
                defaultDate: '2019-11-12',
                navLinks: true, // can click day/week names to navigate views
                defaultView: 'dayGridMonth',

                selectable: true,
                selectHelper: true,
                select: function (start, end, allDay) {
                    var title = prompt('Event Title:');

                    if (title) {
                        var start = $.fullCalendar.formatDate(start, "Y-MM-DD HH:mm:ss");
                        var end = $.fullCalendar.formatDate(end, "Y-MM-DD HH:mm:ss");

                        $.ajax({

                            url: SITEURL + "/calendar/create",
                            data: 'title=' + title + '&amp;start=' + start + '&amp;end=' + end,
                            type: "POST",
                            success: function (data) {
                                displayMessage("Added Successfully");
                            }
                        });
                        calendar.fullCalendar('renderEvent',
                            {
                                title: title,
                                start: start,
                                end: end,
                                allDay: allDay
                            },
                            true
                        );
                    }
                    calendar.fullCalendar('unselect');
                },


                editable: true,
                droppable: true, // this allows things to be dropped onto the calendar
                dateClick: function(info) {
                    alert('Clicked on: ' + info.dateStr);
                    alert('Coordinates: ' + info.jsEvent.pageX + ',' + info.jsEvent.pageY);
                    alert('Current view: ' + info.view.type);

                    info.dayEl.style.backgroundColor = 'red';
                },
                drop: function(info) {

                    // is the "remove after drop" checkbox checked?
                    if (checkbox.checked) {
                        // if so, remove the element from the "Draggable Events" list
                        info.draggedEl.parentNode.removeChild(info.draggedEl);

                    }
                }, eventDrop: function(info) {
                    alert(info.event.title + " was dropped on " + info.event.start.toISOString());

                    if (!confirm("Are you sure about this change?")) {
                        info.revert();
                    }
                },
                eventRender: function(info, event, element, view) {



                    if (info.event.extendedProps.status === 'done') {

                        // Change background color of row
                        info.el.style.backgroundColor = 'red';

                        // Change color of dot marker
                        var dotEl = info.el.getElementsByClassName('fc-event-dot')[0];
                        if (dotEl) {
                            dotEl.style.backgroundColor = 'white';
                        }
                    }
                    var tooltip = new Tooltip(info.el, {
                        title: info.event.extendedProps.description,
                        placement: 'top',
                        trigger: 'hover',
                        container: 'body'
                    });
                },
                eventDrop: function (event, delta) {
                    var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
                    var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
                    $.ajax({
                        url: SITEURL + '/calendar/update',
                        data: 'title=' + event.title + '&amp;start=' + start + '&amp;end=' + end + '&amp;id=' + event.id,
                        type: "POST",
                        success: function (response) {
                            displayMessage("Updated Successfully");
                        }
                    });
                },
                eventClick: function (event) {
                    var deleteMsg = confirm("Do you really want to delete?");
                    if (deleteMsg) {
                        $.ajax({
                            type: "POST",
                            url: SITEURL + '/calendar/delete',
                            data: "&amp;id=" + event.id,
                            success: function (response) {
                                if(parseInt(response) > 0) {
                                    $('#calendar').fullCalendar('removeEvents', event.id);
                                    displayMessage("Deleted Successfully");
                                }
                            }
                        });
                    }
                },
                events: [
                    {
                        title: 'Meeting Salah',
                        description: 'This is a cool scscs sv  event',
                        start: '2019-08-12T14:30:00',

                        extendedProps: {
                            status: 'done'
                        }
                    },
                    {
                        title: 'Birthday Party',
                        description: 'This is a cool scscs sv  event',
                        start: '2019-08-13T07:00:00',
                        backgroundColor: 'green',
                        borderColor: 'green'
                    },
                    {
                        groupId: 999,
                        title: 'Repeating Event',
                        start: '2019-08-09T16:00:00'
                    },
                    {
                        groupId: 999,
                        title: 'Repeating Event',
                        start: '2019-08-16T16:00:00'
                    },
                    {
                        title: 'Conference',
                        start: '2019-08-11',
                        end: '2019-08-13'
                    },
                    {
                        title: 'Meeting',
                        start: '2019-08-12T10:30:00',
                        end: '2019-08-12T12:30:00'
                    },
                    {
                        title: 'Lunch',
                        start: '2019-08-12T12:00:00'
                    },
                    {
                        title: 'Meeting',
                        start: '2019-08-12T14:30:00'
                    },
                    {
                        title: 'Happy Hour',
                        start: '2019-08-12T17:30:00'
                    },
                    {
                        title: 'Dinner',
                        start: '2019-08-12T20:00:00'
                    },
                    {
                        title: 'Birthday Party',
                        start: '2019-08-13T07:00:00'
                    },
                    {
                        title: 'Click for Google',
                        url: 'http://google.com/',
                        start: '2019-08-28'
                    }
                ]

            });


            calendar.render();
        });
        $('.modal-title').text("Edit Record");
        $('#action_edit').val("Add");
        $('#action').val("Add");

        $('#start_edit_id').val(info.event.start.toISOString());
        $('#title_edit_id').val(info.event.title);

        $('#id_edit_id').val(info.event.id);

        $('#description_edit_id:input[name=description]').val(info.event.description);



        </script>




@section('after_styles')
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/core/main.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/timegrid/main.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/list/main.css') !!}">
    <link rel="stylesheet" href="{!! url('assets/plugins/fullcalendar/packages/core/main.css') !!}">
    <link rel="stylesheet" type="text/css" href="{{ url('assets')}}/css/calendar_custom.css" />
    <style>

        /*
        i wish this required CSS was better documented :(
        https://github.com/FezVrasta/popper.js/issues/674
        derived from this CSS on this page: https://popper.js.org/tooltip-examples.html
        */
        #calendar {
            max-width: 900px;
            margin: 40px auto;
        }
        .popper,
        .tooltip {
            position: absolute;
            z-index: 9999;
            background: #FFC107;
            color: black;
            width: 150px;
            border-radius: 3px;
            box-shadow: 0 0 2px rgba(0,0,0,0.5);
            padding: 10px;
            text-align: center;
        }
        .style5 .tooltip {
            background: #1E252B;
            color: #FFFFFF;
            max-width: 200px;
            width: auto;
            font-size: .8rem;
            padding: .5em 1em;
        }
        .popper .popper__arrow,
        .tooltip .tooltip-arrow {
            width: 0;
            height: 0;
            border-style: solid;
            position: absolute;
            margin: 5px;
        }

        .tooltip .tooltip-arrow,
        .popper .popper__arrow {
            border-color: #FFC107;
        }
        .style5 .tooltip .tooltip-arrow {
            border-color: #1E252B;
        }
        .popper[x-placement^="top"],
        .tooltip[x-placement^="top"] {
            margin-bottom: 5px;
        }
        .popper[x-placement^="top"] .popper__arrow,
        .tooltip[x-placement^="top"] .tooltip-arrow {
            border-width: 5px 5px 0 5px;
            border-left-color: transparent;
            border-right-color: transparent;
            border-bottom-color: transparent;
            bottom: -5px;
            left: calc(50% - 5px);
            margin-top: 0;
            margin-bottom: 0;
        }
        .popper[x-placement^="bottom"],
        .tooltip[x-placement^="bottom"] {
            margin-top: 5px;
        }
        .tooltip[x-placement^="bottom"] .tooltip-arrow,
        .popper[x-placement^="bottom"] .popper__arrow {
            border-width: 0 5px 5px 5px;
            border-left-color: transparent;
            border-right-color: transparent;
            border-top-color: transparent;
            top: -5px;
            left: calc(50% - 5px);
            margin-top: 0;
            margin-bottom: 0;
        }
        .tooltip[x-placement^="right"],
        .popper[x-placement^="right"] {
            margin-left: 5px;
        }
        .popper[x-placement^="right"] .popper__arrow,
        .tooltip[x-placement^="right"] .tooltip-arrow {
            border-width: 5px 5px 5px 0;
            border-left-color: transparent;
            border-top-color: transparent;
            border-bottom-color: transparent;
            left: -5px;
            top: calc(50% - 5px);
            margin-left: 0;
            margin-right: 0;
        }
        .popper[x-placement^="left"],
        .tooltip[x-placement^="left"] {
            margin-right: 5px;
        }
        .popper[x-placement^="left"] .popper__arrow,
        .tooltip[x-placement^="left"] .tooltip-arrow {
            border-width: 5px 0 5px 5px;
            border-top-color: transparent;
            border-right-color: transparent;
            border-bottom-color: transparent;
            right: -5px;
            top: calc(50% - 5px);
            margin-left: 0;
            margin-right: 0;
        }

    </style>


@endsection

@section('after_scripts')


    <script src="{!! url('assets/plugins/fullcalendar/packages/moment/moment.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/core/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/interaction/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/daygrid/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/timegrid/main.js') !!}"></script>
    <script src="{!! url('assets/plugins/fullcalendar/packages/list/main.js') !!}"></script>

    @stack('dashboard_scripts')
@endsection





@stop
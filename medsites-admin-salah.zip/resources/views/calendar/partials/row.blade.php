<tr>

    <td class="align-middle">
        <a href="{{ route('user.show', $cashMoney->id) }}">
            {{ $cashMoney->id ?: trans('app.n_a') }}
        </a>
    </td>


    <td class="align-middle">{!! $cashMoney->byFromId()->first()->present()->nameOrEmail    !!}  </td>
    <td class="align-middle">{!! $cashMoney->byToId()->first()->present()->nameOrEmail    !!}  </td>
    <td class="align-middle">{{ $cashMoney->cash_money }}</td>


    <td class="align-middle">{{ $cashMoney->reason}}</td>
    <td class="align-middle">{{ \Carbon\Carbon::parse($cashMoney->created_at)->format('D d F Y ') }}</td>


    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $cashMoney->present()->labelClass }}">
            {{ trans("app.{$cashMoney->status}") }}
        </span>
    </td>

    <td class="text-center align-middle">

        <a href="{{ route('cashMoney.edit', $cashMoney->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('cashMoney.delete', $cashMoney->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
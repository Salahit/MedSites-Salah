@extends('layouts.app')

@section('page-title', 'License')
@section('page-heading', $license->user_email)

@section('breadcrumbs')
    <li class="breadcrumb-item">

        License
    </li>
    <li class="breadcrumb-item active">
        {{ $license->user_email }}
    </li>
@stop

@section('content')

<div class="row">
    <div class="col-lg-6 col-xl-5">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    @lang('app.details')

                    <small class="float-right">

                        <a href="{{ route('license.edit', $license->id) }}" class="edit"
                           data-toggle="tooltip" data-placement="top" title="@lang('app.edit_user')">
                            @lang('app.edit')
                        </a>
                    </small>
                </h5>

                <div class="d-flex align-items-center flex-column pt-3">
                    <div>

                        <span class="rounded-circle img-thumbnail img-responsive mb-4 badge badge-lg badge-{{ $license->present()->labelClassNum }}">
                        {{ trans("app.{$license->status}") }}
                        </span>
                    </div>

                    @foreach($licenseOne as $licenseOnerow)


                    {{ $licenseOnerow->product_name  }} - {{ $licenseOnerow->version_name }}
                    @endforeach
                    <a href="mailto:{{ $license->user_email }}" class="text-muted font-weight-light mb-2">
                        {{ $license->user_email }}
                    </a>
                </div>

                <ul class="list-group list-group-flush mt-3">


                    <li class="list-group-item">
                            <strong>User Email:</strong>
                            <a href="#">{{ $license->user_email }}</a>
                        </li>
                    <li class="list-group-item">
                        <strong>Activation</strong>
                       <br> {{ $license->activation }}
                    </li>
                    <li class="list-group-item">
                        <strong>Computer ID:</strong>
                        {{ $license->computer_id }}
                    </li>
                    <li class="list-group-item">
                        <strong>Status:</strong>
                        <span class="badge badge-lg badge-{{ $license->present()->labelClassNum }}">
            {{ trans("app.{$license->status}") }}
        </span>
                    </li>
                    <li class="list-group-item">
                        <strong>Support Date:</strong>
                        {{ $license->support_f }} -  {{ $license->support_e }}

                    </li>
                </ul>
            </div>
        </div>

        {!! Form::open(['route' => 'ticket.store', 'id' => 'ticket-form']) !!}




    </div>

    <div class="col-lg-6 col-xl-7">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    All License

                    @if (count($licenseActivities))
                        <small class="float-right">
                            <a href="{{ route('license.index') }}" class="edit"
                               data-toggle="tooltip" data-placement="top" title="Veiw All Licenses">
                                @lang('app.view_all')
                            </a>
                        </small>
                    @endif
                </h5>

                @if (count($licenseActivities))
                    <table class="table table-borderless table-striped">
                        <thead>
                        <tr>
                            <th>Email</th>
                            <th>@lang('app.date')</th>
                            <th> Version</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($licenseActivities as $licenseActivity)
                            <tr>

                                <td class="align-middle">
        <span class="badge badge-lg badge-{{ $licenseActivity->present()->labelClassNum }}">
            {{ trans("app.{$licenseActivity->status}") }}
        </span>
                                </td>
                                <td class="align-middle">{{ \Carbon\Carbon::parse($licenseActivity->date_created)->format
                                ('Y M') }}

                                </td>

                                <td>  {{ $licenseActivity->product_name  }} - {{ $licenseActivity->version_name }}</td>
                                <td>   <a href="{{ route('license.show', $licenseActivity->id) }}"        class="btn btn-icon"
                                          title="View License"
                                          data-toggle="tooltip" data-placement="top">
                                        <i class="fas fa-eye mr-2"></i>

                                    </a> </td>

                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                @else
                    <p class="text-muted font-weight-light"><em>@lang('app.no_activity_from_this_user_yet')</em></p>
                @endif
            </div>
        </div>
    </div>
</div>
@stop
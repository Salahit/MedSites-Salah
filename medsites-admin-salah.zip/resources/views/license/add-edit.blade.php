@extends('layouts.app')

@section('page-title', 'Add License')
@section('page-heading', $edit ? $license->id : 'Edit License')

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('license.index') }}">Licenses</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['license.update', $license->id], 'method' => 'PUT', 'id' => 'License-form']) !!}
@else
    {!! Form::open(['route' => 'license.store', 'id' => 'License-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">



            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="Email">Email</label>
                        <input type="text" name="user_email"  id="user_email" class="form-control" value="{{ $edit ? $license->user_email : old
                           ('user_email')
                            }}">
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="product_id">Product</label>
                        <select name="product_id" class="form-control" >
                            <option  value="">-- Select --</option>

                            @foreach ($products_inputs as $products_input)
 <option @if($license->product_id == $products_input->product_id) selected @endif
 value={{$products_input->product_id }}>{{ $products_input->product_name
                            }}</option>
                            @endforeach
                        </select>
                             </div>
                </div>

                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="version_id">Version</label>
                        <select name="version_id" class="form-control" >

                            <option  value="">-- Select --</option>

                            @foreach ($versions_inputs as $version_input)

  <option @if($license->version_id == $version_input->version_id) selected @endif value={{
                            $version_input->version_id }}>
      {{ $version_input->version_name}}

                            </option>
                        @endforeach
                        </select>
                    </div>
                </div>

                        <div class="col-sm-4">
                            <div class="form-group">
                                <label for="activation">Activation</label>
                                <input type="text" name="activation"  id="activation" class="form-control" value="{{ $edit ? $license->activation : old
                           ('activation')
                            }}">
                            </div>
                        </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="computer_id">Computer ID</label>
                                    <input type="text" name="computer_id"  id="computer_id" class="form-control" value="{{ $edit ? $license->computer_id : old
                           ('computer_id')
                            }}">
                                </div>
                            </div>
                      </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label for="support_f">Support Frist</label>
                    <input type="date" name="support_f"    class="form-control" value="{{ $edit ?
                    $license->support_f : old
                           ('support_f')
                            }}">
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="support_e">Support End</label>
  <input type="date" name="support_e"  class="form-control "  value="{{ $edit ?   $license->support_e : old('support_e')  }}">
                </div>

            </div>



            </div>


            </div>
        </div>


{{  Form::hidden('url',URL::previous())  }}
<div class="row">
    <div class="col-md-2">
        <button type="submit" class="btn btn-primary">
            {{ $edit ? 'Update License' : 'Create License' }}
        </button>
    </div>
</div>


{!! Form::close() !!}
@stop

@section('scripts')
    @if ($edit)

<script>
    $('#support_e').datepicker({
        orientation: 'bottom',
        startView: 'years',
        selectYears: true,
        changeYear: true,
        autoclose: false,
        changeMonth: false,
        format: {{$license->support_e}},

    });



</script>
        {!! JsValidator::formRequest('MedSites\Http\Requests\License\UpdateLicenseRequest', '#License-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\License\CreateLicenseRequest', '#License-form') !!}
    @endif
@stop
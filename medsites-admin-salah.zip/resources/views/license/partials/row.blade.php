<tr>
    <td class="text-center align-middle">
        <a href="{{ route('license.show', $license->id) }}"        class="btn btn-icon"
           title="View License"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

        <a href="{{ route('license.edit', $license->id) }}"
           class="btn btn-icon edit"
           title="Edit License"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('license.delete', $license->id) }}"
           class="btn btn-icon"
           title="Delete License"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
    <td class="align-middle">
        <a href="user?search={{ $license->user_email ?: trans('app.n_a') }}&status=">
            {{ $license->user_email ?: trans('app.n_a') }}
        </a>
    </td>
    <td class="text-center min-width-30">
        @if($license->activation == '0')
            0
        @else
            <a
               class="btn btn-icon edit"
               title="{{ $license->activation }}"
               data-toggle="tooltip" data-placement="top">
                <i class="fas fa-check-circle"></i>
            </a>
    @endif
    </td>
    <td class="align-middle">{{ $license->computer_id }}</td>
    <td class="align-middle">{{ $license->product_name  }} - {{ $license->version_name }}</td>
    <td class="align-middle">{{ \Carbon\Carbon::parse($license->date_created)->format('d/m/Y')}}</td>
    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $license->present()->labelClassNum }}">
            {{ trans("app.{$license->status}") }}
        </span>
    </td>

</tr>
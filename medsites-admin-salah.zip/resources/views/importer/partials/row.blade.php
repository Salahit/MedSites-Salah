<tr>




    <td class="align-middle">{{  $importer->users_id()->first()->present()->nameOrEmail  }}  </td>


    <td class="align-middle">{!! $importer->name    !!}  </td>

    <td class="align-middle">{!! $importer->order_count    !!}  </td>
    <td class="align-middle">{!!    $importer->items_count   !!}  </td>


    <td class="align-middle">{{ \Carbon\Carbon::parse($importer->start_at)->format('F Y') }}</td>


    <td class="text-center align-middle">
        <a href="{{ route('importer.listImporter') . '?importer=' .$importer->id   }}"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>




    </td>
</tr>
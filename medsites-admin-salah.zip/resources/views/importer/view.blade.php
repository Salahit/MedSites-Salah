@extends('layouts.app')

@section('page-title', 'Importer')
@section('page-heading',  'Importer')

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('importer.index') }}">Importers</a>
    </li>

@stop

@section('content')

    @include('partials.messages')

    <div class="card">
        <div class="card-body">
            @include('importer.partials.search')

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th> Id</th>
                        <th> Add By</th>

                        <th>importers</th>

                        <th>Item</th>
                        <th>Stock</th>
                        <th> Date</th>
                        <th>@lang('app.action')</th>
                    </tr>
                    </thead>
                    <tbody>
                    @if (count($importers))
                        @foreach ($importers as $importer)
                            @include('importer.partials.row')
                        @endforeach
                    @else
                        <tr>
                            <td colspan="10"><em>@lang('app.no_records_found')</em></td>
                        </tr>
                    @endif
                    </tbody>
                    <tfoot>

                    <th> </th>
                    <th> </th>

                    <th> </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                {!! $importers->render() !!}
            </div>
        </div>
    </div>
@stop

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
    </script>


    @stack('dashboard_scripts')
@endsection

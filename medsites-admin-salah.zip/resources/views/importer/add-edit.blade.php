@extends('layouts.app')

@section('page-title', trans('app.Importer') )
@section('page-heading', $edit ? $importer->invoice_id :  $nameItem . ' ' .  trans('app.create_new_Importer'))

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('importer.index') }}">@lang('app.Importer')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['importer.update', $importer->id], 'method' => 'PUT', 'id' => 'Importer-form']) !!}
@else
    {!! Form::open(['route' => 'importer.store', 'id' => 'Importer-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    Importers Details                </h5>
                <p class="text-muted">
                    A general Importers information.
               </p>
            </div>

            <div class="col-md-9">

@if($findItem)
                    <input type="hidden" name="item_id"   value="{{ $findItem->id}}">
@else
                    <div class="form-group">
                        <label for="importers"> Item  </label>
                        {!! Form::select('item_id', [''=>'Select'] +  $listsItem    , $edit ? $importer->item_id : '' , ['id' =>
                                     'status', 'class' => 'form-control input-solid']) !!}

                    </div>
                @endif



    <div class="form-group">
        <div class="row my-0 flex-md-row flex-column-reverse">
            <div class="col-md-3 mt-md-0 mt-0">
                <label for="by_company">By </label>
            </div>
            <div class="col-md-2 mt-md-0 mt-0">
 <span class="input-group-append">
            <button class="btn btn-light" type="button" id="create_record">

                                 <i class="fas fa-plus-circle text-muted"></i>

                                </button>
                            </span>
            </div>
        </div>

        {!! Form::select('importer_id', [''=>'Select'] +  $listsItemImporters    , $edit ? $importer->importer_id : '',
        ['id' => 'importer_id', 'class' => 'form-control input-solid']) !!}



    </div>





            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    {{ $edit ? trans('app.update_Importer') : trans('app.create_Importer') }}
</button>

</form>

<!-- Modal -->
<div class="modal fade" id="formModal"  role="dialog" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" id="sample_form" class="form-horizontal" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <span id="form_result"></span>
                    <div class="form-group">
                        <label for="from_company">New Company</label>
                        <input type="text" class="form-control" id="name"
                               name="name" placeholder="From Company" value="{{ $edit ? $filesMail->name : old
                           ('name') }}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="action" id="action" />
                    <input type="hidden" name="hidden_id" id="hidden_id" />
                    <input type="submit" name="action_button" id="action_button" class="btn btn-warning" value="Add" />

                </div>
            </form>
        </div>
    </div>
</div>

@stop

@section('scripts')
<script>


    $('#create_record').click(function(){
        $('.modal-title').text("Add New Record");
        $('#action_button').val("Add");
        $('#action').val("Add");
        $('#formModal').modal('show');
    });

    $('#sample_form').on('submit', function(event){

        event.preventDefault();
        if($('#action').val() == 'Add')
        {
            $.ajax({
                url:"{{ route('filesMail.storeCompany') }}",
                method:"POST",
                data: new FormData(this),
                contentType: false,
                cache:false,
                processData: false,
                dataType:"json",
                success:function(data)
                {
                    var html = '';
                    if(data.errors)
                    {
                        html = '<div class="alert alert-danger">';
                        for(var count = 0; count < data.errors.length; count++)
                        {
                            html += '<p>' + data.errors[count] + '</p>';
                        }
                        html += '</div>';
                    }
                    if(data.success)
                    {
                        html = '<div class="alert alert-success alert-notification"><i class="fa fa-check"></i>' + data.success + '</div>';
                        $('#sample_form')[0].reset();
                        // $("#user_table").load(" #user_table");

                        $('#by_company').append('<option value = '+data.id+'>'+data.name+'</option>');


                    }
                    $('#form_result').html(html);
                }
            })
        }




    });

</script>


    @if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Importer\UpdateImporterRequest', '#Importer-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Importer\CreateImporterRequest', '#Importer-form') !!}
    @endif
@stop
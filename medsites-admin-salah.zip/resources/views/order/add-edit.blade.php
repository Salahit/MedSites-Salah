@extends('layouts.app')

@section('page-title', trans('app.order') )
@section('page-heading', $edit ? $order->invoice_id : $ordersVal->name .' '.  trans('app.create_new_order'))

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('order.index',$ordersVal->id) }}">@lang('app.order')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['order.update', $order->id], 'method' => 'PUT', 'id' => 'order-form']) !!}
@else
    {!! Form::open(['route' => 'order.store', 'id' => 'order-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    Order Details                </h5>
                <p class="text-muted">
                    A general Order information.
               </p>


            </div>

            @if ($edit == false)
                <input type="hidden" name="item_id"   value="{{$id}}">

            @endif
            <input type="hidden" type="number" name="rate_company" value="{{$ordersVal->rate_company}}">
            <input type="hidden" type="number" name="rate_importer"  value="{{$ordersVal->rate_importer}}">
            <input type="hidden" type="number" name="price_dollar"   value="{{$ordersVal->price_dollar}}">
            <input type="hidden" type="number" name="pay_day_after"   value="{{$ordersVal->pay_day_after}}">
            <div class="col-md-9">

                @if ($edit == false)
                <div class="form-group">
                    <label for="invoice_id">Invoice Id</label>
                    <input type="text" class="form-control" id="invoice_id"
                           name="invoice_id" placeholder="Invoice Id" value="{{ $edit ? $order->invoice_id : old
                           ('invoice_id') }}">
                </div>
                @endif
                <div class="form-group">
                    <label for="importer">Importer</label>
                    {!! Form::select('importer_id',[''=>'Select'] + $listsItemImporters, $edit ? $order->importer_id
                    : '',
                    ['id' =>
                    'importer_id', 'class' =>
                    'form-control input-solid']) !!}

                </div>

                <div class="form-group">
                    <label for="price">Quantity</label>
                    <input type="text" class="form-control" id="quantity"
                           name="quantity" placeholder="Quantity" value="{{ $edit ? $order->quantity : old
                           ('quantity') }}">
                </div>


                <div class="form-group">
                    <label for="start_at">Date at </label>
                    <input type="date" class="form-control" id="start_at"
                           name="start_at"   value="{{ $edit ? $order->start_at
                            : old('start_at') }}">
                </div>

                    <div class="form-group">
                        <label for="arrival_at">Arrival at </label>
                        <input type="date" class="form-control" id="start_at"
                               name="arrival_at"   value="{{ $edit ? $order->arrival_at
                            : old('arrival_at') }}">
                    </div>
                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" id="note" class="form-control">{{ $edit ? $order->note : old('note')
                    }}</textarea>
                </div>
            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    {{ $edit ? trans('app.update_order') : trans('app.create_order') }}
</button>

</form>



@stop

@section('scripts')



    @if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Order\UpdateOrderRequest', '#order-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Order\CreateOrderRequest', '#order-form') !!}
    @endif
@stop
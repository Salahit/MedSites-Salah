@extends('layouts.app')

@section('page-title', 'Orders Invoice' )
@section('page-heading',  'Orders Invoice '    )

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('order.indexInvoiceOrders' ) }}"> Orders   </a>
    </li>

@stop

@section('content')

    @include('partials.messages')

    <div class="card">
        <div class="card-body">
            @include('order.partials.search-invoice')

            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th>Invoice ID </th>
                        <th>Amount </th>
                        <th> </th>

                        <th>Price Dollar</th>
                        <th> </th>
                        <th>Order ID</th>
                        <th>Arrival At</th>


                    </tr>
                    </thead>
                    <tbody>
                        @if (count($invoices))
                            @foreach ($invoices as  $invoice)
                                @include('order.partials.row-page-invoice')
                            @endforeach
                        @else
                            <tr>
                                <td colspan="10"><em>@lang('app.no_records_found')</em></td>
                            </tr>
                        @endif
                    </tbody>
                    <tfoot>

                    <th> </th>

                    <th>{{number_format($InvoiceOrdersSum)}} </th>


                    <th> </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                {!! $invoices->render() !!}
            </div>
        </div>
    </div>
@stop

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
        $("#item").change(function () {
            $("#users-form").submit();
        });



    </script>


    @stack('dashboard_scripts')
@endsection

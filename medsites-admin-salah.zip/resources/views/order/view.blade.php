@extends('layouts.app')

@section('page-title', $order->invoice_id .' '.$order->ItemId()->first()->name  )
@section('page-heading',  $order->invoice_id .' '.$order->ItemId()->first()->name   )

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('order.index',$order->item_id)  .'?year='.\Carbon\Carbon::parse($order->arrival_at)->format('Y')
        }}">Order</a>
    </li>
    <li class="breadcrumb-item active">
        {{  number_format($order->quantity) }}
    </li>
@stop

@section('content')
 @include('partials.messages')
<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    @lang('app.details')

                            <small class="float-right">
                                <a class="btn btn-icon float-right" href="{{ route('stock.addHistoryView',
                                $order->item_id) }}"
                                   title="Add history"
                                   data-toggle="tooltip">
                                    <i class="fa fa-plus fa-lg"></i>

                                </a>
                                <a class="btn btn-icon float-right"
                                   title="List History"
                                   data-toggle="tooltip"
                                   href="{{ route('stock.history').'?item='.$order->item_id }}" >
                                    <i class="fa fa-history fa-lg"></i>

                                </a>




                        <a href="{{ route('order.edit', $order->id) }}" class="edit float-left"
                           data-toggle="tooltip" data-placement="top" title="@lang('app.edit_user')">
                            @lang('app.edit')
                        </a>
                    </small>
                </h5>
                <ul class="list-group list-group-flush mt-1">
                <li class="list-group-item">
                    <span class="badge badge-lg badge-{{ $order->present()->labelClassOrder}}">
            {{ trans("app.{$order->status_order}") }}
        </span>
                </li><li class="list-group-item">

                    <h3><strong> {{  $order->ItemId()->first()->name  }} </strong> </h3>
                    </li>
                    <li class="list-group-item">
                        Arrival At:
                        <strong> {{   \Carbon\Carbon::parse($order->arrival_at)->format('F Y') }} </strong>
                    </li>
                    <li class="list-group-item">
                        Add By :
                        <strong> {{  $order->UsersId()->first()->present()->nameOrEmail  }} </strong>
                    </li>
                    <li class="list-group-item">
                        Price :
                        <strong>  {{ $order->price_dollar }}  $ </strong>
                    </li>


                    <li class="list-group-item">


                        Quantity :<strong>   {{ number_format($order->quantity) }}  </strong>
                        @if($order->convert_stock == 0)
                            <a href="#"
                               class="btn btn-icon float-right"
                               title="Conversion"
                               data-toggle="modal"
                               data-target="#exampleModal"


                               data-placement="top"

                               data-confirm-title="@lang('app.please_confirm')"
                               data-confirm-text="@lang('app.are_you_sure_delete_user')"
                               data-confirm-delete="@lang('app.yes_delete_him')">

                                <i class="fas fa-reply-all fa-2x"></i>
                            </a>

                        @else
                            <a tabindex="0" role="button" class="btn btn-icon"
                               data-trigger="focus"
                               data-placement="left"
                               data-html="true"
                               data-toggle="popover"
                               title="Done Conversion"
                               data-content="{!!  \Carbon\Carbon::parse($order->convert_date_at)->format(config('app.date_time_format')) !!} ">


                                <i class="fas  fa-check-circle fa-2x"></i>
                            </a>

                        @endif

                        <br>
                        <strong>  {{ $stockImporterFirst->importer()->first()->name }} -      Stock   : <strong>  {{ number_format($stockImporterFirst->total_stock ) }}  </strong>
                        </strong>

                    </li>

                    <li class="list-group-item">
                        Total Price :
                        <strong>  {{  number_format($order->total_price)}}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to {{ $order->ItemId()->first()->company  }}  :
                        <strong>  {{  number_format($order->total_mother_company) }}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to MedSites  :
                        <strong>  {{  number_format($order->total_wanted) }}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        Total to  {{ $stockImporterFirst->importer()->first()->name }}  :
                        <strong>  {{  number_format($order->less_stamp_duties)	 }}  $ </strong>
                    </li>
                    <li class="list-group-item">
                        <strong>  Rate MedSites : {{ $order->rate_company }}
                         % </strong>
                    </li>

                    <li class="list-group-item">
                      Importer:
                        <strong>  {{ $stockImporterFirst->importer()->first()->name }} -  {{ $order->rate_importer}} %
                        </strong>
                        <br>
                    Stock   : <strong>  {{ number_format($stockImporterFirst->total_stock ) }}  </strong>
                    </li>
                    <li class="list-group-item">
                        Pay Day After :</strong>
                        <strong> {{ $order->pay_day_after }}</strong>
                    </li>
                    <li class="list-group-item">
                        <strong>Order Time:</strong>
                        {{ $order->present()->arrivalDateLogin }}
                    </li>
                    <li class="list-group-item">
                        <strong>Updated At:</strong>
                        {{ $order->updated_at->format(config('app.date_time_format')) }}
                    </li>


                </ul>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
                <div class="card">
                <div class="card-body">
                    <h5 class="card-title">

                        Invoice to Medsites    {{ $order->invoice_id }}

                        <span class="badge badge-lg badge-dark">
 {{  number_format($order->total_wanted) }}  $

        </span>

                            <small class="float-right">
   <a href="{{ route('order.createInvoice',$order->id) }}" class="btn btn-primary ms btn-rounded
            float-right">
                                    <i class="fas fa-plus mr-2"> </i>

                                      Invoice
                                </a>

                            </small>

                    </h5>

                @if (count($listOrderInvoice))
                <table class="table table-borderless table-striped">
                    <thead>
                    <tr>

                        <th>Amount </th>
                        <th></th>
                        <th>Price Dollar</th>
                        <th>Arrival At</th>

                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($listOrderInvoice as $invoice)
                        @include('order.partials.rowInvoice')
                    @endforeach
                    </tbody>
                    <tfoot>
                    <tr>
                    <th>{{ number_format($sumOrderInvoice) }} $


                        <th><span class="badge badge-lg badge-info">
{{ number_format($sumRateOrderInvoice) }} %
        </span> </th>
                    <th>Price Dollar</th>

                    <th>Arrival At</th>

                        <th></th> </tr> </tfoot>
                </table>
            @else
                <p class="text-muted font-weight-light"><em> no invoice for this order</em></p>
            @endif
                </div>
                </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-0 mt-0">


                                @if (count($orderActivities))

                                    List  <span class="badge badge-dark">
   {{  number_format (count($orderActivities)) }}</span> of year  <span class="badge badge-light">
   {{  \Carbon\Carbon::parse($order->arrival_at)->format('Y')}}</span> this order

                                <small class="float-right">
                                        <a href="{{ route('order.index', $order->item_id) }}" class="edit"
                                           data-toggle="tooltip" data-placement="top" title="Back">
                                            @lang('app.view_all')
                                        </a>
                                    </small>
                                @endif
                            </h4>

                            <ul class="list-inline mb-0 mt-0">

                                <li class="list-inline-item"><h6 class="text-lg-center">Quantity<br>
                                        <span class="badge badge-primary">
  Total : {{  number_format ($sumquantity) }}</span>
                                    </h6></li>


                                <li class="list-inline-item center">
     <h6 class="text-lg-center">MedSite<br>
  <span class="badge badge-primary">
  Total : {{  number_format ($sumOrdertotal_wanted) }}</span>
                                    </h6>
                                     </li>

                                <li class="list-inline-item"><h6 class="text-lg-center">Mother Company<br>
                                        <span class="badge badge-primary">
  Total : {{  number_format ($sumtotal_mother_company) }}</span>
                                    </h6></li>

                                <li class="list-inline-item"><h6 class="text-lg-center">Importer<br>
                                        <span class="badge badge-primary">
  Total : {{  number_format ($sumless_stamp_duties) }}</span>
                                    </h6></li>

                            </ul>

                            @if (count($orderActivities))
                                <div class="table-responsive" id="users-table-wrapper">
                                    <table class="table table-borderless table-striped">
                                    <thead>
                                    <tr>
                                        <th class="width-80"> Invoice ID</th>
                                        <th class="width-80">To MedSites</th>
                                        <th class="width-80">Importer</th>
                                        <th class="width-80">Quantity</th>
                                        <th class="width-80">Invoice </th>

                                        <th class="width-80">Arrival At</th>

                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($orderActivities as $activity)
                                        @include('order.partials.rowOrder')
                                    @endforeach


                                </table>
                            @else
                                <p class="text-muted font-weight-light"><em>@lang('app.no_activity_from_this_user_yet')</em></p>
                            @endif

                                </div>

        </div>
        </div>
    </div>


</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Would you like to convert {{ number_format
                ($order->quantity) }} to stock</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Stock {{ $stockImporterFirst->importer()->first()->name }} :<strong>   {{ number_format($stockImporterFirst->total_stock) }}  </strong>
            </div>
            <div class="modal-footer">
                {!! Form::open(['route' => ['updateStockFromOrder.updateStockFromOrder'], 'method' =>
                      'POST', 'id' => 'FromOrder1-form']) !!}


                <input type="hidden" value="{{ $order->id  }}" name="order_id" >
                <input type="hidden" value="{{ $order->item_id  }}" name="item_id" >
                <input type="hidden" value="{{ $order->importer_id  }}" name="importer_id" >
                <input type="hidden" value="{{ $order->quantity  }}" name="quantity" >
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
@stop

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
        $("#FromOrder-form").click(function () {
            $("#FromOrder-form").submit();
        });


    </script>


    @stack('dashboard_scripts')
@endsection
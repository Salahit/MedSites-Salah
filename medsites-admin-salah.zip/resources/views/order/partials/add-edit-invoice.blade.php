@extends('layouts.app')

@section('page-title', 'Invoice')
@section('page-heading', $edit ? $order->invoice_id : $order->invoice_id .' '.  trans('app.create_new_order'))

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('order.index',$order->item_id) }}">@lang('app.order')</a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')

@if ($edit)
    {!! Form::open(['route' => ['order.update', $order->id], 'method' => 'PUT', 'id' => 'order-form']) !!}
@else
    {!! Form::open(['route' => 'order.storeInvoice', 'id' => 'order-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    Invoice  Details
                </h5>
                <p class="text-muted">
                    A general Order information.
               </p>
            </div>

            @if ($edit == false)
                <input type="hidden" name="order_id"   value="{{$id}}">
                <input type="hidden" name="item_id"   value="{{ $order->item_id}}">
                <input type="hidden" name="total_wanted"   value="{{$order->total_wanted}}">

            @endif
            <div class="col-md-8">
                <div class="form-group">
                    <label for="invoice_id">Invoice ID</label>
                    <input type="text" class="form-control" id="invoice_id"
                           name="invoice_id" placeholder="Invoice ID" value="{{ $edit ? $order->invoice_id : old
                           ('invoice_id') }}">
                </div>

                <div class="form-group">
                    <label for="invoice_total">Amount collected</label>
                    <input type="text" class="form-control" id="invoice_total"
                           name="invoice_total" placeholder="Amount collected" value="{{ $edit ? $order->invoice_total : old
                           ('invoice_total') }}">
                </div>


                <div class="form-group">
                    <label for="arrival_at">Arrival at </label>
                    <input type="date" class="form-control" id="start_at"
                           name="arrival_at"   value="{{ $edit ? $order->arrival_at
                            : old('arrival_at') }}">
                </div>


                <div class="form-group">
                    <label for="note">Note</label>
                    <textarea name="note" id="note" class="form-control">{{ $edit ? $order->note : old('note')
                    }}</textarea>
                </div>
            </div>
        </div>
    </div>
</div>

<button type="submit" class="btn btn-primary">
    {{ $edit ? trans('app.update') : trans('app.create') }}
</button>
{{  Form::hidden('url',URL::previous())  }}
</form>



@stop

@section('scripts')



    @if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Order\UpdateOrderInvoiceRequest', '#order-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Order\CreateOrderInvoiceRequest', '#order-form') !!}
    @endif
@stop
<tr>
    <td>{{ $invoice->invoice_id  }} </td>
    <td>{{  number_format($invoice->invoice_total) }} $ </td>

    <td>  <span class="badge badge-lg badge-info">
{{ number_format($invoice->rate_invoice) }} %

        </span>
    </td>


    <td>{{  number_format($invoice->price_dollar) }} L.E </td>
    <td>{{ $invoice->ItemId()->first()->name  }} </td>
    <td>{{ $invoice->OrderId()->first()->invoice_id  }} </td>



    <td>
        {{ \Carbon\Carbon::parse($invoice->arrival_at)->format('Y F  d D') }}

    </td>

    <td class="text-center align-middle">

        <a href="{{ route('order.show', $invoice->order_id)   }}"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

    </td>
</tr>

<tr>

    <td class="align-middle">
        <a href="{{ route('order.show', $order->id) }}">
            {{ $order->invoice_id ?: trans('app.n_a') }}
        </a>
    </td>


    <td  >{{  number_format($order->quantity)  }}@if($order->convert_stock == 1)
            <a href=""
               class="btn btn-icon float-left mt-md-0 mt-0"
               title="Done Conversion "
               data-toggle="tooltip">
                <i class="fas fa-check-circle"></i>
            </a>




        @endif
    </td>

    <td class="align-middle">{!! $order->importer()->first()->name    !!}  </td>

    <td class="align-middle">{!! number_format($order->total_mother_company)	  !!} $  </td>
    <td class="align-middle">{!! number_format($order->total_wanted)	  !!} $  </td>
    <td class="align-middle">{!! number_format($order->less_stamp_duties)	  !!} $  </td>
    <td class="align-middle">{!! number_format($order->rate_dollar)	  !!} L.E  </td>



    <td class="align-middle">{{ \Carbon\Carbon::parse($order->arrival_at)->format('F Y') }}</td>

    <td>{{ $order->invoice_count }} - {{ number_format($order->balance)}}</td>
    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $order->present()->labelClassOrder}}">
            {{ trans("app.{$order->status_order}") }}
        </span>
    </td>

    <td class="text-center align-middle">
        <a href="{{ route('order.show', $order->id) .'?year='.\Carbon\Carbon::now()->format('Y') }}"

           class="btn btn-icon eye"
           title="View Item"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye mr-2"></i>

        </a>

        <a href="{{ route('order.edit', $order->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('order.delete', $order->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
@extends('layouts.app')

@section('page-title', 'Orders For ' .  $rowOne->name )
@section('page-heading',  'Orders For ' .  $rowOne->name   )

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('order.index',$id) }}"> Orders   </a>
    </li>

@stop

@section('content')

    @include('partials.messages')

    <div class="card">
        <div class="card-body">
            @include('order.partials.search')
 <h5 class="mt-md-0 mt-0 my-0">{{ $rowOne->name}}    <span class="badge badge-lg badge-light">
            {{ count($orders) }}
        </span>  </h5>
            <div class="table-responsive" id="users-table-wrapper">
                <table class="table table-striped table-borderless">
                    <thead>
                    <tr>
                        <th>Invoice Id</th>

                        <th>QYT </th>
                        <th>Importer </th>

                        <th>V-T-M</th>
                        <th>V-T-MS</th>
                        <th>V-T-EGY</th>
                        <th> </th>
                        <th> Arrival Date</th>
                        <th>  No.</th>
                        <th> Stauts</th>
                        <th>@lang('app.action')</th>
                    </tr>
                    </thead>
                    <tbody>
                        @if (count($orders))
                            @foreach ($orders as $order)
                                @include('order.partials.row')
                            @endforeach
                        @else
                            <tr>
                                <td colspan="10"><em>@lang('app.no_records_found')</em></td>
                            </tr>
                        @endif
                    </tbody>
                    <tfoot>

                    <th> </th>
                    <th>{{ number_format($sumquantity) }}  </th>
                    <th> </th>

                    <th>{{ number_format($sumtotal_mother_company) }} </th>
                    <th>{{ number_format($sumOrdertotal_wanted) }} </th>
                    <th>{{ number_format($sumless_stamp_duties) }} </th>
                    <th> </th>
                    <th> </th>
                    <th> </th>

                    </tfoot>
                </table>


                {!! $orders->render() !!}
            </div>
        </div>
    </div>
@stop

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });    $("#importer").change(function () {
            $("#users-form").submit();
        });


    </script>


    @stack('dashboard_scripts')
@endsection

<tr>

    <td class="align-middle">

            {{ $message->productss->first()->product_name   }}

    </td>
    <td class="align-middle"> <span class="mb-0 badge badge-lg
    badge-light"> <a href="{{ route('message.show', $message->id) }}">{{ $message->title }}</a></span></td>


    <td class="align-middle">  <a href="{{ route('user.show', $message->user_id) }}">{{ $message->users->first()
    ->present()->nameOrEmail    }}</a></td>

    <td class="align-middle">

 <span class="rounded-circle img-thumbnail img-responsive mb-0 badge badge-lg badge-info">
{{  $message->messages_count }}
       </span>
    </td>
    <td class="align-middle">

 <span class="rounded-circle img-thumbnail img-responsive mb-0 badge badge-lg badge-light">
{{  $message->approved_messages_count }}
       </span>
    </td>
    <td class="align-middle">
        {{ $message->created_at->format(config('app.date_time_format')) . ' - ' . $message->created_at->diffForHumans()}}
    </td>



    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $message->present()->labelClass }}">
            {{ trans("app.{$message->status}") }}
        </span>
    </td>

    <td class="text-center align-middle">


        <a tabindex="0" role="button" class="btn btn-icon"
           data-trigger="focus"
           data-placement="left"
           data-html="true"
           data-toggle="popover"
           title="Message"
           data-content="{!! nl2br($message->message)  !!} ">
            <i class="fas fa-info-circle"></i>
        </a>

        <a href="{{ route('message.show', $message->id )}}" class="btn btn-icon edit">
            <i class="fas fa-eye  "></i>

        </a>





        <a href="{{ route('message.delete', $message->id) }}"
           class="btn btn-icon"
           title="@lang('app.delete_user')"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
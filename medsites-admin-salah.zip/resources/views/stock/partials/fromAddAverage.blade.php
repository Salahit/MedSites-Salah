{!! Form::open(['route' => 'stock.storeAverage', 'id' => 'Average-form'] )  !!}

<input type="hidden" value="{{ $stock->id  }}" name="item_id" >
<input type="hidden" value="{{ Input::get('year') }}" name="years" >




<div class="row my-3 flex-md-row flex-column-reverse">
    <div class="col-md-12 mt-md-0 mt-2">
        <div class="input-group custom-search-form">
            <input type="text"
                   class="form-control input-solid"
                   name="average"
                   value="{{ Input::get('average') }}"
                   placeholder="Target">

            <span class="input-group-append">
            <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-save text-muted"></i>
                                </button>
                            </span>
        </div>
    </div>


</div>



{!! Form::close() !!}



{!! Form::open(['route' => 'stock.storeStock', 'id' => 'Stock-form']) !!}

<div class="row my-3 flex-md-row flex-column-reverse">
    <input type="hidden" value="{{ $stock->id  }}" name="item_id" >


    <div class="col-md-12 mt-md-2 mt-2"">
        {!! Form::select('importer_id', $listsItemImporters, Input::get('importer_id'), ['id' => 'importer_id', 'class' =>
        'form-control input-solid']) !!}
    </div>


    <div class="col-md-12 mt-md-2 mt-2">
        <div class="input-group custom-search-form">

            <input type="date"
                   class="form-control input-solid"
                   name="start_at"

                   value="{{ \Carbon\Carbon::parse(now())->format('Y-m-d') }}" >


        </div>
    </div>



    <div class="col-md-12 mt-md-2 mt-2">
        <div class="input-group custom-search-form">
       <input type="text"
                   class="form-control input-solid"
                   name="total_month"
                   value="{{ old('total_month')  }}"


                   placeholder="Total Month	">

            <span class="input-group-append">
            <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-save text-muted"></i>
                                </button>
        </div>
    </div>

</div>
{!! Form::close() !!}

@section('scripts')




    {!! JsValidator::formRequest('MedSites\Http\Requests\Stock\CreateStoreStockRequest', '#Stock-form') !!}



@stop

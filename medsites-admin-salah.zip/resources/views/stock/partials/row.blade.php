<tr>

    <td class="align-middle">
        <a href="{{ route('stock.show', $stock->id) }}">
            {{ $stock->name ?: trans('app.n_a') }}
        </a>
    </td>
    <td class="align-middle">{{ $stock->company }}</td>
    <td class="align-middle">{{ $stock->importer_count }}</td>
    <td class="align-middle">{{ $stock->price }}</td>
    <td class="align-middle">{{ $stock->price_dollar }}</td>


    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $stock->present()->labelClass }}">
            {{ trans("app.{$stock->status}") }}
        </span>
    </td>
    <td class="text-center align-middle">
        <a href="{{ route('order.index', $stock->id).'?year='.\Carbon\Carbon::now()->format('Y')  }}"

           class="btn btn-icon eye"
           title="View Order "
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-dollar-sign  fa-2x"></i>

        </a>
 <a href="{{ route('stock.show', $stock->id) .'?year='.\Carbon\Carbon::now()->format('Y') }}"

           class="btn btn-icon eye"
           title="View Sales"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-eye  fa-2x mr-2"></i>

        </a>

        <a href="{{ route('stock.edit', $stock->id)  }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>


    </td>
</tr>
<div class="dropdown show d-inline-block float-right">
    <a class="btn btn-icon float-right"
       href="#" role="right" id="dropdownMenuLink"
       data-toggle="dropdown"
       aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-edit"></i>
    </a>

    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">


            {!! Form::open(['route' => ['stock.updateAverage', $yearAverage->id], 'method' => 'PUT', 'id' => 'Average-form']) !!}

        <div class="row  flex-md-row flex-column-reverse">
            <input type="hidden" value="{{ $stock->id  }}" name="item_id" >

            <div class="col-md-12">
                <div class="input-group custom-search-form">
                    <input type="text"
                           class="form-control input-solid"
                           name="average"
                           value="{{ $yearAverage->average  }}"
                           placeholder="Target">

                    <span class="input-group-append">
            <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-save text-muted"></i>
                                </button>
                </div>
            </div>

        </div>
            {!! Form::close() !!}
        </div>
    </div>
@section('afrter_scripts')




    <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
    @stack('dashboard_scripts')
@endsection

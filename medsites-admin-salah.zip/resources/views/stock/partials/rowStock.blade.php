<tr>

    <td class="align-middle">{{ \Carbon\Carbon::parse($stockRow->start_at)->format('m') }}




    </td>
    <td class="align-middle">{{  number_format($stockRow->total_month)  }}</td>
    <td class="align-middle">{{  number_format($stockRow->stock)  }}</td>

    <?php




 if($yearAverage){
     $avg = $yearAverage->average  / 12 ;
  $percent_members = round(( $stockRow->total_month / $avg) * 100);
 }else {
     $percent_members = 0 ;
 }

    ?>
    <td class="align-middle">{{  $percent_members   }}  % </td>



    <td class="align-middle">{{ $stockRow->importer()->first()->name   }}   </td>



    <td class="align-middle">{{ \Carbon\Carbon::parse($stockRow->start_at)->format('F Y') }}</td>
    <td class="align-middle">{{  $stockRow->users_id()->first()->present()->nameOrEmail  }}  </td>


    <td class="text-center align-middle" >
        <div class="dropdown show d-inline-block">
            <a class="btn btn-icon"
               href="#" role="button" id="dropdownMenuLink"
               data-toggle="dropdown"
               aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-edit"></i>
            </a>

            <div class="dropdown-menu dropdown-menu-left  " aria-labelledby="dropdownMenuLink" style="width:
            500px" >


                {!! Form::open(['route' => ['stock.editStock', $stockRow->id], 'method' => 'PUT', 'id' =>
                   'stockEdit-form']) !!}
                <input type="hidden" value="{{ $stock->id }}" name="item_id" >
                <input type="hidden" value="{{ $stockRow->importer_id}}" name="importer_id" >
                <div class="col-md-12 mt-md-0 mt-1">
                    <div class="row my-1 flex-md-row flex-column-reverse">
                        <div class="col-md-6 mt-md-0 mt-1">


                                Sales <input type="text" class="form-control input-solid" id="total_month"
                                             name="total_month" placeholder="Total month "
                                             value="{{ $stockRow->total_month  }}">

                        </div>




                        <div class="col-md-6 mt-3 mt-md-1">
                            Stock <input type="text" class="form-control input-solid"  id="total_month"
                                         name="stock" placeholder="Total Stock "
                                         value="{{ $stockRow->stock  }}">

                        </div>
                        <div class="col-md-6 mt-3 mt-md-1">
                            <input type="date" name="start_at"  id="start_at" class="form-control input-solid"  value="{{ $stockRow->start_at}}">


                        </div>

                        <div class="col-md-6 mt-3 mt-md-1">
                            <button type="submit" class="btn btn-primary">
                                Save
                            </button>
                        </div>
                    </div>





                {!! Form::close() !!}
                </div>
            </div>
        </div>




    </td>
</tr>
{!! Form::open(['route' => 'stock.sendEmailStock', 'id' => 'Average-form']) !!}
<input type="hidden" value="{{$stock->id}}" name="item_id" >
@if($getLastMonthValue)
<input type="hidden" value="{{ number_format($getLastMonthValue->total_month)}} " name="monthVal" >
<input type="hidden" value="{{ \Carbon\Carbon::parse($getLastMonthValue->start_at)->format('F Y') }} "
       name="month_date" >
@endif
@if (count($lastMonth))



<textarea name="sales" id="note" class="form-control" style="display: none;" >

     <h1> {{ $stock->name }} </h1>

    <strong>Sales Month :  </strong> <br>
  @foreach ($lastMonth as $Month){{ \Carbon\Carbon::parse
($Month->start_at)->format('Y F') }}
{{ $Month->Importer()->first()->name }} :<strong> {{ number_format($Month->total_month)}}</strong><br>
@endforeach

    @if (count($stockImporter))
  <strong>Stock  </strong> <br>
 @foreach ($stockImporter as $Importer)
            @if($Importer->status == 'Active')
  {{ $Importer->Importer()->first()->name }} : <strong> {{number_format($Importer->total_stock)}}</strong><br>
            @endif
        @endforeach



 <strong>Sales </strong> <br>
 @foreach ($stockImporter as $Importer)
            @if($Importer->status == 'Active')
{{ $Importer->Importer()->first()->name }} : <strong> {{number_format($Importer->balance)}}</strong><br>
            @endif
@endforeach

    @endif
<br>
  Total Year :     <strong> {{ number_format($sumByYear) }}</strong> <br>
  Total Sales : <strong> {{ number_format($countOfStockAllYear)}}</strong><br>


    @if($yearAverage)
        <br>
      Average of {{$yearAverage->years}} <strong>{{ number_format($yearAverage->average)}}</strong>
        <br>
   Average of Month <strong> {{ number_format($yearAverage->average / 12 ) }}</strong>
   @else
        No Average
    @endif


</textarea>



<input type="hidden" value="{{ $stock->name  }}" name="name" >
<button type="submit" class="btn btn-icon "><i class="fas fa-envelope fa-lg"></i></button>





@endif

{!! Form::close() !!}

@extends('layouts.app')

@section('page-title', 'History')
@section('page-heading', 'History')

@section('breadcrumbs')
    <li class="breadcrumb-item active">
        History
    </li>
@stop

@section('content')

@include('partials.messages')

<div class="card">
    <div class="card-body">

        <form action="" method="GET" id="users-form" class="pb-2 mb-3 border-bottom-light">
            <div class="row my-3 flex-md-row flex-column-reverse">
                <div class="col-md-4 mt-md-0 mt-2">
                    <div class="input-group custom-search-form">
                        <input type="text"
                               class="form-control input-solid"
                               name="search"
                               value="{{ Input::get('search') }}"
                               placeholder="Search for History
">

                        <span class="input-group-append">
                                @if (Input::has('search') && Input::get('search') != '')
                                <a href="{{ route('stock.history') }}"
                                   class="btn btn-light d-flex align-items-center text-muted"
                                   role="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                            @endif
                            <button class="btn btn-light" type="submit" id="search-users-btn">
                                    <i class="fas fa-search text-muted"></i>
                                </button>
                            </span>
                    </div>



                </div>


                <div class="col-md-2 mt-2 mt-md-0">
{!! Form::select('item', [''=>'Select'] +  $listsItem    , Input::get('item'), ['id' =>
                     'status', 'class' => 'form-control input-solid']) !!}

                </div>

                <div class="col-md-2 mt-2 mt-md-0">
                    {!! Form::select('type', [''=>'Select','Sales'=>'Sales','Order'=>'Order']      ,  Input::get
                    ('type'),
                     ['id' => 'type', 'class' => 'form-control input-solid']) !!}
                </div>


                <div class="col-md-3">
                    <a href="{{ route('stock.index') }}" class="btn btn-primary btn-rounded float-right">
                        <i class="fas fa-plus mr-2"></i>
                      Stoke
                    </a>
                </div>
            </div>
        </form>
        <div class="table-responsive" id="users-table-wrapper">
            <table class="table table-borderless table-striped">
                <thead>
                <tr>

                    <th >Item</th>
                    <th >Add by</th>
                    <th>Type</th>
                    <th>Title</th>
                    <th class="min-width-80">@lang('app.status')</th>
                    <th class="text-center min-width-150">@lang('app.action')</th>
                </tr>
                </thead>
                <tbody>
                    @if (count($History))
                        @foreach ($History as $history)
                            @include('stock.history.row')
                        @endforeach
                    @else
                        <tr>
                            <td colspan="7"><em>@lang('app.no_records_found')</em></td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>


{!! $History->render() !!}

@stop

@section('scripts')
    <script>
        $("#status").change(function () {
            $("#users-form").submit();
        });
        $("#type").change(function () {
            $("#users-form").submit();
        });

    </script>
@stop

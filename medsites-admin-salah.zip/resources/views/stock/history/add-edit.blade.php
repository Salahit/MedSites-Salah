@extends('layouts.app')

@section('page-title', 'History')
@section('page-heading', $edit ? $stock->title : 'Add History')

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('stock.index') }}">Item Stock </a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')





@if ($edit)
    {!! Form::open(['route' => ['stock.updateHistory', $stock->id], 'method' => 'PUT', 'id' => 'stock-form']) !!}
@else
    {!! Form::open(['route' => 'stock.storeHistory', 'id' => 'stock-form']) !!}
@endif



<input type="hidden" value="{{$itemId}}" name="item_id" >

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <h5 class="card-title">
                    History
                </h5>
                <p class="text-muted">
                    A general   History.
                </p>
            </div>
            <div class="col-md-9">

                <div class="form-group">
                    <label for="name"> Type	</label>
                    {!! Form::select('type_id', [''=>'Select','Sales'=>'Sales','Order'=>'Order']      , $edit ?
                     $stock->type_id : '',
                     ['id' => 'type_id', 'class' => 'form-control  float-right']) !!}

                </div>

                <div class="form-group">
                    <label for="name"> Title	</label>
                    <input type="text" class="form-control" id="title"
                           name="title" placeholder="Title"
                           value="{{ $edit ? $stock->title : old('title') }}">
                </div>

                <div class="form-group">
                    <label for="name"> Date	</label>


                    <input type="date"   name="start_at"  id="start_at"  class="form-control"
                           value="{{$edit ?
                    $stock->start_at : old('start_at')  }}">
                </div>





                <div class="form-group">
                    <label for="editor">Note</label>
                    <textarea name="note" id="note" rows="5" class="form-control">{{ $edit ?
                    $stock->note : old('note') }}</textarea>
                </div>



            </div>
        </div>

   </div>
        </div>


<div class="row">
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">
            {{ $edit ? 'Update History' : 'Save History' }}
        </button>
    </div>
</div>

@stop
@section('after_styles')

    @stack('dashboard_styles')

<style>.pand{padding-top: 35px;} </style>

@endsection
@section('after_scripts')


    @stack('dashboard_scripts')
@endsection

@section('scripts')

    @if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Stock\CreateStockHistoryRequest', '#stock-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Stock\CreateStockHistoryRequest', '#stock-form') !!}
    @endif


@stop


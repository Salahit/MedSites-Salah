<tr>
    <td class="align-middle">{!! $history->items_id()->first()->name  !!}  </td>
    <td class="align-middle">
        <a href="{{ route('user.show', $history->id) }}">
            {{ $history->users_id()->first()->present()->nameOrEmail  }}
        </a>
    </td>


    <td class="align-middle">{{ $history->type_id }}</td>

    <td class="align-middle">{{ $history->title }}</td>
    <td class="align-middle">{{ \Carbon\Carbon::parse($history->start_at)->format('d F Y ') }}</td>

    <td class="align-middle">
        <span class="badge badge-lg badge-{{ $history->present()->labelClass }}">
            {{ trans("app.{$history->status}") }}
        </span>
    </td>
    <td class="text-center align-middle">

                <a href="{{ route('stock.show', $history->item_id) }}"

                   class="btn btn-icon eye"
                   title="View"
                   data-toggle="tooltip" data-placement="top">
                    <i class="fas fa-eye"></i>
                </a>



        <a href="{{ route('stock.editHistory', $history->id) }}"
           class="btn btn-icon edit"
           title="Edit"
           data-toggle="tooltip" data-placement="top">
            <i class="fas fa-edit"></i>
        </a>

        <a href="{{ route('stock.deleteHistory', $history->id) }}"
           class="btn btn-icon"
           title="Delete"
           data-toggle="tooltip"
           data-placement="top"
           data-method="DELETE"
           data-confirm-title="@lang('app.please_confirm')"
           data-confirm-text="@lang('app.are_you_sure_delete_user')"
           data-confirm-delete="@lang('app.yes_delete_him')">
            <i class="fas fa-trash"></i>
        </a>
        <a tabindex="0" role="button" class="btn btn-icon"
           data-trigger="focus"
           data-placement="left"
           data-toggle="popover"
           data-toggle="tooltip"
           title="Note"
           data-content="{!!  $history->note !!}">
            <i class="fas fa-info-circle"></i>
        </a>
    </td>
</tr>
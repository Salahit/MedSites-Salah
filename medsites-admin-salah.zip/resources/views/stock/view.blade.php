@extends('layouts.app')

@section('page-title', 'Sales')
@section('page-heading', $stock->name)

@section('breadcrumbs')
    <li class="breadcrumb-item">

        <a href="{{ route('stock.index') }}"> Items </a>
    </li>
    <li class="breadcrumb-item active">
        {{ $stock->name }}
    </li>
@stop

@section('content')

    @include('partials.messages')



    <div class="row">

        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">

                    <h5 class="card-title">
                        @lang('app.details') Item

                        <small class="float-right">
                            <a class="btn btn-icon float-left" href="{{ route('stock.addHistoryView',$stock->id) }}"
                               title="Add history"
                               data-toggle="tooltip">
                                <i class="fa fa-plus fa-lg"></i>

                            </a>
                            <a class="btn btn-icon float-right"
                               title="List History"
                               data-toggle="tooltip"
                               href="{{ route('stock.history').'?item='.$stock->id }}">
                                <i class="fa fa-history fa-lg"></i>

                            </a>

                        </small>
                    </h5>
                    <ul class="list-group list-group-flush mt-3">
                        <li class="list-group-item">

                            <strong> {{ $stock->name }}</strong>
                        </li>
                        <li class="list-group-item">
                            @if($getLastMonthValue)

                                Last Month Row:




                                <strong>   {{  number_format($getLastMonthValue->total_month)  }} </strong> {{
                         \Carbon\Carbon::parse($getLastMonthValue->start_at)->format('F Y') }} <br>

                                Last Month All:




                                <strong>  {{  number_format($lastMonthSum)  }} </strong>         {{
                             \Carbon\Carbon::parse($getLastMonthValue->start_at)->format('F Y') }} <br>
                            @endif
                        </li>
                        <li class="list-group-item">
                            @if($lastMonth)
                                @if (count($lastMonth))
                                    @foreach ($lastMonth as $Month)

                                        @if($Month->status == 'Active')
                                            <h6>  {{ $Month->Importer()->first()->name }} : <strong> {{
                          number_format($Month->total_month)
                              }}</strong> {{ \Carbon\Carbon::parse($Month->start_at)->format('F Y') }}
                                            </h6>

                                        @endif
                                    @endforeach
                                @endif
                            @endif
                        </li>

                        <li class="list-group-item">

                            Total Sales : <strong> {{ number_format($countOfStockAllYear)}}</strong>
                        </li>
                        <li class="list-group-item">

                            @if (count($stockImporter))
                                <strong>Stock </strong><br>
                                @foreach ($stockImporter as $Importer)
                                    @if($Importer->status == 'Active')
                                        <h6>  {{ $Importer->Importer()->first()->name }} : <strong> {{
                          number_format($Importer->total_stock)
                              }}</strong></h6>
                                    @endif
                                @endforeach

                                <strong>Sales </strong><br>
                                @foreach ($stockImporter as $Importer)
                                    @if($Importer->status == 'Active')
                                        <h6>  {{ $Importer->Importer()->first()->name }} : <strong> {{
                          number_format($Importer->balance)
                              }}</strong></h6>    @endif
                                @endforeach

                            @else
                                <em>@lang('app.no_records_found')</em>
                            @endif


                        </li>


                        <li class="list-group-item">

                            Total Year : <strong> {{ number_format($sumByYear) }}</strong>
                        </li>


                        @if($yearAverage)
                            <li class="list-group-item">
                                Target of   {{$yearAverage->years}}
                                <strong>{{ number_format($yearAverage->average)}}</strong>
                                @include('stock.partials.fromEditAverage')<br>
                                Target of Month <strong> {{ number_format($yearAverage->average / 12 ) }}</strong>


                                @else
                                    @include('stock.partials.fromAddAverage')
                            </li>
                        @endif


                    </ul>

                    @if(count($allStock) < 12 * count($stockImporter))
                        @include('stock.partials.fromAddStock')
                    @else

                        <li class="list-group-item">

                            <strong> Count Month: {{ count($allStock) }} </strong>


                        </li>
                    @endif

                    @include('stock.partials.fromSendEmailStock')
                </div>
            </div>
        </div>


        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">

                    <form action="" method="GET" id="users-form" class="pb-1 mb-1 border-bottom-light">
                        <div class="row my-1 flex-md-row flex-column-reverse">


                            <div class="col-md-3 mt-3 mt-md-0">
                                <select name="year" class="form-control input-solid" id="year">
                                    <option value="">Year</option>
                                    <?php  $currentDate = new \Carbon\Carbon(); ?>

                                    @for ($i = 2014; $i <= $currentDate->year; $i++)

                                        <option @if(Input::get('year') == $i) selected @endif value="{{ $i }}">Year {{ $i
                                    }}</option>
                                    @endfor


                                </select>

                            </div>

                            <div class="col-md-3 mt-3 mt-md-0">
                                {!! Form::select('importer', [''=>'Importers'] + $listsItemImporters, Input::get('importer'), ['id' =>
                                'importer', 'class' =>
          'form-control input-solid']) !!}
                            </div>
                            <div class="col-md-6 mt-3 mt-md-0 float-right"><h3> {{ Input::get('year')}}</h3></div>

                        </div>
                    </form>


                    <div class="table-responsive" id="printableArea">
                        <table class="table table-borderless table-striped">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Sales</th>
                                <th>Stock</th>
                                <th>%</th>
                                <th>Importer</th>

                                <th>Month</th>
                                <th>Add By</th>


                            </tr>
                            </thead>
                            <tbody>
                            @if (count($allStock))

                                @foreach ($allStock as $stockRow)
                                    @include('stock.partials.rowStock')
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="7"><em>@lang('app.no_records_found')</em></td>
                                </tr>
                            @endif
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>#</th>
                                <th><h4>{{ number_format($sumBysearch) }} </h4></th>
                                <th>Stock</th>
                                <th>%</th>
                                <th>Importer</th>
                                <th>Month</th>
                                <th>Add By</th>


                            </tr>
                            <tfoot>
                        </table>
                        {!! $allStock->render() !!}


                    </div>


                    <div class="table-responsive" id="printableArea">
                        Average Monthly Sales
                        <table class="table table-borderless table-striped">
                            <thead>
                            <tr>


                            </tr>
                            </thead>
                            <tbody>


                            <tr>

                                <td>


 <span class="card-title"> 12
          {{ number_format($getLatestAverage12) }} / 12 =    <span class="badge badge-lg badge-info">
 {{ number_format($getLatestAverage12 / 12) }} </span>

             /
             <?php $sum12 = $getLatestAverage12 / 12; ?>

             {{ number_format($stockImporterSumStock ) }}

             = <span class="badge badge-lg badge-success">{{ number_format($stockImporterSumStock / $sum12) }} </span>

  </span>


                                </td>
                                <td>

 <span class="card-title"> 12
          {{ number_format($getLatestAverage12) }} / 12 =    <span class="badge badge-lg badge-info">
 {{ number_format($getLatestAverage12    / 12) }} </span>

             /
         <?php $sum12 = $getLatestAverage12 / 12;

         $sumOrder = $stockImporterSumStock + $getLatestOrder ;
         ?>

         {{ number_format($stockImporterSumStock) }} + {{ number_format($getLatestOrder) }}

         = <span class="badge badge-lg badge-success">{{ number_format($sumOrder /
         $sum12)
          }} </span>

     </span>


                                </td>
                            </tr>




                            <tr>

                                <td>

<span>   12
<span class="card-title">   {{ number_format($getLatestAverage6) }} / 6 = <span   class="badge badge-lg badge-info">
   {{ number_format($getLatestAverage6 / 6) }} </span>    /
        <?php $sum6 = $getLatestAverage6 / 6; ?>

  {{ number_format($stockImporterSumStock ) }}

= <span class="badge badge-lg badge-success">{{ number_format
($stockImporterSumStock / $sum6) }} </span>
 </span>
  </span>


                                </td>
                                <td>

 <span class="card-title"> 6
          {{ number_format($getLatestAverage6) }} / 6 =    <span class="badge badge-lg badge-info">
 {{ number_format($getLatestAverage6    / 6) }} </span>

             /
         <?php $sum6 = $getLatestAverage6 / 6;

         $sumOrder = $stockImporterSumStock + $getLatestOrder ;
         ?>

         {{ number_format($stockImporterSumStock) }} + {{ number_format($getLatestOrder) }}

         = <span class="badge badge-lg badge-success">{{ number_format($sumOrder /
         $sum6)
          }} </span>

     </span>


                                </td>
                            </tr>


                            <tr>

                                <td>

                                    <span> 3
                                            <span class="card-title">   {{ number_format($getLatestAverage6) }} / 3 = <span   class="badge
                                             badge-lg badge-info">
   {{ number_format($getLatestAverage3 / 3) }} </span>    /
                                                <?php $sum3 = $getLatestAverage3 / 3; ?>

                                                {{ number_format($stockImporterSumStock ) }}

= <span class="badge badge-lg badge-success">{{ number_format($stockImporterSumStock / $sum3) }}

                                                </span>
                                            </span>

                                </td>

                                <td>

 <span class="card-title"> 3
          {{ number_format($getLatestAverage3) }} / 3 =    <span class="badge badge-lg badge-info">
 {{ number_format($getLatestAverage3    / 3) }} </span>

             /
         <?php $sum3 = $getLatestAverage3 / 3;

         $sumOrder = $stockImporterSumStock + $getLatestOrder ;
         ?>
         {{ number_format($stockImporterSumStock) }} + {{ number_format($getLatestOrder) }}

         = <span class="badge badge-lg badge-success">{{ number_format($sumOrder /
         $sum3)
          }} </span>

     </span>


                                </td>

                            </tr>
 </tbody>

                        </table>


                    </div>
                </div>

            </div>
        </div>
    </div>


    @if (Input::has('search') && Input::get('search') != '' or Input::has('year') && Input::get('year') != '')
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <div class="pt-2 px-1">
                            @include('stock.ini.latest-month')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">

                    <div class="pt-2 px-1">
                        @include('stock.ini.latest-stock')
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">

                    <div class="pt-2 px-1">
                        @include('stock.ini.latest-users')
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">

                    <div class="pt-2 px-1">
                        @include('stock.ini.latest-all-month')
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

@section('scripts')





@stop

@section('after_styles')
    <?php /*<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">*/ ?>


    <link rel="stylesheet" href="{!! url('assets/plugins/morris/0.5.1/morris.css') !!}">
    <!-- DASHBOARD LIST CONTENT - dashboard_styles stack -->
    @stack('dashboard_styles')

    <style>
        /* Bootstrap tooltip need to be in single line */
        .tooltip-inner {
            white-space: nowrap;
            max-width: none;
        }
    </style>
@endsection

@section('after_scripts')
    <script>
        $("#year").change(function () {
            $("#users-form").submit();
        });
        $("#importer").change(function () {
            $("#users-form").submit();
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
    {!! JsValidator::formRequest('MedSites\Http\Requests\Stock\CreateStoreStockRequest', '#Stock-form') !!}

    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    {!! HTML::script('assets/plugins/morris/morris.min.js') !!}
    {!! HTML::script('assets/plugins/chartjs/2.7.2/Chart.js') !!}
    <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
    @stack('dashboard_scripts')
@endsection


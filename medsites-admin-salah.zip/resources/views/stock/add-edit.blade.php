@extends('layouts.app')

@section('page-title', 'Add Item')
@section('page-heading', $edit ? $stock->name : 'Edit Item')

@section('breadcrumbs')
    <li class="breadcrumb-item">
        <a href="{{ route('stock.index') }}">Item </a>
    </li>
    <li class="breadcrumb-item active">
        {{ $edit ? trans('app.edit') : trans('app.create') }}
    </li>
@stop

@section('content')

@include('partials.messages')





@if ($edit)
    {!! Form::open(['route' => ['stock.update', $stock->id], 'method' => 'PUT', 'id' => 'stock-form']) !!}
@else
    {!! Form::open(['route' => 'stock.store', 'id' => 'stock-form']) !!}
@endif

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <h5 class="card-title">
                    Item    Details
                </h5>
            </div>
        </div>
        <div class="row">

            <div class="col-md-4">
                <div class="form-group">
                    <label for="name"> Name</label>
                    <input type="text" class="form-control" id="name"
                           name="name" placeholder="name"
                           value="{{ $edit ? $stock->name : old('name') }}">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="importer"> Rate MedSites %</label>
                    <input type="text" class="form-control" id="rate_company"
                           name="rate_company" placeholder="Rate MedSites %"
                           value="{{ $edit ? $stock->rate_company : old('rate_company') }}">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="rate_importer"> Rate Importer %</label>
                    <input type="text" class="form-control" id="rate_importer"
                           name="rate_importer" placeholder="Rate Importer %"
                           value="{{ $edit ? $stock->rate_importer : old('rate_importer') }}">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="company"> Company</label>
                    <input type="text" class="form-control" id="company"
                           name="company" placeholder="Company"
                           value="{{ $edit ? $stock->company : old('company') }}">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="importer"> Importer</label>
                    <input type="text" class="form-control" id="importer"
                           name="importer" placeholder="importer"
                           value="{{ $edit ? $stock->importer : old('importer') }}">
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="company"> Price LE</label>
                    <input type="text" class="form-control" id="price"
                           name="price" placeholder="Price LE"
                           value="{{ $edit ? $stock->price : old('price') }}">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="_dollar"> Price Dollar $</label>
                    <input type="text" class="form-control" id="price"
                           name="price_dollar" placeholder="Price Dollar $ "
                           value="{{ $edit ? $stock->price_dollar : old('price_dollar') }}">
                </div>
            </div>
            <div class="col-md-4">
                <label for="pay_day_after">Pay Day After</label>
                <input type="text" class="form-control" id="pay_day_after"
                       name="pay_day_after" placeholder="Pay Day after Like 150 Day" value="{{ $edit ?
                           $stock->pay_day_after : old
                           ('pay_day_after') }}">
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="status">@lang('app.status')</label>
                    {!! Form::select('status', $statuses, $edit ? $stock->status : '',
                ['class' => 'form-control', 'id' => 'status']) !!}
                </div>
            </div>
        </div>




<div class="row">
    <div class="col-md-4">
        <button type="submit" class="btn btn-primary">
            {{ $edit ? 'Update Item' : 'Save Item' }}
        </button>
    </div>
</div>

@stop
@section('after_styles')

    @stack('dashboard_styles')

<style>.pand{padding-top: 35px;} </style>

@endsection
@section('after_scripts')


    @stack('dashboard_scripts')
@endsection

@section('scripts')

    @if ($edit)
        {!! JsValidator::formRequest('MedSites\Http\Requests\Stock\UpdateStockRequest', '#stock-form') !!}
    @else
        {!! JsValidator::formRequest('MedSites\Http\Requests\Stock\CreateStockRequest', '#stock-form') !!}
    @endif


@stop


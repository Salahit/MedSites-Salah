
    <h5 class="card-title">Sales  of all Years</h5>

		<div class="chart" id="barChartUsers" style="height: 300px;width:100% ;"></div>





@push('dashboard_styles')
@endpush

@push('dashboard_scripts')
    <script>
        $(function () {
            "use strict";
        
            // USERS STATS
            var area = new Morris.Bar({
                element: 'barChartUsers',
                resize: true,
                data: {!! $stockPerMonth !!},
                xkey: 'y',
                ykeys: ['activated'],
                labels: ['Total'],
                lineColors: ['#88c16d','#88c16d'],
                hideHover: 'auto',
                parseTime: true
            });
        });
    </script>
@endpush

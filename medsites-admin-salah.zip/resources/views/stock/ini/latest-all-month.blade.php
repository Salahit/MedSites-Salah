
    <h5 class="card-title">Sales  in every month of all years </h5>

		<div class="chart" id="getAllManthStockChart" style="height: 300px;width:100% ;"></div>





@push('dashboard_styles')
@endpush

@push('dashboard_scripts')
    <script>
        $(function () {
            "use strict";

            var area = new Morris.Bar({
                element: 'getAllManthStockChart',
                resize: true,
                data: {!! $getAllManthStockChart !!},
                xkey: 'y',
                ykeys: ['item'],
                labels: ['Total'],
                lineColors: ['#a0d0e0'],
                hideHover: 'auto'

            });
        });
    </script>
@endpush


    <h5 class="card-title">Sales  of Year {{ Input::get('search') }}</h5>

		<div class="chart" id="ManthStockChart" style="height: 300px;width:100% ;"></div>





@push('dashboard_styles')
@endpush

@push('dashboard_scripts')
    <script>
        $(function () {
            "use strict";

            var area = new Morris.Bar({
                element: 'ManthStockChart',
                resize: true,
                data: {!! $getManthStockChart !!},
                xkey: 'y',
                ykeys: ['item'],
                labels: ['Total'],
                lineColors: ['#a0d0e0'],
                hideHover: 'auto'

            });
        });
    </script>
@endpush

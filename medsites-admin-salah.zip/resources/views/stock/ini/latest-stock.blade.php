

    <div style="width:100%;">
        <canvas id="canvas"></canvas>
    </div>


@push('dashboard_styles')

    <style>

    </style>


@endpush

@push('dashboard_scripts')

    {!! HTML::script('assets/js/utils.js') !!}
                <script>

               var config = {
                    type: 'bar',
                   resize: true,
                   responsive: true,
                    data: {
                        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                        datasets: [{
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(0)->format('Y') }}',
                            backgroundColor: window.chartColors.red,
                            borderColor: window.chartColors.red,
                            data: {!! $sumStockPerMonthForYear0 !!},
                            fill: true,
                        }, {
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(1)->format('Y') }}',
                            fill: true,
                            backgroundColor: window.chartColors.blue,
                            borderColor: window.chartColors.blue,
                            data: {!! $sumStockPerMonthForYear1 !!},
                        }, {
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(2)->format('Y') }}',
                            fill: true,
                            backgroundColor: window.chartColors.green,
                            borderColor: window.chartColors.green,
                            data: {!! $sumStockPerMonthForYear2 !!},
                        }, {
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(3)->format('Y') }}',
                            fill: true,
                            backgroundColor: window.chartColors.orange,
                            borderColor: window.chartColors.orange    ,
                            data: {!! $sumStockPerMonthForYear3 !!},
                        }, {
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(4)->format('Y') }}',
                            fill: true,
                            backgroundColor: window.chartColors.yellow,
                            borderColor: window.chartColors.yellow,
                            data: {!! $sumStockPerMonthForYear4 !!},
                        }, {
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(5)->format('Y') }}',
                            fill: true,
                            backgroundColor: window.chartColors.grey,
                            borderColor: window.chartColors.grey,
                            data: {!! $sumStockPerMonthForYear5 !!},
                        }, {
                            label: 'Sales  {{ \Carbon\Carbon::now()->subYear(6)->format('Y') }}',
                            fill: true,
                            backgroundColor: window.chartColors.purple,
                            borderColor: window.chartColors.purple,
                            data: {!! $sumStockPerMonthForYear6 !!},
                        }]
                    },
                    options: {
                        responsive: true,
                        title: {
                            display: true,
                            text: 'Chart Line Unit'
                        },  tooltips: {
                            callbacks: {
                                label: function(tooltipItem, data) {
                                    return `${data.labels[tooltipItem.datasetIndex]} - ${numeral(data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index]).format('0,0')}`;
                                }
                            }
                        },

                        tooltips: {
                            mode: 'index',
                            intersect: false,
                        },
                        hover: {
                            mode: 'nearest',
                            intersect: true
                        },
                        scales: {
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Month'
                                }
                            }],
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'Value'
                                }
                            }]
                        }
                    }
                };

                window.onload = function() {
                    var ctx = document.getElementById('canvas').getContext('2d');
                    window.myLine = new Chart(ctx, config);
                };


            </script>


    {!! HTML::script('assets/js/chart.min.js') !!}


@endpush

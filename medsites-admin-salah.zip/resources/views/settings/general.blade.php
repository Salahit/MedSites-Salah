@extends('layouts.app')

@section('page-title', trans('app.general_settings'))
@section('page-heading', trans('app.general_settings'))

@section('breadcrumbs')
    <li class="breadcrumb-item text-muted">
        @lang('app.settings')
    </li>
    <li class="breadcrumb-item active">
        @lang('app.general')
    </li>
@stop

@section('content')

@include('partials.messages')

{!! Form::open(['route' => 'settings.general.update', 'id' => 'general-settings-form']) !!}

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                    <label for="name">@lang('app.name')</label>
                    <input type="text" class="form-control" id="app_name"
                           name="app_name" value="{{ settings('app_name') }}">
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="app_phone"
                           name="app_phone" value="{{ settings('app_phone') }}">
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                    <label for="dollar">Dollar Today</label>
                    <input type="text" class="form-control" id="dollar"
                           name="dollar" value="{{ settings('dollar') }}">
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                    <label for="app_address"> Language Available </label>
                    <div class="form-group my-4">
                        <div class="d-flex align-items-center">
                            <div class="switch">
                                <input type="hidden" value="0" name="language_available">
                                {!! Form::checkbox('language_available', 1, settings('language_available'), ['class' =>
                                'switch', 'id' => 'switch-language_available']) !!}
                                <label for="switch-language_available"></label>
                            </div>
                            <div class="ml-3 d-flex flex-column">
                                <label class="mb-0">Language Available</label>
                                <small class="pt-0 text-muted">
                                    Language Available
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                    <label for="app_address">Phone</label>
                    <textarea rows="4" cols="50" aria-rowcount="10" class="form-control" name="app_address"
                              id="description" >

{{ settings('app_address') }}
                    </textarea>
                </div>
            </div>
        </div>
    </div>


</div>




<button type="submit" class="btn btn-primary">
    @lang('app.update_settings')
</button>

{{ Form::close() }}
@stop

@section('after_styles')
    <link rel="stylesheet" type="text/css" href="{{ url('design')}}/assets/plugins/simditor/styles/simditor.css" />



    @stack('dashboard_styles')



@endsection
@section('after_scripts')



    <script src="{{ url('design')}}/assets/plugins/simditor/scripts/mobilecheck.js"></script>

    <script src="{{ url('design')}}/assets/plugins/simditor/scripts/module.js"></script>
    <script src="{{ url('design')}}/assets/plugins/simditor/scripts/hotkeys.js"></script>
    <script src="{{ url('design')}}/assets/plugins/simditor/scripts/uploader.js"></script>
    <script src="{{ url('design')}}/assets/plugins/simditor/scripts/simditor.js"></script>
    <script type="text/javascript">
        Simditor.i18n = {
            'en': {
                'blockquote': 'Block Quote',
                'bold': 'Bold',
                'code': 'Code',
                'color': 'Text Color',
                'coloredText': 'Colored Text',
                'hr': 'Horizontal Line',
                'image': 'Insert Image',
                'externalImage': 'External Image',
                'uploadImage': 'Upload Image',
                'uploadFailed': 'Upload failed',
                'uploadError': 'Error occurs during upload',
                'imageUrl': 'Url',
                'imageSize': 'Size',
                'imageAlt': 'Alt',
                'restoreImageSize': 'Restore Origin Size',
                'uploading': 'Uploading',
                'indent': 'Indent',
                'outdent': 'Outdent',
                'italic': 'Italic',
                'link': 'Insert Link',
                'linkText': 'Text',
                'linkUrl': 'Url',
                'linkTarget': 'Target',
                'openLinkInCurrentWindow': 'Open link in current window',
                'openLinkInNewWindow': 'Open link in new window',
                'removeLink': 'Remove Link',
                'ol': 'Ordered List',
                'ul': 'Unordered List',
                'strikethrough': 'Strikethrough',
                'table': 'Table',
                'deleteRow': 'Delete Row',
                'insertRowAbove': 'Insert Row Above',
                'insertRowBelow': 'Insert Row Below',
                'deleteColumn': 'Delete Column',
                'insertColumnLeft': 'Insert Column Left',
                'insertColumnRight': 'Insert Column Right',
                'deleteTable': 'Delete Table',
                'title': 'Title',
                'normalText': 'Text',
                'underline': 'Underline',
                'alignment': 'Alignment',
                'alignCenter': 'Align Center',
                'alignLeft': 'Align Left',
                'alignRight': 'Align Right',
                'selectLanguage': 'Select Language',
                'fontScale': 'Font Size',
                'fontScaleXLarge': 'X Large Size',
                'fontScaleLarge': 'Large Size',
                'fontScaleNormal': 'Normal Size',
                'fontScaleSmall': 'Small Size',
                'fontScaleXSmall': 'X Small Size'
            }
        };

        (function() {
            $(function() {
                var $preview, editor, mobileToolbar, toolbar, allowedTags;
                Simditor.locale = 'en';
                mobileToolbar = ["bold", "italic", "underline", "ul", "ol"];
                if (mobilecheck()) {
                    toolbar = mobileToolbar;
                }


                allowedTags = [];
                editor = new Simditor({
                    textarea: $('#description'),
                    placeholder: 'Describe what makes the product unique ...',
                    toolbar: toolbar,
                    pasteImage: false,
                    defaultImage: '{{ url("design")}}/assets/plugins/simditor/images/image.png',
                    upload: false,
                    html: true,

                    allowedTags: allowedTags
                });

                $preview = $('#preview');
                if ($preview.length > 0) {
                    return editor.on('valuechanged', function(e) {
                        return $preview.html(editor.getValue());
                    });
                }
            });
        }).call(this);
    </script>
    <!-- DASHBOARD LIST CONTENT - dashboard_scripts stack -->
    @stack('dashboard_scripts')
@endsection

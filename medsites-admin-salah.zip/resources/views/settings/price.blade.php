@extends('layouts.app')

@section('page-title', ' Price Settings')
@section('page-heading', ' Price Settings')

@section('breadcrumbs')
    <li class="breadcrumb-item text-muted">
         Settings
    </li>
    <li class="breadcrumb-item active">
        Price
    </li>
@stop

@section('content')

@include('partials.messages')

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="panel-heading"></div>
            <div class="card-body">
                <h5 class="card-title">
                    Price Settings
                </h5>

                {!! Form::open(['route' => 'settings.price.update', 'id' => 'price-settings-form']) !!}

                    <div class="form-group my-4">
                        <div class="d-flex align-items-center">
                            <div class="switch">
                                <input type="hidden" value="Banned" name="price_basic_on">

                                <input type="checkbox"
                                       name="price_basic_on"
                                       class="switch"
                                       value="Active"
                                       id="switch-price_basic_on"
                                       {{ settings('price_basic_on')  == 'Active' ? 'checked' : '' }}>

                                <label for="switch-price_basic_on"></label>
                            </div>
                            <div class="ml-3 d-flex flex-column">
                                <label class="mb-0">@lang('app.Activate_Version_Price') Basic</label>
                                <small class="pt-0 text-muted">
                                    @lang('app.Activate_the_version_in_the_page')
                                </small>
                            </div>
                        </div>
                    </div>



                <div class="form-group my-4">
                    <div class="d-flex align-items-center">
                        <div class="switch">
                            <input type="hidden" value="Banned" name="price_standard_on">

                            <input type="checkbox"
                                   name="price_standard_on"
                                   class="switch"
                                   value="Active"
                                   id="switch-price_standard_on"
                                    {{ settings('price_standard_on') == 'Active' ? 'checked' : '' }}>

                            <label for="switch-price_standard_on"></label>
                        </div>
                        <div class="ml-3 d-flex flex-column">
                            <label class="mb-0">@lang('app.Activate_Version_Price') Standard</label>
                            <small class="pt-0 text-muted">
                                @lang('app.Activate_the_version_in_the_page')
                            </small>
                        </div>
                    </div>
                </div>




                <div class="form-group my-4">
                    <div class="d-flex align-items-center">
                        <div class="switch">
                            <input type="hidden" value="Banned" name="price_advanced_on">

                            <input type="checkbox"
                                   name="price_advanced_on"
                                   class="switch"
                                   value="Active"
                                   id="switch-price_advanced_on"
                                    {{ settings('price_advanced_on') == 'Active' ? 'checked' : '' }}>

                            <label for="switch-price_advanced_on"></label>
                        </div>
                        <div class="ml-3 d-flex flex-column">
                            <label class="mb-0">@lang('app.Activate_Version_Price') Advanced</label>
                            <small class="pt-0 text-muted">
                                @lang('app.Activate_the_version_in_the_page')
                            </small>
                        </div>
                    </div>
                </div>





                <div class="form-group my-4">
                    <div class="d-flex align-items-center">
                        <div class="switch">
                            <input type="hidden" value="Banned" name="price_support_updates_on">

                            <input type="checkbox"
                                   name="price_support_updates_on"
                                   class="switch"
                                   value="Active"
                                   id="switch-price_support_updates_on"
                                    {{ settings('price_support_updates_on') == 'Active' ? 'checked' : '' }}>

                            <label for="switch-price_support_updates_on"></label>
                        </div>
                        <div class="ml-3 d-flex flex-column">
                            <label class="mb-0">@lang('app.Activate_Version_Price') Support & Updates</label>
                            <small class="pt-0 text-muted">
                                @lang('app.Activate_the_version_in_the_page')
                            </small>
                        </div>
                    </div>
                </div>



                <div class="col-md-6">


                            <div class="form-group">
                                <label for="support_updates_standard_id">Support & Updates Standard ID</label>
                                <input type="text" class="form-control" id="support_updates_standard_id"
                                       name="support_updates_standard_id" value="{{ settings('support_updates_standard_id') }}">
                            </div>
                        </div>

                <div class="col-md-6">


                    <div class="form-group">
                        <label for="support_updates_standard_price">Support & Updates Standard Price</label>
                        <input type="text" class="form-control" id="support_updates_standard_price"
                               name="support_updates_standard_price" value="{{ settings('support_updates_standard_price') }}">
                    </div>
                </div>



                <div class="col-md-6">


                    <div class="form-group">
                        <label for="support_updates_advanced_id">Support & Updates Advanced ID</label>
                        <input type="text" class="form-control" id="support_updates_advanced_id"
                               name="support_updates_advanced_id" value="{{ settings('support_updates_advanced_id') }}">
                    </div>
                </div>

                <div class="col-md-6">


                    <div class="form-group">
                        <label for="support_updates_advanced_price">Support & Updates Advanced Price</label>
                        <input type="text" class="form-control" id="support_updates_advanced_price"
                               name="support_updates_advanced_price" value="{{ settings('support_updates_advanced_price') }}">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary mt-3">
                        @lang('app.update_settings')
                    </button>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>

@stop
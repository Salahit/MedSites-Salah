<div class="inner-box">
    <h2 class="title-2">
        <i class="icon-mail"></i> New Ticket
    </h2>


    <div style="clear:both"></div>



    {!! Form::open(['route' => 'ticket.store', 'id' => 'ticket-form']) !!}



    <div class="row">

        <div class="col-md-4">


            <div class="form-group">
                <label for="product_id">Product</label>
                <select name="product_id" class="form-control" >
                    <option  value="">-- Select --</option>

                    @foreach ($products_inputs as $products_input)
                        <option
                                value={{$products_input->product_id }}>{{ $products_input->product_name
                            }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label for="title"> Titel Ticket</label>
                <input type="text" class="form-control" id="title"
                       name="title" placeholder="Titel"
                       value="{{ $edit ? $priec->title : old('title') }}">
            </div>
        </div>


        <div class="col-md-12">
            <div class="form-group">
                <label for="message">Message </label>
                <textarea name="message" id="description" rows="5" class="form-control">{{ $edit ?
                    $page->content : old('message') }}</textarea>
            </div>
        </div>

    </div>




    <div class="row">
        <div class="col-md-4">
            <button type="submit" class="btn btn-primary">
                Send Message
            </button>
        </div>
    </div>


</div>
{!! Form::close() !!}

@include('front.layouts.header')



@include('front.layouts.navbar')
@include('front.layouts.menu')



@include('front.layouts.message')
@yield('content')




@include('front.layouts.footer')
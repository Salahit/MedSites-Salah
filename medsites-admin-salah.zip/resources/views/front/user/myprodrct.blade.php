@extends('front.app')
@section('page-title', 'My Prodrct')
@section('page-heading', 'My Prodrct'))
@section('content')

@include('partials.messages')

<div class="main-container inner-page">
    <div class="container">
        <div class="section-content">
            <div class="inner-box">
                <h2 class="title-2">
                    <i class="icon-mail"></i> My Prodrct
                </h2>
                    <div class="card">
                        <div class="card-body">
                            <h1>{{auth()->user()->email}} - {{ count($licenseActivities) }}</h1>
                            <div class="table-responsive">
                                <table class="table table-borderless table-striped">
                                    <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>License</th>
                                        <th>Product</th>

                                        <th>Support End</th>


                                    </tr>
                                    </thead>
                                    <tbody>
                                    @if (count($licenseActivities))
                                        @foreach($licenseActivities as $licenseActivity)
                                            <tr>

                                                <td class="align-middle">
        <span class="badge badge-lg badge-{{ $licenseActivity->present()->labelClassNum }}">
            {{ trans("app.{$licenseActivity->status}") }}
        </span>
                                                </td>
 <td class="align-middle">{{ \Carbon\Carbon::parse($licenseActivity->date_created)->format ('Y M') }}
 </td>


                                                <td>  {{ $licenseActivity->activation  }} </td>
                                                <td>  {{ $licenseActivity->product_name  }} - {{ $licenseActivity->version_name }}</td>
                                                <td>  {{ $licenseActivity->support_e  }} </td>

                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                @else
                                    <p class="text-muted font-weight-light"><em>@lang('app.no_activity_from_this_user_yet')</em></p>
                                    @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>      </div>
                    </div>
                </div>    </div>
@stop
@section('after_styles')



        @stack('dashboard_styles')
@endsection
@section('scripts')




@stop
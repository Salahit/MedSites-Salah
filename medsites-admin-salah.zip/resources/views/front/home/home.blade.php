@extends('front.app')

@section('content')
    <div class="main-container" id="homepage" >
        <div class="wide-intro">
            <div id="custom_carousel" class="carousel slide" data-ride="carousel" data-interval="5500">
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    @if (count(menu_all()))
                        @foreach (menu_all() as $product)
                    <div class="item {{ $product->id == 1 ? 'active'  : '' }}">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/{{ $product->p_name }}.png" width="220" height="290" class="img-responsive"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">


                                    <h2> {!!$product['p_name'.langIsAr()]!!}</h2>


                                    <p>  {!!$product['p_description'.langIsAr()]!!}<br/></p>
                                    <a class="btn btn btn-add-listing" href="{{ $product->name_link }}" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i>   @lang('frontLog.read_more')
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                @else

                    @lang('app.no_records_found')

                @endif
                    <!-- End Item -->
                </div>
                <!-- End Carousel Inner -->
                <div class="controls">
                    <ul class="nav">
                        @if (count(menu_all()))
                            @foreach (menu_all() as $product)

                                <?php $val =  (count(menu_all()) - count(menu_all())) +1; ?>


 <li data-target="#custom_carousel" data-slide-to="{{  $loop->index }}"


                            class="{{ $product->id == 1 ? 'active'  : '' }}">

                            <a href="#"><img src="design/images/products/{{ $product->p_name }}.png" width="50"
                                            height="60"><small>{!!$product['p_name'.langIsAr()]!!}</small></a>



                        </li>
                            @endforeach
                        @else

                            @lang('app.no_records_found')

                        @endif
                    </ul>
                </div>
            </div>


        </div>

        <div class="h-spacer"></div>


        <div class="container" >
            <div class="row" >
                <div class="col-lg-12 page-content"@if (direction()== 'rtl') style="direction:rtl;" @endif >
                    <div class="inner-box">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div>
                                    <h2 class="title-3">
                                        <i class="fa fa-building"></i>&nbsp;@lang('frontLog.Welcome_to_MedSites')
                                    </h2>
                                    <div class="row" style="padding: 0 10px 0 20px;">



                                        <?php $valen = \MedSites\Pages::query()->where('status', 'Active')->where
                                        ('slug','aboutus')->first(); ?>

                                          {!!$valen['content'.langIsAr()]!!}

                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>

                <div class="h-spacer"></div>
                <div class="h-spacer"></div>
                <div class="container">

                    <div class="col-lg-12 content-box layout-section">
                        <div class="row row-featured row-featured-category">
                            <div class="col-lg-12 box-title">
                                <div class="inner" @if (direction()== 'rtl') style="direction:rtl;" @endif>
                                    <h2>
                                        <span class="title-3"> <span style="font-weight: bold;"> @lang('frontLog.Products')</span></span>
                                        <a href="#" class="sell-your-item">
                                            {{count(menu_all())}}<i class="icon-th-list"></i>
                                        </a>
                                    </h2>
                                </div>
                            </div>

                            <div style="clear: both"></div>

                            <div class="relative content featured-list-row clearfix">

                                <div class="large-12 columns" >
                                    <center>
                                    <div class="no-margin featured-list-slider owl-carousel owl-theme">

                                        @if (count(menu_all()))
                                            @foreach (menu_all() as $product)
                                                <div class="item">
                                                <a href="{{ $product->name_link }}">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/{{ $product->p_name }}.png" alt="Regulatory Affairs Officer" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                    <span class="item-name">{!!$product['p_nc_name'.langIsAr()
                                                  ]!!}</span>
                                                    <span class="price">{!!$product['p_name'.langIsAr()
                                                  ]!!}</span>
                                                    <span class="price">{{ $product->p_since }}
</span>
                                                    <span class="price">@lang('frontLog.Start') ${{
                                                    $product->f_price }}</span>
                                                </a>
                                    </div>
                                            @endforeach
                                        @else

                                               @lang('app.no_records_found')

                                        @endif





                                    </div></center>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>






            </div>
        </div>

@endsection


    @section('after_styles')
        <!-- bxSlider CSS file -->
            @if (direction()== 'rtl')
                <link href="{{ url('design/assets/plugins/bxslider/jquery.bxslider.rtl.css') }}" rel="stylesheet"/>
            @else

                <link href="{{ url('design/assets/plugins/bxslider/jquery.bxslider.css') }}" rel="stylesheet"/>
        @endif
    @endsection

    @section('after_scripts')
   <script>

                $(document).ready(function(ev){
                    $('#custom_carousel').on('slide.bs.carousel', function (evt) {
                        $('#custom_carousel .controls li.active').removeClass('active');
                        $('#custom_carousel .controls li:eq('+$(evt.relatedTarget).index()+')').addClass('active');
                    })
                });
  </script>
@endsection


@extends('front.app')

@section('content')





    <div class="h-spacer"></div>
    <div class="main-container inner-page">
        <div class="container">
            <div class="section-content">
                <div class="row">

                    <h1 class="text-center title-1" style="color: ;"><strong>Partner</strong></h1>
                    <hr class="center-block small text-hr" style="background-color: ;">

                    <div class="col-md-12 page-content">
                        <div class="inner-box relative">
                            <div class="row">
                                <div class="col-sm-12 page-content">
                                    <h3 style="text-align: center; color: ;">Partner</h3>
                                    <table border="0" width="100%">
                                        <tbody>
                                        <tr>
                                            <td height="50" width="362"><p>Ghana</p>
                                                <p>SUNSOFT MULTIMEDIALTD <br>
                                                    Mr. Pascal Mohammed <br>
                                                    No. 7 Maabey Avenue C3 <br>
                                                    Haasto Residential Area, Accra <br>
                                                    P.O. Box LG 950<br>
                                                    Ghana, West Africa<br>
                                                    Mobile: +233 268 808 886<br>
                                                    Email : <a href="mailto:pascal@sunsoftmultimedia.net">pascal@sunsoftmultimedia.net</a> <br>
                                                    Web: <a href="http://www.sunsoftmultimedia.net">www.sunsoftmultimedia.net</a></p>
                                                <p> </p></td>
                                        </tr>
                                        <tr>
                                            <td height="50" width="362"><p>Egypt</p>
                                                <p>Electronic Golden Software<br>
                                                    12 Minaa Aghader st; Miami<br>
                                                    Alexandria, Egypt.<br>
                                                    Tel: +20 3 540 2190 - +20 3 555 9116<br>
                                                    Email : <a href="mailto:info@egoldensoft.com">info@egoldensoft.com</a></p>
                                                <p> </p></td>
                                        </tr>
                                        <tr>
                                            <td height="50" width="362"><p>Uganda</p>
                                                <p>Mr.Richard Okot <br>
                                                    Gad Info-Systems <br>
                                                    PLOT 29A-29B <br>
                                                    PRINTERS ARCADE <br>
                                                    NASSER ROAD <br>
                                                    P.O BOX 23886 <br>
                                                    KAMPALA, UGANDA <br>
                                                    TEL:(+256) 772 427309 <br>
                                                    (+256) 772 496372 <br>
                                                    EMAIL: <a href="mailto:info@gadinfosystems.com">info@gadinfosystems.com</a><br>
                                                    Web: <a href="http://www.gadinfosystems.com">www.gadinfosystems.com</a></p>
                                                <p> </p></td>
                                        </tr>
                                        <tr>
                                            <td height="50" width="362"><p>Zambia</p>
                                                <p>Redfort Limited<br>
                                                    Mr. David C. Toka<br>
                                                    P.O. Box 437FW<br>
                                                    Lusaka, Zambia <br>
                                                    Tel: +260-1-223314 <br>
                                                    Email : <a href="mailto:redfort@botsnet.bw">redfort@botsnet.bw</a></p>
                                                <p> </p></td>
                                        </tr>
                                        <tr>
                                            <td height="50" width="362"><p>Ghana</p>
                                                <p>Direct Innsoft Enterprise<br>
                                                    Mr. Charles Yeboah<br>
                                                    Tel : +233243967711<br>
                                                    Skype ID : charlesyeboah1765<br>
                                                    email : <a href="mailto:yeboah1765@gmail.com">yeboah1765@gmail.com</a></p>
                                                <br></td>
                                        </tr>
                                        <tr>
                                            <td height="50" width="362"><p>USA</p>
                                                <p> Mr. Calros Ayala<br>
                                                    South Florida Telecom                                                                                3857 Coral Tree Circle                                                                                Coconut Creek, FL 33073<br>
                                                    Tel: (954) 862-7008 <br>
                                                    URL : <a href="http://www.SouthFloridaTelecom.com">www.SouthFloridaTelecom.com</a></p></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                    <p>&nbsp;</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div style="margin: 25px 0; text-align: center;">
                    <button class='btn btn-fb share s_facebook'><i class="icon-facebook"></i> </button>&nbsp;
                    <button class='btn btn-tw share s_twitter'><i class="icon-twitter"></i> </button>&nbsp;
                    <button class='btn btn-danger share s_plus'><i class="icon-googleplus-rect"></i> </button>&nbsp;
                    <button class='btn btn-lin share s_linkedin'><i class="icon-linkedin"></i> </button>
                </div>
            </div>
        </div>
    </div>
@endsection
@extends('front.app')

@section('content')





    <div class="h-spacer"></div>
    <div class="main-container">
        <div class="container">
            <div class="row">



                <div class="col-md-8 page-content">
                    <div class="inner-box category-content">
                        <h2 class="title-2"><strong>  Download {{ $product->name_link }}</strong></h2>
                        <div class="row">


                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <form action="http://med-sites.com/download/add_download" id="register_form" ,class="regular_form" method="post" accept-charset="utf-8"><div style="display:none">
                                        <input type="hidden" name="csrf_test_name" value="ad66bd9d60548d8890ffe22d0685cd04" />
                                    </div>

                                    <div id="error" class="the_error">
                                    </div>
                                    <div id="success" class="the_error">
                                    </div>
                                    <p>(All fields are required)</p>



                                    <div class="form-group">
                                        <label for="reg_first_name">Name</label>
                                        <input type="text" name="name" id="reg_first_name" class="form-control tooltip_target" placeholder="Name" data-toggle="tooltip"  value=""  data-original-title="* Length between 6 - 16
* Can only contain a-z A-Z 0-9 _ and - characters">
                                    </div>

                                    <div class="form-group">
                                        <label for="reg_email">E-mail address</label>
                                        <input type="text" name="email" id="reg_email" class="form-control tooltip_target" placeholder="E-mail address" value="" data-toggle="tooltip" data-original-title="* Please provide a valid e-mail address">
                                    </div>
                                    <ul id="email_verification_box" class="list-unstyled">
                                        <li><div id="email_valid"></div></li>
                                    </ul>

                                    <div class="form-group">
                                        <label for="reg_email">Country</label>

                                        <select name="country"  class="form-control tooltip_target">

                                            <option value="" selected="selected">--Select--</option>
                                            <option  value=1 >Afghanistan</option><option  value=2 >Albania</option><option  value=3 >Algeria</option><option  value=5 >American Samoa</option><option  value=6 >Angola</option><option  value=7 >Argentina</option><option  value=8 >Armenia</option><option  value=9 >Australia</option><option  value=10 >Austria</option><option  value=11 >Azerbaijan</option><option  value=12 >Bahamas</option><option  value=13 >Bahrain</option><option  value=15 >Bangladesh</option><option  value=16 >Belarus</option><option  value=17 >Belgium</option><option  value=18 >Belize</option><option  value=20 >Bosnia</option><option  value=21 >Botswana</option><option  value=22 >Brazil</option><option  value=23 >Brunei Darussalam</option><option  value=24 >Bulgaria</option><option  value=25 >Burkina Faso</option><option  value=26 >Burundi</option><option  value=27 >Cameroon</option><option  value=28 >Canada</option><option  value=29 >Cayman Islands</option><option  value=30 >Central African Rep.</option><option  value=31 >Chad</option><option  value=32 >Chile</option><option  value=33 >China</option><option  value=34 >Colombia</option><option  value=35 >Comoros</option><option  value=36 >Congo</option><option  value=37 >Costa Rica</option><option  value=38 >Croatia (Hrvatska)</option><option  value=39 >Cuba</option><option  value=40 >Cyprus</option><option  value=41 >Czech Republic</option><option  value=42 >Denmark</option><option  value=43 >Djibouti</option><option  value=44 >Dominican Republic</option><option  value=45 >East Timor</option><option  value=46 >Ecuador</option><option  value=47 >Egypt</option><option  value=50 >El Salvador</option><option  value=51 >Eritrea</option><option  value=52 >Estonia</option><option  value=53 >Ethiopia</option><option  value=54 >Fiji</option><option  value=55 >Finland</option><option  value=56 >France</option><option  value=57 >Gabon</option><option  value=58 >Gambia</option><option  value=59 >Georgia</option><option  value=60 >Germany</option><option  value=61 >Ghana</option><option  value=62 >Great Britain (UK)</option><option  value=63 >Greece</option><option  value=64 >Guatemala</option><option  value=65 >Haiti</option><option  value=66 >Honduras</option><option  value=67 >Hong Kong</option><option  value=68 >Hungary</option><option  value=69 >Iceland</option><option  value=70 >India</option><option  value=71 >Indonesia</option><option  value=72 >Iran</option><option  value=73 >Iraq</option><option  value=77 >Ireland</option><option  value=78 >Italy</option><option  value=79 >Jamaica</option><option  value=80 >Japan</option><option  value=81 >Jordan</option><option  value=86 >Kazakhstan</option><option  value=87 >Kenya</option><option  value=88 >Korea (North)</option><option  value=89 >Korea (South)</option><option  value=90 >Kuwait</option><option  value=96 >Kyrgyzstan</option><option  value=97 >Laos</option><option  value=98 >Latvia</option><option  value=99 >Lebanon</option><option  value=104 >Liberia</option><option  value=105 >Libya</option><option  value=108 >Lithuania</option><option  value=109 >Luxembourg</option><option  value=110 >Macau</option><option  value=111 >Macedonia</option><option  value=112 >Madagascar</option><option  value=113 >Malawi</option><option  value=114 >Malaysia</option><option  value=115 >Maldives</option><option  value=116 >Mali</option><option  value=117 >Malta</option><option  value=118 >Mauritania</option><option  value=119 >Mauritius</option><option  value=120 >Mexico</option><option  value=121 >Monaco</option><option  value=122 >Mongolia</option><option  value=123 >Morocco</option><option  value=128 >Mozambique</option><option  value=129 >Myanmar</option><option  value=130 >Namibia</option><option  value=131 >Nepal</option><option  value=132 >Netherlands</option><option  value=133 >New Zealand</option><option  value=134 >Nicaragua</option><option  value=135 >Niger</option><option  value=136 >Nigeria</option><option  value=137 >Norway</option><option  value=138 >Oman</option><option  value=141 >Other</option><option  value=142 >Pakistan</option><option  value=143 >Palestine</option><option  value=149 >Panama</option><option  value=150 >Paraguay</option><option  value=151 >Peru</option><option  value=152 >Philippines</option><option  value=153 >Poland</option><option  value=154 >Portugal</option><option  value=155 >Puerto Rico</option><option  value=156 >Qatar</option><option  value=158 >Romania</option><option  value=159 >Russian Federation</option><option  value=160 >Rwanda</option><option  value=161 >San Marino</option><option  value=162 >Saudi Arabia</option><option  value=168 >Senegal</option><option  value=169 >Seychelles</option><option  value=170 >Sierra Leone</option><option  value=171 >Singapore</option><option  value=172 >Slovak Republic</option><option  value=173 >Slovenia</option><option  value=174 >Somalia</option><option  value=175 >South Africa</option><option  value=176 >Spain</option><option  value=177 >Sri Lanka</option><option  value=178 >Sudan</option><option  value=180 >Swaziland</option><option  value=181 >Sweden</option><option  value=182 >Switzerland</option><option  value=183 >Syria</option><option  value=189 >Taiwan</option><option  value=190 >Tajikistan</option><option  value=191 >Tanzania</option><option  value=192 >Thailand</option><option  value=193 >Tonga</option><option  value=194 >Tunisia</option><option  value=199 >Turkey</option><option  value=200 >Turkmenistan</option><option  value=201 >Uganda</option><option  value=202 >Ukraine</option><option  value=203 >United Arab Emirates</option><option  value=212 >United Kingdom</option><option  value=213 >United States</option><option  value=214 >Uruguay</option><option  value=215 >Uzbekistan</option><option  value=216 >Vatican City</option><option  value=217 >Venezuela</option><option  value=218 >Viet Nam</option><option  value=219 >Western Sahara</option><option  value=220 >Yemen</option><option  value=221 >Yugoslavia</option><option  value=222 >Zaire</option><option  value=223 >Zambia</option><option  value=224 >Zimbabwe</option><option  value=226 >Israel</option><option  value=1 >Afghanistan</option><option  value=2 >Albania</option><option  value=3 >Algeria</option><option  value=5 >American Samoa</option><option  value=6 >Angola</option><option  value=7 >Argentina</option><option  value=8 >Armenia</option><option  value=9 >Australia</option><option  value=10 >Austria</option><option  value=11 >Azerbaijan</option><option  value=12 >Bahamas</option><option  value=13 >Bahrain</option><option  value=15 >Bangladesh</option><option  value=16 >Belarus</option><option  value=17 >Belgium</option><option  value=18 >Belize</option><option  value=20 >Bosnia</option><option  value=21 >Botswana</option><option  value=22 >Brazil</option><option  value=23 >Brunei Darussalam</option><option  value=24 >Bulgaria</option><option  value=25 >Burkina Faso</option><option  value=26 >Burundi</option><option  value=27 >Cameroon</option><option  value=28 >Canada</option><option  value=29 >Cayman Islands</option><option  value=30 >Central African Rep.</option><option  value=31 >Chad</option><option  value=32 >Chile</option><option  value=33 >China</option><option  value=34 >Colombia</option><option  value=35 >Comoros</option><option  value=36 >Congo</option><option  value=37 >Costa Rica</option><option  value=38 >Croatia (Hrvatska)</option><option  value=39 >Cuba</option><option  value=40 >Cyprus</option><option  value=41 >Czech Republic</option><option  value=42 >Denmark</option><option  value=43 >Djibouti</option><option  value=44 >Dominican Republic</option><option  value=45 >East Timor</option><option  value=46 >Ecuador</option><option  value=47 >Egypt</option><option  value=50 >El Salvador</option><option  value=51 >Eritrea</option><option  value=52 >Estonia</option><option  value=53 >Ethiopia</option><option  value=54 >Fiji</option><option  value=55 >Finland</option><option  value=56 >France</option><option  value=57 >Gabon</option><option  value=58 >Gambia</option><option  value=59 >Georgia</option><option  value=60 >Germany</option><option  value=61 >Ghana</option><option  value=62 >Great Britain (UK)</option><option  value=63 >Greece</option><option  value=64 >Guatemala</option><option  value=65 >Haiti</option><option  value=66 >Honduras</option><option  value=67 >Hong Kong</option><option  value=68 >Hungary</option><option  value=69 >Iceland</option><option  value=70 >India</option><option  value=71 >Indonesia</option><option  value=72 >Iran</option><option  value=73 >Iraq</option><option  value=77 >Ireland</option><option  value=78 >Italy</option><option  value=79 >Jamaica</option><option  value=80 >Japan</option><option  value=81 >Jordan</option><option  value=86 >Kazakhstan</option><option  value=87 >Kenya</option><option  value=88 >Korea (North)</option><option  value=89 >Korea (South)</option><option  value=90 >Kuwait</option><option  value=96 >Kyrgyzstan</option><option  value=97 >Laos</option><option  value=98 >Latvia</option><option  value=99 >Lebanon</option><option  value=104 >Liberia</option><option  value=105 >Libya</option><option  value=108 >Lithuania</option><option  value=109 >Luxembourg</option><option  value=110 >Macau</option><option  value=111 >Macedonia</option><option  value=112 >Madagascar</option><option  value=113 >Malawi</option><option  value=114 >Malaysia</option><option  value=115 >Maldives</option><option  value=116 >Mali</option><option  value=117 >Malta</option><option  value=118 >Mauritania</option><option  value=119 >Mauritius</option><option  value=120 >Mexico</option><option  value=121 >Monaco</option><option  value=122 >Mongolia</option><option  value=123 >Morocco</option><option  value=128 >Mozambique</option><option  value=129 >Myanmar</option><option  value=130 >Namibia</option><option  value=131 >Nepal</option><option  value=132 >Netherlands</option><option  value=133 >New Zealand</option><option  value=134 >Nicaragua</option><option  value=135 >Niger</option><option  value=136 >Nigeria</option><option  value=137 >Norway</option><option  value=138 >Oman</option><option  value=141 >Other</option><option  value=142 >Pakistan</option><option  value=143 >Palestine</option><option  value=149 >Panama</option><option  value=150 >Paraguay</option><option  value=151 >Peru</option><option  value=152 >Philippines</option><option  value=153 >Poland</option><option  value=154 >Portugal</option><option  value=155 >Puerto Rico</option><option  value=156 >Qatar</option><option  value=158 >Romania</option><option  value=159 >Russian Federation</option><option  value=160 >Rwanda</option><option  value=161 >San Marino</option><option  value=162 >Saudi Arabia</option><option  value=168 >Senegal</option><option  value=169 >Seychelles</option><option  value=170 >Sierra Leone</option><option  value=171 >Singapore</option><option  value=172 >Slovak Republic</option><option  value=173 >Slovenia</option><option  value=174 >Somalia</option><option  value=175 >South Africa</option><option  value=176 >Spain</option><option  value=177 >Sri Lanka</option><option  value=178 >Sudan</option><option  value=180 >Swaziland</option><option  value=181 >Sweden</option><option  value=182 >Switzerland</option><option  value=183 >Syria</option><option  value=189 >Taiwan</option><option  value=190 >Tajikistan</option><option  value=191 >Tanzania</option><option  value=192 >Thailand</option><option  value=193 >Tonga</option><option  value=194 >Tunisia</option><option  value=199 >Turkey</option><option  value=200 >Turkmenistan</option><option  value=201 >Uganda</option><option  value=202 >Ukraine</option><option  value=203 >United Arab Emirates</option><option  value=212 >United Kingdom</option><option  value=213 >United States</option><option  value=214 >Uruguay</option><option  value=215 >Uzbekistan</option><option  value=216 >Vatican City</option><option  value=217 >Venezuela</option><option  value=218 >Viet Nam</option><option  value=219 >Western Sahara</option><option  value=220 >Yemen</option><option  value=221 >Yugoslavia</option><option  value=222 >Zaire</option><option  value=223 >Zambia</option><option  value=224 >Zimbabwe</option><option  value=226 >Israel</option></select>

                                    </div>

                                    <div class="form-group">
                                        <label for="reg_email">Know About Us From</label>

                                        <select name="know"  class="form-control tooltip_target">
                                            <option value="" selected="selected">--Select--</option>
                                            <option value="Altavista.com" >Altavista.com</option>
                                            <option value="AOL.com" >AOL.com</option>
                                            <option value="ASK.com" >ASK.com</option>
                                            <option value="Download.com" >Download.com</option>
                                            <option value="Facebook.com" >Facebook.com</option>
                                            <option value="Google.com" >Google.com</option>
                                            <option value="Bing.com">Bing.com</option>
                                            <option value="Lycos.com" >Lycos.com</option>
                                            <option value="Yahoo.com" >Yahoo.com</option>
                                            <option value="MSN.com" >MSN.com</option>
                                            <option value="E-Mails" >E-Mails</option>
                                            <option value="Other Search Engine" >Other Search Engine</option>
                                            <option value="Others" >Others</option>
                                        </select>

                                    </div>

                                    <div class="form-group">
                                        <h5>Please note by registering in our website and download our software you will subscribe to our email list, to unsubscribe you can delete your account.
                                        </h5></div>

                                    <div class="recaptcha-wrapper">
                                    </div>

                                    <!-- Button  -->
                                    <div class="form-group">
                                        <label class="col-md-4 control-label"></label>
                                        <div class="col-md-6">
                                            <button id="signupBtn" class="btn btn-success btn-lg"> Download </button>
                                        </div>
                                    </div>
                                    <div class="h-spacer"></div>


                                    <input type="hidden" name="id_p" value="HospitalGate" />
                                </form>


                            </div>
                        </div>
                    </div>
                </div>
                @include('front.layouts.bar_lift')

            </div>
        </div>
    </div>

@endsection
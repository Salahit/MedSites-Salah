@extends('front.app')

@section('content')





    <div class="h-spacer"></div>
    <div class="main-container inner-page">
        <div class="container">
            <div class="section-content">
                <div class="row">

                    <h1 class="text-center title-1" style="color: ;"><strong>AboutUS</strong></h1>
                    <hr class="center-block small text-hr" style="background-color: ;">

                    <div class="col-md-12 page-content">
                        <div class="inner-box relative">
                            <div class="row">
                                <div class="col-sm-12 page-content">
                                    <h3 style="text-align: center; color: ;">AboutUS MedSites</h3>
                                    <strong>MedSites is a Cairo based Complete Software Solutions and Complete web Solutions Company focused on creating custom applications and laying special emphasis on the unique business needs of its corporate clients. MedSites infrastructure and processes are concentrated at designing and implementing solutions for Small to large sized companies. MedSites long-term-relationship-based strategy ensures a continuously stable growth and a solid customer base.<br><br>

                                        Our Staff Our staff consists of a team of talented and innovative individuals like Software & Web developers, graphic artists, analysts, programmers, database designers and Internet Business specialists all of whom are dedicated to providing your desktop, multi-user & online solutions.</strong>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div style="margin: 25px 0; text-align: center;">
                    <button class='btn btn-fb share s_facebook'><i class="icon-facebook"></i> </button>&nbsp;
                    <button class='btn btn-tw share s_twitter'><i class="icon-twitter"></i> </button>&nbsp;
                    <button class='btn btn-danger share s_plus'><i class="icon-googleplus-rect"></i> </button>&nbsp;
                    <button class='btn btn-lin share s_linkedin'><i class="icon-linkedin"></i> </button>
                </div>
            </div>
        </div>
    </div>
@endsection
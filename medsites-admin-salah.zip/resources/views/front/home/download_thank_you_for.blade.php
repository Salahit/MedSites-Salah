@extends('front.app')

@section('content')





    <div class="h-spacer"></div>
    <div class="main-container">
        <div class="container">
            <div class="row">



                <div class="col-md-8 page-content">
                    <div class="inner-box category-content">
                        <h2 class="title-2"><strong>  Download</strong></h2>
                        <div class="row">


                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">


                            </div>
                        </div>
                    </div>
                </div>
                @include('front.layouts.bar_lift')

            </div>
        </div>
    </div>

@endsection
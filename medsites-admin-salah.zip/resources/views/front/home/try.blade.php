<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="shortcut icon" href="http://med-sites.com/images/medsites.ico"/>
    <title>Medical Software, Hospital, Dental, Veterinary, Billing, Appointment, Clinic</title>
    <meta name="DESCRIPTION" content="MedSites is a Healthcare Software Leader For Medical Billing Software, Hospital Management, Veterinary Office, Salon, Dental Clinic, Appointment scheduling software For Small-Large Practice Management Size. Download FREE 21 Days Trial." />
    <meta name="keywords" content="medical software, hospital software, veterinary software, dental software, beauty salon software, billing software, clinic Software, medical Appointment scheduling software, healthcare software, practice management software, Hospital management system" />

    <link rel="dns-prefetch" href="//fonts.googleapis.com"/>
    <link rel="dns-prefetch" href="//graph.facebook.com"/>
    <link rel="dns-prefetch" href="//google.com"/>
    <link rel="dns-prefetch" href="//apis.google.com"/>
    <link rel="dns-prefetch" href="//ajax.googleapis.com"/>
    <link rel="dns-prefetch" href="//www.google-analytics.com"/>
    <link rel="dns-prefetch" href="//pagead2.googlesyndication.com"/>
    <link rel="dns-prefetch" href="//gstatic.com"/>
    <link rel="dns-prefetch" href="//cdn.api.twitter.com"/>
    <link rel="dns-prefetch" href="//oss.maxcdn.com"/>

    <meta property="og:site_name" content="Medsites" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content=" Medical Software, Hospital, Dental, Veterinary, Salon, Billing, VAT, Appointment Scheduling, Clinic" />
    <meta property="og:description" content="MedSites is a Healthcare Software Leader For Medical Billing Software, Hospital Mangement, Veterinary Office, Salon, Dental Clinic, Appointment scheduling software For Small-Large Practice Management Size. Download FREE 21 Days Trial." />
    <meta property="twitter:card" content="summary">
    <meta property="twitter:title" content="Medical Software, Hospital, Dental, Veterinary, Salon, Billing, VAT, Appointment Scheduling, Clinic">
    <meta property="twitter:description" content="MedSites is a Healthcare Software Leader For Medical Billing Software, Hospital Mangement, Veterinary Office, Salon, Dental Clinic, Appointment scheduling software For Small-Large Practice Management Size. Download FREE 21 Days Trial.">
    <meta property="twitter:domain" content="www.med-sites.com">



    <link href="{{ url('design')}}/css/app.css" rel="stylesheet">

    <style type="text/css">
        #custom_carousel .item {

            color:#006;

            padding:20px 0;
        }
        #custom_carousel .controls{
            overflow-x: auto;
            overflow-y: hidden;
            padding:10;
            margin:10;
            white-space: nowrap;
            text-align: center;
            position: relative;

        }
        #custom_carousel .controls li {
            display: table-cell;
            width: 1%;
            max-width:90px
        }
        #custom_carousel .controls li.active {

            border-top:3px solid orange;
        }
        #custom_carousel .controls a small {
            overflow:hidden;
            display:block;
            font-size:10px;
            margin-top:5px;
            font-weight:bold
        }
        /* === Body === */

        /* === Header === */
        .navbar-site { position: absolute !important; }
        /* === Footer === */

        /* === Button: Add Listing === */

        /* === Other: Grid View Columns === */

        /* === Homepage: Search Form Area === */
        #homepage .wide-intro {background-image: url(design/uploads/app/logo/header-5aa1512725049.png);
            background-size: cover;}#homepage .wide-intro h1 { color: #080808; }#homepage .wide-intro p { color: #080808; }
        /* === Homepage: Locations & Country Map === */


        /* === CSS Fix === */
        .f-category h6 {
            color: #333;
        }
        .photo-count {
            color: #292b2c;
        }
        .page-info-lite h5 {
            color: #ccc;
        }
        h4.item-price {
            color: #292b2c;
        }
        .skin-blue .pricetag {
            color: #fff;
        }

    </style>

    <link href="{{ url('design')}}/css/custom.css" rel="stylesheet">

    <link href="{{ url('design')}}/assets/plugins/bxslider/jquery.bxslider.css" rel="stylesheet"/>


    <meta name="google-site-verification" content="cbSYvDVe9ImsWX3mfMCXoTYhVMNElDqr5pImC5E1CS0" />
    <meta name="google-site-verification" content="neiMyEmK5nfWxWqq-PiomUMrWls_I0khY7TjBCFXJ9g" />
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-108613292-2"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-108613292-2');
    </script>


    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->

    <script>
        paceOptions = {
            elements: true
        };
    </script>
    <script src="{{ url('design')}}/assets/js/pace.min.js"></script>
</head>
<body class="skin-blue">

<div id="wrapper">

    <div class="header">
        <nav class="navbar navbar-site navbar-default" role="navigation">
            <div class="container">
                <div class="navbar-header">

                    <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>


                    <button class="flag-menu country-flag visible-xs btn btn-default hidden" href="#selectCountry" data-toggle="modal">

                        <i class="fa fa-question-circle "></i><strong> Help</strong><span class="caret hidden-sm"></span>

                        <span class="caret hidden-xs"></span>
                    </button>


                    <a href="/" class="navbar-brand logo logo-title">
                        <img src="{{ url('design')}}/uploads/app/logo/logo-5a92d4c5aaa85.png"
                             alt="MedSites" class="tooltipHere main-logo" title="" data-placement="bottom"
                             data-toggle="tooltip"
                             data-original-title="MedSites"/>
                    </a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-left">


                        <li class="tooltipHere hidden-xs" data-toggle="tooltip" data-placement="right" title="Help" style="margin-top:0px;">

                            <a class="btn btn-block btn-border btn-post btn-add-listing" href="#selectCountry" data-toggle="modal">
                                <i class="fa fa-key "></i><strong> Help</strong><span class="caret hidden-sm"></span>
                            </a>



                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-building fa hidden-sm"></i>
                                <span><strong>Company</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>

                            <ul  class="dropdown-menu user-menu">
                                <li><a href="http://med-sites.com/aboutus">About Us</a></li>
                                <li><a href="http://med-sites.com/partner">Our Partnrs</a></li>
                                <li><a href="http://med-sites.com/faq">Faq</a></li>
                                <li><a href="http://med-sites.com/feedback">Feedback</a></li>
                                <li><a href="http://med-sites.com//feedback_post">Post Feedback</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-check-square fa hidden-sm"></i>
                                <span><strong>Services</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>

                            <ul  class="dropdown-menu user-menu">
                                <li><a href="http://med-sites.com/services">Services</a></li>
                                <li><a href="http://med-sites.com/software_reseller">Software Reseller</a></li>

                            </ul>
                        </li>
                        <li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-th fa hidden-sm"></i>
                                <span><strong>Products</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>
                            <ul  class="dropdown-menu user-menu">
                                <li><a href="http://med-sites.com/hospital_software">HospitalGate</a></li>
                                <li><a href="http://med-sites.com/medical_billing_software">ClinicGate</a></li>
                                <li><a href="http://med-sites.com/veterinary_practice_software">VeterinaryGate</a></li>
                                <li><a href="http://med-sites.com/beauty_salon_software">BodyCareGate</a></li>
                                <li><a href="http://med-sites.com/purchase_orders_software">CompanyGate</a></li>
                                <li><a href="http://med-sites.com/restaurant_software">RestaurantGate</a></li>
                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-users hidden-sm"></i>
                                <span><strong>Clients</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>
                            <ul  class="dropdown-menu user-menu">
                                <li><a href="http://med-sites.com/clients_software">Software</a></li>
                                <li><a href="http://med-sites.com/clients_web">Websites</a></li>
                            </ul>
                        </li>




                        <li   >
                            <a target="_blank" class="btn btn btn-add-listing" style="padding-left:10px; padding-right:10px;" href="http://med-sites.com/support">
                                <i class="fa fa-question-circle "></i><strong> Support</strong>
                            </a>
                        </li>

                        <!-- Language selector -->
                        <li class="dropdown lang-menu">
                            <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                                EN
                                <span class="caret hidden-sm"> </span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="#" tabindex="-1" rel="alternate" hreflang="fr">
                                        <span class="lang-name"> Fr (soon)</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" tabindex="-1" rel="alternate" hreflang="ar">
                                        <span class="lang-name">Ar (soon) </span>
                                    </a>
                                </li>
                            </ul>

                        </li>
                        <li>



                            <a href="http://med-sites.com/account/login#quickLogin" data-toggle="modal"><i class="icon-user fa"></i> Log In</a>
                        </li>
                        <li><a href="http://med-sites.com/account/register"><i class="icon-user-add fa"></i> Register</a></li>


                    </ul>


                </div>
            </div>
        </nav>
    </div>





    <div class="main-container" id="homepage">

        <div class="wide-intro">
            <div id="custom_carousel" class="carousel slide" data-ride="carousel" data-interval="5500">
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="item active">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/HospitalGate.png" width="220" height="290" class="img-responsive"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">
                                    <h2>HospitalGate</h2>
                                    <p>HospitalGate Offers hospital software, Hospital Information System - HIS and FREE Hospital Software to creates a common workflow infrastructure across the entire healthcare system for instant communication, patient and resource tracking, and automated patient flow.</p>
                                    <p>
                                        HospitalGate is a Network and Multi-User Hospital Information System - HIS, Electronic Medical record Software and FREE Hospital Admission software for Small-medium Hospital that contain all the Financial, Clinical, and Operational elements For a successful running Hospital.</p>
                                    <br/>
                                    <a class="btn btn btn-add-listing" href="hospital_software" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/ClinicGate.png" class="img-responsive" width="220" height="290"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">
                                    <h2>Medical Billing Software</h2>
                                    <p>

                                        ClinicGate is a Medical Software offers an easy to use Windows interface featuring an integration of Medical Billing, Appointment Scheduling, Patient Record, Insurance Claim CMS 1500, Tracking Receivables, Managing Expenses and Generating Customized Reports And Graphic Reports.
                                    </p> <p>
                                        ClinicGate is a Network and Multi-User Medical Software, Medical Office Billing Software, Electronic Medical record Software and for Small-Large Medical Practice that contain all the Financial, Clinical, and Operational elements For a successful running Medical Office.</p>
                                    <br/>
                                    <a class="btn btn btn-add-listing" href="medical_billing_software" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/VeterinaryGate.png" class="img-responsive" width="220" height="290"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">
                                    <h2>Veterinary Software</h2>
                                    <p>

                                        VeterinaryGate is a Veterinary Software, Veterinary Office Billing Software, Practice Management Software offers an easy to use Windows interface featuring an integration of Animal & Pet Medical Records, Appointment Scheduling, Billing, Tracking Receivables, Managing Expenses and Generating Customized Reports And Graphic Reports.
                                    </p> <p>
                                        VeterinaryGate is a Network and Multi-User Veterinary Software, Veterinary Office Billing Software, Animal Medical Records Software and Veterinary Practice Management Software for Samll-Large Veterinary Medical Practice that contain all the Financial, Clinical, and Operational elements For a successful running Veterinary Practice .</p>
                                    <a class="btn btn btn-add-listing" href="veterinary_practice_software" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/BodyCareGate.png" class="img-responsive" width="220" height="290"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">
                                    <h2>Beauty Salon Software</h2>
                                    <p>


                                        BodyCareGate is a Beauty Salon & SPA Software, Massage Therapy Software, offers an easy to use Windows interface featuring an integration of Customer Records, Appointment Scheduling, Invoicing, Billing , Tracking Receivables, Expenses, Inventory with Purchase Orders, Sales Orders and Generating Customized Reports And Graphic Reports.
                                    </p><p>
                                        BodyCareGate is Affordable (US$ 99), Easy & Simple Multi-User Beauty Salon & SPA Software, Massage Therapy Software, For Small-Large Practice that empower your business by creating the right System unique to your Business needs that contain all the Financial, Therapeutic, and Operational elements For a successful running Practice.</p>

                                    <a class="btn btn btn-add-listing" href="purchase_orders_software" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/BodyCareGate.png" class="img-responsive" width="220" height="290"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">
                                    <h2>Purchase Orders Software</h2>
                                    <p>

                                        CompanyGate is a Business Management Software, Purchase Orders Software and Sales orders Software offers an easy to use Windows interface featuring an integration of Customer Records, Appointment Scheduling, Invoicing, Billing , Tracking Receivables, Expenses, Inventory with Purchase Orders, Sales Orders and Generating Customized Reports And Graphic Reports.
                                    </p><p>
                                        CompanyGate is a Affordable US$99 Multi-User Business Management Software For Small-Medium Companies that contains all the Financial and Sales Operation Management that helps you to successfully run your Business.</p>
                                    <br/>
                                    <a class="btn btn btn-add-listing" href="beauty_salon_software" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-lg-2 col-md-2 col-sm-2"><img src="design/images/products/RestaurantGate.png" class="img-responsive" width="220" height="290"></div>
                                <div class="col-lg-10 col-md-10 col-sm-10">
                                    <h2> Restaurant Software</h2>
                                    <p>

                                        RestaurantGate is a Restaurant Software, Bistro & Internet Cafe Software offers an easy to use Windows interface featuring an integration of Customer Records, Table Reservation Scheduling, Invoicing, Billing , Tracking Receivables, Expenses, Inventory with Purchase Orders, Sales Orders and Generating Customized Reports And Graphic Reports.
                                    </p><p>
                                        RestaurantGate is Affordable (US$ 199), Easy & Simple Multi-User Restaurant Software, internet Cafe Software, Bistro Software For Small-Large Size, Bistro and Cafe that empower your Business by creating the right System unique to your needs and contains all the Financial and Sales Operation Management that helps you to successfully run your Business.</p>

                                    <br/>
                                    <a class="btn btn btn-add-listing" href="restaurant_software" style="padding:10px;text-transform: none;">
                                        <i class="fa fa-book"></i> Read More
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Item -->
                </div>
                <!-- End Carousel Inner -->
                <div class="controls">
                    <ul class="nav">

                        <li data-target="#custom_carousel" data-slide-to="0" class="active"><a href="#"><img src="design/images/products/HospitalGate.png" width="50" height="60"><small>HospitalGate</small></a></li>
                        <li data-target="#custom_carousel" data-slide-to="1"><a href="#"><img src="design/images/products/ClinicGate.png" width="50" height="60"><small>ClinicGate</small></a></li>
                        <li data-target="#custom_carousel" data-slide-to="2"><a href="#"><img src="design/images/products/VeterinaryGate.png" width="50" height="60"><small>VeterinaryGate</small></a></li>
                        <li data-target="#custom_carousel" data-slide-to="3"><a href="#"><img src="design/images/products/BodyCareGate.png" width="50" height="60"><small>BodyCareGate</small></a></li>
                        <li data-target="#custom_carousel" data-slide-to="4"><a href="#"><img src="design/images/products/CompanyGate.png" width="50" height="60"><small>CompanyGate </small></a></li>
                        <li data-target="#custom_carousel" data-slide-to="5"><a href="#"><img src="design/images/products/RestaurantGate.png" width="50" height="60"><small>RestaurantGate</small></a></li>
                    </ul>
                </div>
            </div>


        </div>

        <div class="h-spacer"></div>


        <div class="container">
            <div class="row">
                <div class="col-lg-12 page-content">
                    <div class="inner-box">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div>
                                    <h2 class="title-3">
                                        <i class="fa fa-building"></i>&nbsp;Welcome to MedSites
                                    </h2>
                                    <div class="row" style="padding: 0 10px 0 20px;">


                                        <h3>MedSites is Healthcare Software Company and a Leader Of Medical Software, Medical Office Billing Software, Hospital Software, Veterinary Software, Beauty Salon Software, Clinic Billing Software, Appointment Scheduling Software, Dental Software, VAT Software, since year 2001. We empower and improve your Practice Management by creating Windows Billing System Software right according to your unique Business needs.
                                            <br />
                                            Dwonload 21 Days Full Version Free Trial then Order with 30 Days Money Back Guarantee. Join MedSites Affiliate and Reseller Program. We are located in Cairo - Egypt for our USA customers, call 2026575650 - We are Open for Partnership/Joint Venture in USA, UK, UAE & Saudi Arabia, Contact us for Business Co-operation Details.</h3>
                                        Our Major Clients
                                        <br /><center> <p> <img src="http://med-sites.com//content/images/pfizerlogo.png" alt="" width="169" height="113" class="center" />  <img src="http://med-sites.com//content/images/bayer.png" alt="" width="135" height="113" class="center" />



                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
                <div class="h-spacer"></div><div class="h-spacer"></div>
                <div class="container">
                    <div class="col-lg-12 content-box layout-section">
                        <div class="row row-featured row-featured-category">
                            <div class="col-lg-12 box-title">
                                <div class="inner">
                                    <h2>
                                        <span class="title-3"> <span style="font-weight: bold;">Products</span></span>
                                        <a href="#" class="sell-your-item">
                                            6 <i class="icon-th-list"></i>
                                        </a>
                                    </h2>
                                </div>
                            </div>

                            <div style="clear: both"></div>

                            <div class="relative content featured-list-row clearfix">

                                <div class="large-12 columns">
                                    <div class="no-margin featured-list-slider owl-carousel owl-theme">

                                        <div class="item">
                                            <a href="hospital_software">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/HospitalGate.png" alt="Regulatory Affairs Officer" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                <span class="item-name">Hospital Software</span>
                                                <span class="price">HospitalGate</span>
                                                <span class="price">Since 2008
</span>
                                                <span class="price">Start at US$498</span>
                                            </a>
                                        </div>

                                        <div class="item">
                                            <a href="medical_billing_software">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/ClinicGate.png" alt="Regulatory Affairs Officer" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                <span class="item-name">Medical Billing Software</span>
                                                <span class="price">ClinicGate </span>
                                                <span class="price">Since 2004
</span>
                                                <span class="price">Start at US$199</span>
                                            </a>
                                        </div>

                                        <div class="item">
                                            <a href="veterinary_practice_software">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/VeterinaryGate.png" alt="Regulatory Affairs Officer" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                <span class="item-name">Veterinary Software</span>
                                                <span class="price">VeterinaryGate</span>
                                                <span class="price">Since 2008
</span>
                                                <span class="price">Start at US$199</span>
                                            </a>
                                        </div>

                                        <div class="item">
                                            <a href="beauty_salon_software">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/BodyCareGate.png" alt="Regulatory Affairs Officer" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                <span class="item-name">Beauty Salon & SPA Software</span>
                                                <span class="price">BodyCareGate</span>
                                                <span class="price">Since 2005
</span>
                                                <span class="price">Start at US$69</span>
                                            </a>
                                        </div>

                                        <div class="item">
                                            <a href="purchase_orders_software">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/CompanyGate.png" alt="CompanyGate" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                <span class="item-name">Invoicing Software</span>
                                                <span class="price">CompanyGate </span>
                                                <span class="price">Since 2006
</span>
                                                <span class="price">Start at US$69</span>
                                            </a>
                                        </div>

                                        <div class="item">
                                            <a href="restaurant_software">
    <span class="item-carousel-thumb">
    <img class="img-responsive" src="design/images/products/RestaurantGate.png" alt="RestaurantGate" style="border: 1px solid #e7e7e7; margin-top: 2px;">
    </span>
                                                <span class="item-name">Restaurant Software</span>
                                                <span class="price">RestaurantGate </span>
                                                <span class="price">Since 2008
</span>
                                                <span class="price">Start at US$199</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>






            </div>	</div>

        <footer class="main-footer">
            <div class="footer-content">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                            <div class="footer-col">
                                <h4 class="footer-title">Products</h4>
                                <ul class="list-unstyled footer-nav">

                                    <li><a href="hospital_software">HospitalGate</a></li>
                                    <li><a href="medical_billing_software">ClinicGate</a></li>
                                    <li><a href="veterinary_practice_software">VeterinaryGate</a></li>
                                    <li><a href="beauty_salon-software">BodyCareGate</a></li>
                                    <li><a href="purchase_orders_softwarep">CompanyGate</a></li>
                                    <li><a href="restaurant_software">RestaurantGate</a></li>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                            <div class="footer-col">
                                <h4 class="footer-title">Contact &amp; Support</h4>
                                <ul class="list-unstyled footer-nav">
                                    <li><a href="services">Services</a></li>
                                    <li><a href="software_reseller">Software Reseller</a></li>
                                    <li><a href="http://med-sites.com/support">Support</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                            <div class="footer-col">
                                <h4 class="footer-title"> Company</h4>
                                <ul class="list-unstyled footer-nav">
                                    <li><a href="http://med-sites.com/aboutus">About Us</a></li>
                                    <li><a href="http://med-sites.com/partner">Our Partnrs</a></li>
                                    <li><a href="http://med-sites.com/faq">Faq</a></li>
                                    <li><a href="http://med-sites.com/feedback">Feedback</a></li>
                                    <li><a href="http://med-sites.com//feedback_post">Post Feedback</a></li>
                                    <li><a href="http://med-sites.com/services">Services</a></li>
                                    <li><a href="http://med-sites.com/software_reseller">Software Reseller</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="footer-col row">


                                <div class="col-sm-12 col-xs-6 col-xxs-12 no-padding-lg">
                                    <div class="">
                                        <h4 class="footer-title ">Follow us on</h4>
                                        <ul class="list-unstyled list-inline footer-nav social-list-footer social-list-color footer-nav-inline">
                                            <li>
                                                <a class="icon-color fb" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://www.facebook.com/MedSitesSoft/" data-original-title="Facebook">
                                                    <i class="fa fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="icon-color tw" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://twitter.com/medsites" data-original-title="Twitter">
                                                    <i class="fa fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="icon-color gp" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://plus.google.com/u/0/102942835317554440895" data-original-title="Google+">
                                                    <i class="fa fa-google-plus"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="icon-color lin" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://www.linkedin.com/in/medsites/" data-original-title="LinkedIn">
                                                    <i class="fa fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a class="icon-color pin" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="#" data-original-title="Pinterest">
                                                    <i class="fa fa-pinterest-p"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div style="clear: both"></div>

                        <div class="col-lg-12">
                            <hr>

                            <div class="copy-info text-center">
                                � 2018 Medsites. All Rights Reserved.
                                Powered by MedSites
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </footer>

    </div>
    <div class="modal fade" id="quickLogin" tabindex="-1" role="dialog">
        <div class="modal-dialog  modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                    </button>
                    <h4 class="modal-title"><i class="icon-login fa"></i> Log In </h4>
                </div>
                <form action="http://med-sites.com/account/login/validate" method="post" accept-charset="utf-8"><div style="display:none">
                        <input type="hidden" name="csrf_test_name" value="b822f6f1475be9daa66313b156999cfd" />
                    </div>

                    <div class="modal-body">




                        <!-- Login -->
                        <div class="form-group ">
                            <label for="login" class="control-label">Login (Email address)</label>
                            <div class="input-icon"><i class="icon-user fa"></i>
                                <input id="mLogin" name="username" type="text" placeholder="Email address" class="form-control" value="">
                            </div>
                        </div>

                        <!-- Password -->
                        <div class="form-group ">
                            <label for="password" class="control-label">Password</label>
                            <div class="input-icon"><i class="icon-lock fa"></i>
                                <input id="mPassword" name="password" type="password" class="form-control" placeholder="Password" autocomplete="off">
                            </div>
                        </div>

                        <div class="form-group ">

                            <p>
                                <label for="remember_me">Remember me</label>
                                <input type="checkbox" name="remember_me" value="accept" id="remember_me"  />					</p>

                            <p class="pull-right" style="margin-top: 10px;">

                                <a href="http://med-sites.com/account/register">Create account</a> /
                                <a href="http://med-sites.com/account/forgot_password"  >Retrieve password</a> /
                                <a href="http://med-sites.com/account/forgot_username" >Retrieve username</a>


                            </p>
                            <div style=" clear:both"></div>
                        </div>

                        <!-- recaptcha -->
                        <div class="form-group required ">

                            <div>



                            </div>
                        </div>

                        <input type="hidden" name="quickLoginForm" value="1">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success pull-right">Log In</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <!-- Modal Change Country -->
    <div class="modal fade modalHasList" id="selectCountry" tabindex="-1" role="dialog" aria-labelledby="selectCountryLabel"
         aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                    </button>
                    <h4 class="modal-title uppercase font-weight-bold" id="selectCountryLabel">
                        <i class="icon-map"></i> Help
                    </h4>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="row" style="padding: 0 20px">
                            <a href="tel:+201222189796"  class="btn btn-success btn-block showphone">
                                <i class="icon-phone-1">+201222189796</i>
                            </a>

                            <strong>Address</strong> : 	2 Mahmoud Esmat Street, Sheraton Heliopolis.
                            Cairo - Egypt
                            <br>
                            <strong> Cell Phone :</strong>

                            +201-222189796 <br>
                            <strong>Tel </strong>	:

                            +202-22690045 <br>

                            <strong> USA :</strong>

                            +1202-657-5650 <br>

                            <strong>Fax </strong>	: 	+202-22690480 <br>

                            <strong>Skype ID </strong>	:	medsites <br>

                            <strong>Office Time</strong> 	: 	9h00 AM - 6h00 PM (Saturday to Thursday) <br>

                            <strong>Time zone </strong>	: 	GMT +02:00 <br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.modal -->
    <script type="text/javascript">

        <!--
        var CI = {
            'base_url': 'http://med-sites.com/'
        };
        -->
    </script>
    <script type="text/javascript">
        <!--
        var LANG = {
            'is_valid_email' : 'Please enter a correct e-mail address.',
            'fill_out_username': 'Please fill out a username.',
            'fill_out_password' : 'Please choose a password.',
            'checking_validity' : 'checking validity ...',
            'checking_availability' : 'checking availability ...',
            'email_is_valid' : 'E-mail address is valid',
            'email_is_taken' : 'E-mail address is taken',
            'email_is_available' : 'E-mail address is available',
            'email_characters' : 'Invalid characters in e-mail address.',
            'username_is_valid' : 'Username is valid',
            'username_available' : 'Username is available',
            'username_exists' : 'That username is already registered.',
            'username_minlength' : 'Username must be at least 6 characters.',
            'username_maxlength' : 'Username can not be bigger then 16 characters',
            'is_valid_username' : 'The username field can only contain a-z A-Z 0-9 _ and - characters.',
            'fill_out_first_name' : 'Please fill out a first name.',
            'first_name_minlength' : 'The first name field must be at least 2 characters in length.',
            'first_name_maxlength' : 'The first name field can not exceed 40 characters in length.',
            'fill_out_last_name' : 'Please fill out a last name.',
            'last_name_minlength' : 'The last name field must be at least 2 characters in length.',
            'last_name_maxlength' : 'The last name field can not exceed 60 characters in length.',
            'fill_out_email' : 'Please enter your e-mail address.',
            'email_maxlength' : 'E-mail address can contain maximum 255 characters.',
            'password_minlength' : 'The password field must be at least 6 characters in length.',
            'password_maxlength' : 'The password field can not exceed 64 characters in length.',
            'password_match' : 'The password fields must match.',
            'password_profile' : 'Please enter your password before changing your profile.',
            'password_current' : 'The current password must contain at least 6 characters.',
            'password_new' : 'The new password must contain at least 6 characters.',
            'password_new_max' : 'The new password must contain less then 64 characters.',
            'password_repeat' : 'The repeat new password field can\'t be empty.',
            'password_no_match' : 'New passwords do not match.',
            'search_data' : 'Please enter some search data.',
            'email_empty' : 'E-mail field can not be empty.',
            'recaptcha_required' : 'The captcha response field field is required'
        };
        -->
    </script>

    <script>

        var siteUrl = 'public';
        var languageCode = 'en';
        var countryCode = 'EG';


        var langLayout = {
            'hideMaxListItems': {
                'moreText': "View More",
                'lessText': "View Less"
            },
            'select2': {
                errorLoading: function(){
                    return "The results could not be loaded."
                },
                inputTooLong: function(e){
                    var t = e.input.length - e.maximum, n = 'Please delete ' + t + ' character';
                    return t != 1 && (n += 's'),n
                },
                inputTooShort: function(e){
                    var t = e.minimum - e.input.length, n = 'Please enter ' + t + ' or more characters';
                    return n
                },
                loadingMore: function(){
                    return "Loading more results�"
                },
                maximumSelected: function(e){
                    var t = 'You can only select ' + e.maximum + ' item';
                    return e.maximum != 1 && (t += 's'),t
                },
                noResults: function(){
                    return "No results found"
                },
                searching: function(){
                    return "Searching�"
                }
            }
        };
    </script>


    <script>
        /* Carousel Parameters */
        var carouselItems = 3;
        var carouselAutoplay = 1;
        var carouselAutoplayTimeout = 1500;
        var carouselLang = {
            'navText': {
                'prev': "prev",
                'next': "next"
            }
        };
    </script>

    <script src="{{ url('design')}}/js/app.js?id=ee03f858562229352a21"></script>
    <script src="{{ url('design')}}/assets/plugins/select2/js/i18n/en.js"></script>
    <script>
        $(document).ready(function () {

            $('.selecter').select2({
                language: langLayout.select2,
                dropdownAutoWidth: 'true',
                minimumResultsForSearch: Infinity,
                width: '100%'
            });


            $('.sselecter').select2({
                language: langLayout.select2,
                dropdownAutoWidth: 'true',
                width: '100%'
            });


            $('.share').ShareLink({
                title: 'MedSites is a Healthcare .',
                text: 'MedSites is a Healthcare Software Leader For Medical Billing Software, Hospital Mangement, Veterinary Office, Salon, Dental Clinic, Appointment scheduling software For Small-Large Practice Management Size. Download FREE 21 Days Trial.',
                url: 'http://med-sites.com/'

            });


        });
    </script>


    <script>

        $(document).ready(function(ev){
            $('#custom_carousel').on('slide.bs.carousel', function (evt) {
                $('#custom_carousel .controls li.active').removeClass('active');
                $('#custom_carousel .controls li:eq('+$(evt.relatedTarget).index()+')').addClass('active');
            })
        });
        /* Default view (See in /js/script.js) */
        gridView('.grid-view');
        /* Save the Search page display mode */
        var listingDisplayMode = readCookie('listing_display_mode');
        if (!listingDisplayMode) {
            createCookie('listing_display_mode', '.grid-view', 7);
        }

        /* Favorites Translation */
        var lang = {
            labelSavePostSave: "Save ad",
            labelSavePostRemove: "Remove favorite",
            loginToSavePost: "Please log in to save the Ads.",
            loginToSaveSearch: "Please log in to save the search.",
            confirmationSavePost: "Post saved in favorites successfully !",
            confirmationRemoveSavePost: "Post deleted from favorites successfully !",
            confirmationSaveSearch: "Search saved successfully !",
            confirmationRemoveSaveSearch: "Search deleted successfully !"
        };
    </script>

    <script>
        /* Modal Default Admin1 Code */
        var modalDefaultAdminCode = '0';
    </script>
    <script src="{{ url('design')}}/assets/js/app/load.cities.js"></script>

    <script src="{{ url('design')}}/assets/plugins/twism/jquery.twism.js"></script>
    <script>
        $(document).ready(function () {
            $('#countryMap').twism("create",
                {
                    map: "custom",
                    customMap: 'images/maps/eg.svg',
                    backgroundColor: 'transparent',
                    border: '#4682B4',
                    hoverBorder: '#4682B4',
                    borderWidth: 4,
                    color: '#d5e3ef',
                    width: '300px',
                    height: '300px',
                    click: function(region) {
                        if (typeof region == "undefined") {
                            return false;
                        }
                        if (isBlankValue(region)) {
                            return false;
                        }
                        region = rawurlencode(region);
                        var searchPage = 'design/search';
                        searchPage = searchPage + '?r=' + region;
                        redirect(searchPage);
                    },
                    hover: function(regionId) {
                        if (typeof regionId == "undefined") {
                            return false;
                        }
                        var selectedIdObj = document.getElementById(regionId);
                        if (typeof selectedIdObj == "undefined") {
                            return false;
                        }
                        selectedIdObj.style.fill = '#4682B4';
                        return;
                    },
                    unhover: function(regionId) {
                        if (typeof regionId == "undefined") {
                            return false;
                        }
                        var selectedIdObj = document.getElementById(regionId);
                        if (typeof selectedIdObj == "undefined") {
                            return false;
                        }
                        selectedIdObj.style.fill = '#d5e3ef';
                        return;
                    }
                });
        });
    </script>
    <!-- bxSlider Javascript file -->
    <script src="{{ url('design')}}/assets/plugins/bxslider/jquery.bxslider.min.js"></script>

    <script>
        /* Favorites Translation */
        var lang = {
            labelSavePostSave: "Save ad",
            labelSavePostRemove: "Remove favorite",
            loginToSavePost: "Please log in to save the Ads.",
            loginToSaveSearch: "Please log in to save the search.",
            confirmationSavePost: "Post saved in favorites successfully !",
            confirmationRemoveSavePost: "Post deleted from favorites successfully !",
            confirmationSaveSearch: "Search saved successfully !",
            confirmationRemoveSaveSearch: "Search deleted successfully !"
        };

        $(document).ready(function () {
            /* Slider */
            var $mainImgSlider = $('.bxslider').bxSlider({
                speed: 1000,
                pagerCustom: '#bx-pager',
                adaptiveHeight: true
            });

            /* Initiates responsive slide */
            var settings = function () {
                var mobileSettings = {
                    slideWidth: 80,
                    minSlides: 2,
                    maxSlides: 5,
                    slideMargin: 5,
                    adaptiveHeight: true,
                    pager: false
                };
                var pcSettings = {
                    slideWidth: 100,
                    minSlides: 3,
                    maxSlides: 6,
                    pager: false,
                    slideMargin: 10,
                    adaptiveHeight: true
                };
                return ($(window).width() < 768) ? mobileSettings : pcSettings;
            };

            var thumbSlider;

            function tourLandingScript() {
                thumbSlider.reloadSlider(settings());
            }

            thumbSlider = $('.product-view-thumb').bxSlider(settings());
            $(window).resize(tourLandingScript);


            /* Google Maps */
            getGoogleMaps(
                'AIzaSyBDtOxfjaoajVFTEHnSkftYzmyZ3zB1720',
                'Sidi Salim,Egypt',
                'en'
            );

            /* Keep the current tab active with Twitter Bootstrap after a page reload */
            /* For bootstrap 3 use 'shown.bs.tab', for bootstrap 2 use 'shown' in the next line */
            $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
                /* save the latest tab; use cookies if you like 'em better: */
                localStorage.setItem('lastTab', $(this).attr('href'));
            });
            /* Go to the latest tab, if it exists: */
            var lastTab = localStorage.getItem('lastTab');
            if (lastTab) {
                $('[href="' + lastTab + '"]').tab('show');
            }
        })
    </script>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-44464760-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-44464760-1');
    </script>

</body>
</html>






@extends('front.app')

@section('content')


@section('page-title', $page->title )


    <div class="h-spacer"></div>
    <div class="main-container inner-page" @if (direction()== 'rtl') style="direction:rtl;" @endif>
        <div class="container">
            <div class="section-content">
                <div class="row">

                    <h1 class="text-center title-1"  ><strong> {!!$page['name'.langIsAr()]!!}
                        </strong></h1>
                    <hr class="center-block small text-hr" style="background-color: ;">

                    <div class="col-md-12 page-content">
                        <div class="inner-box relative">
                            <div class="row">
                                <div class="col-sm-12 page-content">
                                    <h3 style="text-align: center; color: ;">  {!!$page['name'.langIsAr()]!!}</h3>

 <p><strong> {!!  $page['content'.langIsAr()]  !!}</strong></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div style="margin: 25px 0; text-align: center;">
                    <button class='btn btn-fb share s_facebook'><i class="icon-facebook"></i> </button>&nbsp;
                    <button class='btn btn-tw share s_twitter'><i class="icon-twitter"></i> </button>&nbsp;
                    <button class='btn btn-danger share s_plus'><i class="icon-googleplus-rect"></i> </button>&nbsp;
                    <button class='btn btn-lin share s_linkedin'><i class="icon-linkedin"></i> </button>
                </div>
            </div>
        </div>
    </div>
@endsection
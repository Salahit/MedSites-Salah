@extends('front.app_products')

@section('content')




    <div class="main-container">
        <div class="container">
            <ol class="breadcrumb pull-left">
                <li><a href="/"><i class="icon-home fa"></i></a></li>
                <li>
                    <a href="#">
                        Products
                    </a>
                </li>

                <li class="active">{{ $products->p_name }}</li>
            </ol>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-9 page-content col-thin-right">
                    <div class="inner inner-box ads-details-wrapper">
                        <h2 class="enable-long-words">
                            <strong>
                                <a href="3" title="Medical Rep">
                                    {{ $products->p_name }}                                 </a>
                            </strong>
                            <small class="label label-default adlistingtype">{{ $products->p_since }}</small>
                        </h2>
                        <span class="info-row">
							<span class="date"><i class=" icon-clock"> </i> 11 years </span> -&nbsp;
							<span class="category"><a target="_blank" href="http://www.med-sites.com/manual/cg"><i class="fa fa-question-circle"></i>Training Help Manual</a></span> -&nbsp;
							<span class="item-location"><a target="_blank" href="http://www.med-sites.com/manual/Brochure/Medical_Billing_Software_Brochure_cg.pdf"><i class="fa fa-file"></i> Download Brochure</a> </span> -&nbsp;
							<span class="category"><a target="_blank" href="manual/cg/ClinicGate_Ver_Comp.html"><i class="fa fa-check"></i>Version's Comparison</a></span>
<span class="category">-&nbsp;-&nbsp;<a target="_blank" href="http://med-sites.com/download/product/ClinicGate"><i class="fa fa-download"></i> Download</a></span>
						</span>
                        <h1 class="pricetag">{{ $products->f_price }}</h1>
                        <h2 class="title-3">
                            {{ $products->p_nc_name }} </h2>
                        <h3><p>
                                {!! $products->p_description !!} </h3>

                        <center>
                            <div class="item">

    <span class="item-carousel-thumb center">
    <img src="{{ url('design')}}/images/products/{{$products->p_name}}.png" alt="{{$products->p_nc_name}}" width="300" height="400
    " class="img-responsive" style="border: 1px solid #e7e7e7; margin-top: 2px; background-position:center">
    </span>

                            </div>
                        </center>

                        <br />
                        <center>
                            <h4><p>
                                    CMS 1500 & ICD-9-CM International Diseases Classifications are included<br />

                                    Software for Microsoft Windows 98, ME, XP, NT, 2000, 2003, 2008, Vista, Windows
                                    7, 8,10 and comes with 1 Full Year FREE online support.
                                </p></h4>
                        </center>
                        <br />
                        <h4><p>
                                {!! $products->p_keyword_price !!}
                            </p></h4>



                        @include('front.products.price.'. $products->name_link )


                        <div class="ads-details">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab-details" data-toggle="tab"><h4>Software Features </h4></a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab-details">
                                    <div class="row" style="padding: 10px;">
                                        <div class="ads-details-info col-md-12 col-sm-12 col-xs-12 enable-long-words from-wysiwyg">

                                            <!-- Location -->
                                            <div class="detail-line-lite col-md-6 col-sm-6 col-xs-6">
                                                <div>
                                                    <span><i class="fa fa-download"></i> Download: </span>
                                                    <span>
																												<a href="#">
 21 days FREE trial														</a>
													</span>
                                                </div>
                                            </div>
                                            <!-- Price / Salary -->
                                            <div class="detail-line-lite col-md-6 col-sm-6 col-xs-6">
                                                <div>

														<span>

																																														<small class="label label-success">User Friendly, Simple and Affordable</small>
																													</span>
                                                </div>
                                            </div>
                                            <div style="clear: both;"></div>
                                            <hr>

                                            <!-- Description -->
                                            <div class="detail-line-content">
                                                <center>
                                                    <div class="ads-image">

                                                        <ul class="bxslider" >



                                                            @if (count($features))
                                                                @foreach ($features as $feature)
                                                                    <li><img src="{{ url('design')
                                                                    }}/images/medical/{!! $products->name_link !!}/{{ $feature->img_path }}" width="" height"" alt="img"></li>

                                                                @endforeach
                                                            @else

                                                                  <em>@lang('app.no_records_found')</em>

                                                            @endif
                                                                                   </ul>
                                                    </div>
                                                </center>
                                                <hr>



                                                @if (count($features))
                                                    @foreach ($features as $feature)
                                                        <h3>    {!! $feature->name !!}</h3>
                                                        {!! $feature->content !!}<br/>
                                                    @endforeach
                                                @else

                                                    <em>@lang('app.no_records_found')</em>

                                                @endif
                                            </div>



                                        </div>

                                        <br />&nbsp;<br />
                                    </div>
                                </div>

                            </div>



                        </div>
                    </div>
                    <!--/.ads-details-wrapper-->
                </div>
                <!--/.page-content-->

                @include('front.layouts.product_bar')


            </div>

        </div>






@endsection
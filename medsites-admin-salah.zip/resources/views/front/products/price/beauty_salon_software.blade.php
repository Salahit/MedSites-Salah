<div class="col-lg-12 content-box layout-section">
    <div class="row row-featured row-featured-category">
        <div class="col-lg-12 box-title">
            <div class="inner">
                <h2>
                    <span class="title-3">ClinicGate Price List  <span style="font-weight: bold;">US$</span></span>
                    <br />		<a href="#" >
                        ( License price is one time payment lifetime & Support paid Yearly)
                    </a>
                </h2>
            </div>
        </div>
        <table class="table table-hover table-bordered" style="text-align:center;padding-left:200px; padding-right:200px;">
            <thead>
            <tr class="active">

                <th><center><h3>#</h3><p class="text-muted text-sm">-</p></center></th>
                <th><center><h3>Standard</h3><p class="text-muted text-sm">Perfect for larger operations.</p></center></th>
                <th><center><h3>Advanced</h3><p class="text-muted text-sm">Perfect for those who want software.</p></center></th>

            </tr>
            </thead>
            <tbody>

            <tr>
                <td><h3>1</h3>
                </td>

                <td> <h2 style="padding:0px;width:100%px">199$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13" class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='37' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>

                </td>

                <td><h2 style="padding:0px;width:100%px">$249</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='41' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                </td>


            </tr>




            <tr>
                <td><h3>3</h3>
                </td>

                <td> <h2 style="padding:0px;width:100%px">299$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='38' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>

                </td>

                <td><h2 style="padding:0px;width:100%px">379$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='42' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                </td>


            </tr>


            <tr>
                <td><h3>5</h3>
                </td>

                <td> <h2 style="padding:0px;width:100%px">498$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='39' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>

                </td>

                <td><h2 style="padding:0px;width:100%px">$623</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='43' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                </td>


            </tr>

            <tr>
                <td><h3>10</h3>
                </td>

                <td> <h2 style="padding:0px;width:100%px">995$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='40' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>

                </td>

                <td><h2 style="padding:0px;width:100%px">1245$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='44' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                </td>


            </tr>


            <tr>
                <td colspan="5" align="left" style="padding-left:20px;" class="active"><b>Support & Updates</b></td>
            </tr>
            <tr>
                <td>Support & Updates</td>

                <td>70$</td>
                <td>90$</td>

            </tr>

            <tr><td></td>

                <td>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='169' />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                </td>
                <td> <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value='168' />
                        <input type='hidden' name='quantity' value='1' />
                    </form></td>

            </tr>
            </tbody>
        </table>
    </div>
</div>
<div class="col-lg-12 content-box layout-section">
    <div class="row row-featured">
        <div class="col-lg-12 box-title">
            <div class="inner">
                <h2>
                    <span class="title-3">@lang('frontLog.Price_List')  {!!$product['p_name'.langIsAr()]!!}  <span
                                style="font-weight: bold;">US$</span></span>
                    <br />
                        (@lang('frontLog.License_price')</h2>


            </div>
        </div>

        <table class="table table-hover table-bordered" style="text-align:center;padding-left:200px;
        padding-right:200px; padding-top: 0px;margin-top: 0px;">
            <thead>
            <tr class="active">
                <th><center><h3>#</h3><p class="text-muted text-sm">-</p></center></th>
           @if(settings('price_standard_on') == 'Active')<th><center><h3>Standard</h3><p class="text-muted
           text-sm">Perfectfor larger operations.  </p></center></th>
                @endif


                <th><center><h3>Advanced</h3><p class="text-muted text-sm">Perfect for those who want software.</p></center></th>

            </tr>
            </thead>
            <tbody>

            @if (count($prices))
                @foreach ($prices as $price)
                    <h3>    {!! $price->name !!}</h3>

                    @if($price->status == "Active")
            <tr>
                <td><h3>{!! $price->numbers !!}</h3>
                </td>

                @if(settings('price_standard_on') == 'Active')
                    <td>
                    @if($price->standard_status == "Active")
                    <h2 style="padding:0px;width:100%px">{{$price->price_standard}}$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="16" class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id' value="{{$price->product_id_standard}}" />
                        <input type='hidden' name='quantity' value='1' />
                    </form>
                    @endif
                </td>
                @endif
                <td>

                    <h2 style="padding:0px;width:100%px">{{$price->price_advanced}}$</h2>
                    <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                        <input name="Submit3" type="submit" value="Order Now"  size="16"  class="btn btn-info btn-sm" />
                        <input type='hidden' name='sid' value='146793' />
                        <input type='hidden' name='product_id'  value="{!! $price->product_id_advanced !!}"  />
                        <input type='hidden' name='quantity' value='1' />
                    </form>

                </td>


            </tr>
                    @endif





                @endforeach
            @else

                <em>@lang('app.no_records_found')</em>

            @endif


            </tbody>
        </table>
        @if(settings('price_support_updates_on') == 'Active')

        <table class="table table-hover table-bordered" style="text-align:center;padding-left:200px;
        padding-right:200px; padding-top: 0px;margin-top: 0px;">
            <thead>
        <tr>
            <td colspan="5" align="left" style="padding-left:20px;" class="active"><b>Support & Updates</b></td>
        </tr>
        <tr>
            <td>Support & Updates</td>

            <td>{{settings('support_updates_standard_price')}}$</td>
            <td>{{settings('support_updates_advanced_price')}}$</td>

        </tr>

        <tr><td></td>

            <td>
                <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                    <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                    <input type='hidden' name='sid' value='146793' />
                    <input type='hidden' name='product_id' value={{settings('support_updates_standard_id')}} />
                    <input type='hidden' name='quantity' value='1' />
                </form>
            </td>
            <td> <form action='https://www.2checkout.com/2co/buyer/purchase' method='post'  target="_blank">
                    <input name="Submit3" type="submit" value="Order Now"  size="13"  class="btn btn-info btn-sm" />
                    <input type='hidden' name='sid' value='146793' />
                    <input type='hidden' name='product_id' value='{{settings('support_updates_advanced_id')}}' />
                    <input type='hidden' name='quantity' value='1' />
                </form></td>

        </tr>
            </thead></table>

            @endif
    </div>
</div>
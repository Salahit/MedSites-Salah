@include('front.layouts.header_products')



@include('front.layouts.navbar')
@include('front.layouts.menu')



@include('front.layouts.message')
@yield('content')




@include('front.layouts.footer')
<footer class="main-footer" @if (direction()== 'rtl') style="direction:rtl;" @endif >
    <div class="footer-content">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                    <div class="footer-col">
                        <h4 class="footer-title">@lang('frontLog.Products')</h4>
                        <ul class="list-unstyled footer-nav">


                            @if (count(menu_all()))
                                @foreach (menu_all() as $product)

                                    <li><a href="{{ $product->name_link }}">{!!$product['p_name'.langIsAr()
                                        ]!!}</a></li>
                        @endforeach
                        @else

                            @lang('app.no_records_found')

                        @endif
                        </li>

                    </div>
                </div>



                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                    <div class="footer-col">
                        <h4 class="footer-title"> @lang('frontLog.Company')</h4>
                        <ul class="list-unstyled footer-nav">
                        @if (count(page_Services()))
                            @foreach (page_Services() as $page)
                                <li><a href="/page/{{ $page->slug }}">{!!$page['name'.langIsAr()]!!}</a></li>
                            @endforeach
                        @else

                            @lang('app.no_records_found')

                        @endif

                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-col row">


                        <div class="col-sm-12 col-xs-6 col-xxs-12 no-padding-lg">
                            <div class="">
                                <h4 class="footer-title ">Follow us on</h4>
                                <ul class="list-unstyled list-inline footer-nav social-list-footer social-list-color footer-nav-inline">
                                    <li>
                                        <a class="icon-color fb" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://www.facebook.com/MedSitesSoft/" data-original-title="Facebook">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="icon-color tw" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://twitter.com/medsites" data-original-title="Twitter">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="icon-color gp" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://plus.google.com/u/0/102942835317554440895" data-original-title="Google+">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="icon-color lin" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="https://www.linkedin.com/in/medsites/" data-original-title="LinkedIn">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="icon-color pin" title="" data-placement="top" data-toggle="tooltip" target="_blank" href="#" data-original-title="Pinterest">
                                            <i class="fa fa-pinterest-p"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>

                <div style="clear: both"></div>

                <div class="col-lg-12">
                    <hr>

                    <div class="copy-info text-center">
                         2020 Medsites. All Rights Reserved.
                        Powered by MedSites
                    </div>
                </div>

            </div>
        </div>
    </div>
</footer>

</div>



<!-- Modal Change Country -->
<div class="modal fade modalHasList" id="selectCountry" tabindex="-1" role="dialog" aria-labelledby="selectCountryLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    <span class="sr-only">Close</span>
                </button>
                <h4 class="modal-title uppercase font-weight-bold" id="selectCountryLabel">
                    <i class="icon-map"></i> Help
                </h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="row" style="padding: 0 20px">
                        <a href="tel:+201222189796"  class="btn btn-success btn-block showphone">
                            <i class="icon-phone-1">+201222189796</i>
                        </a>

                        <strong>Address</strong> : 	2 Mahmoud Esmat Street, Sheraton Heliopolis.
                        Cairo - Egypt
                        <br>
                        <strong> Cell Phone :</strong>

                        +201-222189796 <br>
                        <strong>Tel </strong>	:

                        +202-22690045 <br>

                        <strong> USA :</strong>

                        +1202-657-5650 <br>

                        <strong>Fax </strong>	: 	+202-22690480 <br>


                        <strong>Office Time</strong> 	: 	9h00 AM - 6h00 PM (Saturday to Thursday) <br>

                        <strong>Time zone </strong>	: 	GMT +02:00 <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">


    var CI = {
        'base_url': 'http://med-sites.com/'
    };

</script>

<script>
    /* Carousel Parameters */
    var carouselItems = 3;
    var carouselAutoplay = 1;
    var carouselAutoplayTimeout = 1500;
    var carouselLang = {
        'navText': {
            'prev': "prev",
            'next': "next"
        }
    };
</script>

<script>

            {{-- Init. Root Vars --}}
    var siteUrl = '<?php echo url((!currentLocaleShouldBeHiddenInUrl() ? config('app.locale') : '' ) . '/'); ?>';
    var languageCode = '<?php echo config('app.locale'); ?>';
    var countryCode = '<?php echo config('country.code', 0); ?>';
    var timerNewMessagesChecking = <?php echo (int)config('settings.other.timer_new_messages_checking', 0); ?>;


    var langLayout = {
        'hideMaxListItems': {
            'moreText': "View More",
            'lessText': "View Less"
        },
        'select2': {
            errorLoading: function(){
                return "The results could not be loaded."
            },
            inputTooLong: function(e){
                var t = e.input.length - e.maximum, n = 'Please delete ' + t + ' character';
                return t != 1 && (n += 's'),n
            },
            inputTooShort: function(e){
                var t = e.minimum - e.input.length, n = 'Please enter ' + t + ' or more characters';
                return n
            },
            loadingMore: function(){
                return "Loading more results�"
            },
            maximumSelected: function(e){
                var t = 'You can only select ' + e.maximum + ' item';
                return e.maximum != 1 && (t += 's'),t
            },
            noResults: function(){
                return "No results found"
            },
            searching: function(){
                return "Searching�"
            }
        }
    };
</script>


@if (Route::is('Homeprofile') or Route::is('Homeprofile/activity')  )
    <script src="{{ url('assets/js/as/app.js') }}"></script>
@else
    <script src="{{ url('design')}}/js/app.js"></script>
    @endif




@yield('after_scripts')
@yield('scripts')

<script src="{{ url('assets/plugins/pnotify/pnotify.custom.min.js') }}"></script>

<script src="http://med-sites.com/public/assets/plugins/twism/jquery.twism.js"></script>
{{-- Bootstrap Notifications using Prologue Alerts --}}
<script type="text/javascript">
    jQuery(document).ready(function ($) {

        PNotify.prototype.options.styling = "bootstrap4";
        PNotify.prototype.options.styling = "fontawesome";

        @foreach (Alert::getMessages() as $type => $messages)
        @foreach ($messages as $message)

        $(function () {
            @if ($message == 'demo_mode_message')
            new PNotify({
                title: 'Information',
                text: "{{ $message }}",
                type: "{{ $type }}"
            });
            @else
            new PNotify({
                text: "{{ $message }}",
                type: "{{ $type }}",
                icon: false
            });
            @endif
        });

        @endforeach
        @endforeach
    });
</script>

</body>
</html>






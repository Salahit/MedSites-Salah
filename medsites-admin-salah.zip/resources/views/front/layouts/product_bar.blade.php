<div class="col-sm-3 page-sidebar-right"  >
    <aside>
        <div class="panel sidebar-panel panel-contact-seller">
            <div class="panel-heading">{!!$product['p_name'.langIsAr()]!!} </div>
            <div class="panel-content user-info">
                <div class="panel-body text-center">

                    <div class="user-ads-action">
                        <a href="{{ url('download')}}/{{ $product->p_name }}/{{ $product->id }}
                       " data-toggle="modal" class="btn btn-warning btn-block">
                            <i class="fa fa-download fa-2x"></i> <strong> @lang('frontLog.Download')</strong>  <br />
                            @lang('frontLog.21_days_FREE_trial') </a>
                        <a href="{{ $product->p_manual_url }}" data-toggle="modal" class="btn btn-default btn-block">
                            <i class="fa fa-question-circle"></i> @lang('frontLog.Training_Help_Manual')
                        </a>

                        <a href="{{ $product->p_pdf_url }}" data-toggle="modal" class="btn btn-default btn-block">
                            <i class="fa fa-file"></i> @lang('frontLog.Download_Brochure')
                        </a>
                        <a href="{{$product->p_comparison_url}}" data-toggle="modal" class="btn btn-default btn-block">
                            <i class="fa fa-check"></i> @lang('frontLog.Versions_Comparison')
                        </a>
                        <a href="#applyNow" data-toggle="modal" class="btn btn-info btn-block">
          <i class="fa fa-windows fa-5x"></i><br/><h3>  @lang('frontLog.Windows_10_Compatible')</h3>
                        </a>

                        <a href="#applyNow" data-toggle="modal" class="btn btn-default btn-block">
                            <i class="fa fa-cc-paypal fa-5x"></i>
                        </a>

                        <a href="#applyNow" data-toggle="modal" class="btn btn-primary btn-block">
                            <i class="fa fa-money fa-5x"></i> <br /><h3>
                                @lang('frontLog.money_back_30_day')

                        </a>
                        <a href="#applyNow" data-toggle="modal" class="btn btn-primary btn-block">
                            <i class="fa fa-certificate fa-5x"></i> <br /><h2>15 Years <br />  2001 - 2016 <br /> Medsites </h2>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel sidebar-panel">
            <div class="panel-heading">MedSites Company</div>
            <div class="panel-content">
                <div class="panel-body text-left">
                    {!! settings('app_address') !!}
                </div>
            </div>
        </div>

        <div style="margin: 25px 0; text-align: center;">
            <button class='btn btn-fb share s_facebook'><i class="icon-facebook"></i> </button>&nbsp;
            <button class='btn btn-tw share s_twitter'><i class="icon-twitter"></i> </button>&nbsp;
            <button class='btn btn-danger share s_plus'><i class="icon-googleplus-rect"></i> </button>&nbsp;
            <button class='btn btn-lin share s_linkedin'><i class="icon-linkedin"></i> </button>
        </div>
        <div class="panel sidebar-panel">
            <div class="panel-heading">Software Benefits</div>
            <div class="panel-content">
                <div class="panel-body text-left">
                    <ul class="list-check">
                        <li> User Friendly </li>
                        <li>One Time Payment </li>
                        <li> Affordable Price</li>
                    </ul>
                </div>
            </div>
        </div>
    </aside>
</div>

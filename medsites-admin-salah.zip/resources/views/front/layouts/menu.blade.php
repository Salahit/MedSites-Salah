
<body class="skin-blue">

<div id="wrapper">

    <div class="header">
        <nav class="navbar navbar-site navbar-default" role="navigation">
            <div class="container">
                <div class="navbar-header">

                    <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>


                    <button class="flag-menu country-flag visible-xs btn btn-default hidden" href="#selectCountry" data-toggle="modal">

                        <i class="fa fa-question-circle "></i><strong> @lang('frontLog.Help')</strong><span class="caret
                         hidden-sm"></span>

                        <span class="caret hidden-xs"></span>
                    </button>


                    <a href="/" class="navbar-brand logo logo-title">
                        <img src="{{ url('design')}}/uploads/app/logo/logo-5a92d4c5aaa85.png"
                             alt="MedSites" class="tooltipHere main-logo" title="" data-placement="bottom"
                             data-toggle="tooltip"
                             data-original-title="MedSites"/>
                    </a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-left">


                        <li class="tooltipHere hidden-xs" data-toggle="tooltip" data-placement="right" title="Help" style="margin-top:0px;">

                            <a class="btn btn-block btn-border btn-post btn-add-listing" href="#selectCountry" data-toggle="modal">
                                <i class="fa fa-key "></i><strong>@lang('frontLog.Help')</strong><span class="caret hidden-sm"></span>
                            </a>



                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
@if(page_Company())
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-building fa hidden-sm"></i>
                                <span><strong> @lang('frontLog.Company')</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>

                            <ul  class="dropdown-menu user-menu">
                                @foreach(page_Company() as $company )
 <li><a href="{{route('pages.page',$company->slug )}}">{!!$company['name'.langIsAr() ]!!}</a></li>
                                    @endforeach
                             </a></li>
                            </ul>
                        </li>
                        @endif
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-check-square fa hidden-sm"></i>
                                <span><strong>@lang('frontLog.Services')</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>

                            <ul  class="dropdown-menu user-menu">
                                @foreach(page_Services() as $services )
                                    <li><a href="{{route('pages.page',$services->slug )}}">{!!$services['name'.langIsAr() ]!!}</a></li>
                                    @endforeach
                                    </a></li>
                            </ul>
                        </li>
                        <li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-th fa hidden-sm"></i><span><strong> @lang('frontLog.Products') </strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>
                            <ul  class="dropdown-menu user-menu">
                                @if (count(menu_all()))
                                    @foreach (menu_all() as $product)

                                        <li><a href="{{url($product->name_link)}}">{!!$product['p_name'.langIsAr()
                                        ]!!}</a></li>
                                    @endforeach
                                @else

                                    @lang('app.no_records_found')

                                @endif


                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-users hidden-sm"></i>
                                <span><strong>@lang('frontLog.Clients')</strong></span>
                                <i class="icon-down-open-big fa hidden-sm"></i>
                            </a>
                            <ul  class="dropdown-menu user-menu">
                                <li><a href="#">@lang('frontLog.Software')</a></li>
                                <li><a href="#">@lang('frontLog.Websites')</a></li>
                            </ul>
                        </li>




                        <li   >
                            <a   class="btn btn btn-add-listing" style="padding-left:10px;
                            padding-right:10px;" href="{{url('/')}}/ticket">
                                <i class="fa fa-question-circle "></i><strong> @lang('frontLog.Support')</strong>
                            </a>
                        </li>
@if( settings('language_available'))
                        <!-- Language selector -->
                        <li class="dropdown lang-menu">
                            <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                                EN
                                <span class="caret hidden-sm"> </span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="{{url('lang/an')}}" tabindex="-1" rel="alternate" hreflang="fr">
                                        <span class="lang-name"> English</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{url('lang/ar')}}" tabindex="-1" rel="alternate" hreflang="ar">
                                        <span class="lang-name"> @lang('frontLog.arabic')  </span>
                                    </a>
                                </li>
                            </ul>

                        </li>

@endif



                            @if ( Auth::check())
                            <li>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="icon-user fa hidden-sm"></i>
                                    <span>{!! auth()->user()->present()->nameOrEmail !!}  </span>
                                    <i class="icon-down-open-big fa hidden-sm"></i>
                                </a>
                                <ul class="dropdown-menu user-menu">
                                    <li class="active">
                                        <a href="{{ route('Homeprofile') }}">
                                            <i class="icon-home"></i> Personal Home
                                        </a>
                                    </li>
                                    <li><a href="{{ route('Homeprofile.myprodrct') }}"><i class="icon-th-thumb"></i> My
                                            Products </a></li>




                                </ul>
                            </li>
                            <li>
                                <a href="{{ url('logout') }}">
                                    <i class="glyphicon glyphicon-off hidden-sm"></i> @lang('frontLog.log_out')
                                </a> </li>
                            @else
                            <li>    <a href="/login" data-toggle="modal">
                                    <i class="icon-user fa"></i> Log In</a>
                            </li>

                            <li><a href="register"><i class="icon-user-add fa"></i> Register</a></li>
                                @endif






                    </ul>


                </div>
            </div>
        </nav>
    </div>

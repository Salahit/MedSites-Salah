<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="shortcut icon" href="{{url('favicon.ico')}}"/>
    <title> @yield('page-title') Medical Software, Hospital, Dental, Veterinary, Billing, Appointment, Clinic
    </title>
    <meta name="DESCRIPTION" content="MedSites is a Healthcare Software Leader For Medical Billing Software, Hospital Management, Veterinary Office, Salon, Dental Clinic, Appointment scheduling software For Small-Large Practice Management Size. Download FREE 21 Days Trial." />
    <meta name="keywords" content="medical software, hospital software, veterinary software, dental software, beauty salon software, billing software, clinic Software, medical Appointment scheduling software, healthcare software, practice management software, Hospital management system" />
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta name="application-name" content="{{ settings('app_name') }}"/>



    @if (direction()== 'rtl')

        <link href="{{ url('design')}}/css/app.rtl.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Cairo:400,700&display=swap&subset=arabic" rel="stylesheet">
        <style type="text/css">
            *{
                font-family: 'Cairo', sans-serif;
            }

            #custom_carousel .item {

                color:#006;

                padding:20px 0;
                direction: rtl;
            }
            #custom_carousel .controls{
                overflow-x: auto;
                overflow-y: hidden;
                padding:10;
                margin:10;
                white-space: nowrap;
                text-align: center;
                position: relative;
                direction: rtl;
            }
            #custom_carousel .controls li {
                display: table-cell;
                width: 1%;
                max-width:90px
            }
            #custom_carousel .controls li.active {

                border-top:3px solid orange;
            }
            #custom_carousel .controls a small {
                overflow:hidden;
                display:block;
                font-size:10px;
                margin-top:5px;
                font-weight:bold
            }
            /* === Body === */

            /* === Header === */
            .navbar-site { position: absolute !important; }
            /* === Footer === */

            /* === Button: Add Listing === */

            /* === Other: Grid View Columns === */

            /* === Homepage: Search Form Area === */
            #homepage .wide-intro {background-image: url(design/uploads/app/logo/header-5aa1512725049.png);
                background-size: cover;}#homepage .wide-intro h1 { color: #080808; }#homepage .wide-intro p { color: #080808; }
            /* === Homepage: Locations & Country Map === */


            /* === CSS Fix === */
            .f-category h6 {
                color: #333;
            }
            .photo-count {
                color: #292b2c;
            }
            .page-info-lite h5 {
                color: #ccc;
            }
            h4.item-price {
                color: #292b2c;
            }
            .skin-blue .pricetag {
                color: #fff;
            }
            body{
                font-family: 'Cairo', sans-serif;
            }
        </style>
    @else
        <link href="{{ url('design')}}/css/app.css" rel="stylesheet">

    <style type="text/css">
        #custom_carousel .item {

            color:#006;

            padding:20px 0;
        }
        #custom_carousel .controls{
            overflow-x: auto;
            overflow-y: hidden;
            padding:10;
            margin:10;
            white-space: nowrap;
            text-align: center;
            position: relative;

        }
        #custom_carousel .controls li {
            display: table-cell;
            width: 1%;
            max-width:90px
        }
        #custom_carousel .controls li.active {

            border-top:3px solid orange;
        }
        #custom_carousel .controls a small {
            overflow:hidden;
            display:block;
            font-size:10px;
            margin-top:5px;
            font-weight:bold
        }
        /* === Body === */

        /* === Header === */
        .navbar-site { position: absolute !important; }
        /* === Footer === */

        /* === Button: Add Listing === */

        /* === Other: Grid View Columns === */

        /* === Homepage: Search Form Area === */
        #homepage .wide-intro {background-image: url(design/uploads/app/logo/header-5aa1512725049.png);
            background-size: cover;}#homepage .wide-intro h1 { color: #080808; }#homepage .wide-intro p { color: #080808; }
        /* === Homepage: Locations & Country Map === */


        /* === CSS Fix === */
        .f-category h6 {
            color: #333;
        }
        .photo-count {
            color: #292b2c;
        }
        .page-info-lite h5 {
            color: #ccc;
        }
        h4.item-price {
            color: #292b2c;
        }
        .skin-blue .pricetag {
            color: #fff;
        }

    </style>
    @endif

    <link href="{{ url('design')}}/css/custom.css" rel="stylesheet">







    <link media="all" type="text/css" rel="stylesheet" href="{{ url('assets/plugins/pnotify/pnotify.custom.min.css') }}">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    @yield('after_styles')
    @yield('styles')

</head>
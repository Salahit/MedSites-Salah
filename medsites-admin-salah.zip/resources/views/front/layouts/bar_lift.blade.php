<div class="col-md-4 reg-sidebar">
    <div class="reg-sidebar-inner text-center">
        <div class="promo-text-box"><i class="icon-picture fa fa-4x icon-color-1"></i>
            <h3><strong>About us</strong></h3>
            <p>

                MedSites is a Cairo based Complete Software Solutions and Complete web Solutions Company focused on creating custom applications and laying special emphasis on the unique business needs of its corporate clients. MedSites infrastructure and processes are concentrated at designing and implementing solutions for Small to large sized companies. MedSites long-term-relationship-based strategy ensures a continuously stable growth and a solid customer base.

                Our Staff Our staff consists of a team of talented and innovative individuals like Software & Web developers, graphic artists, analysts, programmers, database designers and Internet Business specialists all of whom are dedicated to providing your desktop, multi-user & online solutions
            </p>
        </div>
        <div class="promo-text-box"><i class=" icon-pencil-circled fa fa-4x icon-color-2"></i>
            <h3><strong>Software Reseller</strong></h3>
            <p>

                Looking for a way to earn more dollars ? Our software HospitalGate, ClinicGate, VeterinaryGate, BodyCareGate, CompanyGate and RestaurantGate are a leading 5 Star Award Winning software in the market today. It has been expanding at an escalating rate since its introduction in 2004. Our software has been covered in several high profile magazines including ZDnet and PC Magazine and comes highly recommended by its authors. </p>
        </div>
        <div class="promo-text-box"><i class="icon-heart-2 fa fa-4x icon-color-3"></i>
            <h3><strong>Services.</strong></h3>
            <p>
                MedSites Team Strives to provide you with custom oftware , Web solutions,
                Social Marketing and Search Engine Optimization that will empower you to remain a head of your competitors by continuously improving your information technology based business solutions .</p>
        </div>
    </div>
</div>